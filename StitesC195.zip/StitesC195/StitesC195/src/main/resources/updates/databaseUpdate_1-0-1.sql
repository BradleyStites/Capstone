CREATE TABLE software_version(id INT NOT NULL, version_number varchar(20) NOT NULL, release_date DATE, description varchar(255), PRIMARY KEY (id));

CREATE TABLE user_roles(Role_ID int NOT NULL, Role_Description varchar(50), CanResetPassword BOOLEAN, SuperUser BOOLEAN, PRIMARY KEY (Role_ID));

CREATE TABLE administrators(Admin_ID int NOT NULL, User_ID int NOT NULL, Role_ID int NOT NULL, PRIMARY KEY (Admin_ID), CONSTRAINT FK_ADMIN_USERS FOREIGN KEY (User_ID) REFERENCES Users(User_ID), CONSTRAINT FK_ADMIN_ROLES FOREIGN KEY (Role_ID) REFERENCES User_Roles(Role_ID));

CREATE TABLE searches(Search_ID int NOT NULL, Start datetime, End datetime, Type varchar(50), User_ID int, Title varchar(50), Description varchar(50), Favorite BOOLEAN, Customer_ID int, Contact_ID int, Location varchar(50), Zone_ID varchar(50), Owner_ID int, PRIMARY KEY (Search_ID), CONSTRAINT FK_SEARCHES_USERS FOREIGN KEY (User_ID) REFERENCES Users(User_ID), CONSTRAINT FK_SEARCHES_CUSTOMERS FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID), CONSTRAINT FK_SEARCHES_CONTACTS FOREIGN KEY (Contact_ID) REFERENCES Contacts(Contact_ID));

CREATE TABLE user_availability(Availability_ID int NOT NULL, User_ID int NOT NULL, Start datetime, End datetime, Status varchar(50), RepeatFrequency varchar(50), Repeat_End_Date datetime, Details varchar(255), PRIMARY KEY(Availability_ID), CONSTRAINT FK_AVAILABILITY_USER FOREIGN KEY (User_ID) REFERENCES Users(User_ID));

INSERT INTO user_roles(Role_ID, Role_Description, CanResetPassword, SuperUser) VALUES (1, 'User',  0, 0),(2, 'Admin', 1, 0),(3, 'Super Admin', 1, 1);

INSERT INTO software_version (id, version_number, release_date, description) VALUES (1, '1.0.1', '2023-12-18', 'Initial release of software version, availability, roles, and administration related tables.');