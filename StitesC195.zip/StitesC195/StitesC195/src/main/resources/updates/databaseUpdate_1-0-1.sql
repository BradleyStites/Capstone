CREATE TABLE software_version(id INT NOT NULL AUTO_INCREMENT, version_number varchar(20) NOT NULL, release_date DATE, description varchar(255), PRIMARY KEY (id));

CREATE TABLE user_roles(Role_ID int NOT NULL AUTO_INCREMENT, Role_Description varchar(50), Administrator BOOLEAN, PRIMARY KEY (Role_ID));

CREATE TABLE administrators(Admin_ID int NOT NULL AUTO_INCREMENT, User_ID int NOT NULL, Role_ID int NOT NULL, PRIMARY KEY (Admin_ID), CONSTRAINT FK_ADMIN_USERS FOREIGN KEY (User_ID) REFERENCES Users(User_ID), CONSTRAINT FK_ADMIN_ROLES FOREIGN KEY (Role_ID) REFERENCES User_Roles(Role_ID));

CREATE TABLE searches(Search_ID int NOT NULL AUTO_INCREMENT, Start datetime null, End datetime null, Type varchar(50) null, Title varchar(50) null, User_ID int null, Description varchar(50) null, Favorite BOOLEAN, Customer_ID int NULL, Contact_ID int NULL, Location varchar(50) null, Owner_ID int NULL, PRIMARY KEY (Search_ID), CONSTRAINT FK_SEARCHES_USERS FOREIGN KEY (User_ID) REFERENCES Users(User_ID), CONSTRAINT FK_SEARCHES_CUSTOMERS FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID), CONSTRAINT FK_SEARCHES_CONTACTS FOREIGN KEY (Contact_ID) REFERENCES Contacts(Contact_ID), CONSTRAINT FK_SEARCHES_OWNER FOREIGN KEY (Owner_ID) REFERENCES Users(User_ID));

CREATE TABLE user_availability(Availability_ID int NOT NULL AUTO_INCREMENT, User_ID int NOT NULL, Start datetime, End datetime, Status varchar(50), RepeatFrequency varchar(50), Repeat_End_Date datetime, Details varchar(255), PRIMARY KEY(Availability_ID), CONSTRAINT FK_AVAILABILITY_USER FOREIGN KEY (User_ID) REFERENCES Users(User_ID));

INSERT INTO user_roles(Role_ID, Role_Description, administrator) VALUES (1, 'User',  0),(2, 'Admin', 1);

INSERT INTO software_version (id, version_number, release_date, description) VALUES (1, '1.0.1', '2023-12-18', 'Initial release of software version, availability, roles, searches, and administration related tables.');