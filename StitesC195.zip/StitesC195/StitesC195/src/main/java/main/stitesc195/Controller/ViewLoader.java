package main.stitesc195.Controller;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Bounds;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.stage.Screen;
import javafx.stage.Stage;
import main.stitesc195.MainApplication;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the ViewLoader class.
 * Launches different screens, shows alerts, shows confirm prompts, and exits out of the application.
 *
 * @author Bradley Stites
 */
public class ViewLoader {

    /**
     * Loads different screens throughout the application based on fxmlFileName and hides previous screens based
     * on currentStage.
     * @param fxmlFileName  the file name intended to be loaded.
     * @param currentStage  current stage being hidden.
     */
    public void loadFXML(String fxmlFileName, Stage currentStage) {
        String title = ResourceBundle.getBundle("language").getString(fxmlFileName);
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource(fxmlFileName + ".fxml"));

        try (InputStream fxmlStream = MainApplication.class.getResourceAsStream(fxmlFileName + ".fxml")) {
            Scene scene = new Scene(fxmlLoader.load(fxmlStream));
            Stage stage = new Stage();
            if(currentStage!=null)
                currentStage.hide();
            stage.setTitle(title);
            stage.setScene(scene);
            stage.setOnShown(event -> {
                Bounds bounds = stage.getScene().getRoot().getLayoutBounds();
                double x = (Screen.getPrimary().getVisualBounds().getWidth() - bounds.getWidth()) / 2;
                double y = (Screen.getPrimary().getVisualBounds().getHeight() - bounds.getHeight()) / 2;
                stage.setX(x);
                stage.setY(y);
            });
            stage.show();
        } catch (IOException e) {
            System.err.println("Failed to load FXML file: " + fxmlFileName);
            e.printStackTrace();
        }
    }

    /**
     * Displays an alert with the message parameter.
     * @param message   Message to alert the user.
     */
    public void showAlert(String message) {

        ResourceBundle languages      = ResourceBundle.getBundle("language");
        String okay                   = languages.getString("okay");

        new Alert(
                Alert.AlertType.WARNING,
                message,
                new ButtonType(okay, ButtonBar.ButtonData.OK_DONE)
        ).showAndWait();
    }

    /**
     * Displays a confirmation prompt with a message.
     *
     * @param message confirmation message for the user.
     * @return        TRUE if confirmed, FALSE if cancelled.
     */
    public Boolean confirmPrompt(String message) {
        ResourceBundle languages = ResourceBundle.getBundle("language");
        String confirm = languages.getString("confirm");
        String cancel = languages.getString("cancel");

        Alert alert = new Alert(
                Alert.AlertType.CONFIRMATION,
                message,
                new ButtonType(confirm, ButtonBar.ButtonData.OK_DONE),
                new ButtonType(cancel, ButtonBar.ButtonData.CANCEL_CLOSE)
        );

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get().getButtonData() == ButtonBar.ButtonData.OK_DONE) {
            // User clicked "OK" button
            return true;
        } else {
            return false;
        }
    }

    /**
     * Exits out of the application and closes the connection to the database.
     */
    private void Exit(){
        try {
            ConnectDB.closeConnection();
        }catch(Exception e){
            System.out.println("Error Closing Connection: \n"+e.toString());
        }

        System.exit(0);
    }
}