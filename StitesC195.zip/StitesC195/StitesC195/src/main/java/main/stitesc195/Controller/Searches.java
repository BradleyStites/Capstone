package main.stitesc195.Controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.*;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.stitesc195.Model.Contact;
import main.stitesc195.Model.Customer;
import main.stitesc195.Model.Search;

/**
 * Contains the logic and variables for the "Customers" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class Searches implements Initializable {

    /**
     * Search button for loading the details from the selected search into the appointments screen.
     */
    @FXML
    private Button searchButton;

    /**
     * Add button for adding search, loads the Search Details screen when pressed.
     */
    @FXML
    private Button addButton;

    /**
     * Back button for return to previous screen, loads the Appointments screen.
     */
    @FXML
    private Button backButton;

    /**
     * TableView for storing the various searches.
     */
    @FXML
    private TableView searchesTable;

    /**
     * Modify Button for viewing or modifying an existing search, loads Search Details screen when pressed.
     */
    @FXML
    private Button modifyButton;

    /**
     * Delete button for deleting a selected search from the table and database
     */
    @FXML
    private Button deleteButton;

    /**
     * Show Favorites check box for limiting the selection to view on the table to favorites only
     */
    @FXML
    private CheckBox showFavoritesCheckBox;

    /**
     * TableColumn for storing Search Ids
     */
    @FXML
    TableColumn<Search, Integer> idColumn;

    /**
     * TableColumn for storing Search Start value
     */
    @FXML
    TableColumn<Search, String> startColumn;

    /**
     * TableColumn for storing Search End value
     */
    @FXML
    TableColumn<Search, String> endColumn;

    /**
     * TableColumn for storing Search Type
     */
    @FXML
    TableColumn<Search, String> typeColumn;

    /**
     * TableColumn for storing Search User ID value
     */
    @FXML
    TableColumn<Search, String> userIDColumn;

    /**
     * TableColumn for storing Search Customer ID value
     */
    @FXML
    TableColumn<Search, String> customerIDColumn;

    /**
     * TableColumn for storing Search Contact Name value
     */
    @FXML
    TableColumn<Search, String> contactNameColumn;

    /**
     * TableColumn for storing Search Location value
     */
    @FXML
    TableColumn<Search, String> locationColumn;

    /**
     * TableColumn for storing Search Favorite value
     */
    @FXML
    TableColumn<Search, Boolean> favoriteColumn;

    /**
     * ObservableList used to store all searches
     */
    ObservableList<Search> searches = FXCollections.observableArrayList();

    /**
     * ObservableList to store all contacts.
     */
    ObservableList<Contact>     contacts     = FXCollections.observableArrayList();

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * Boolean value used to represent false if converting toServer
     */
    static final Boolean toServer = false;

    /**
     * Boolean value used to represent false if converting fromServer
     */
    static final Boolean fromServer = true;

    /**
     * Search object used to store the selected search
     */
    private Search selectedSearch = new Search();

    /**
     * DateHelper class to help convert dates
     */
    DateHelper dateHelper;

    /**
     * Initializes the Search screen.
     * Sets the GUI elements to the appropriate text based on language selection and gets all searches from the database
     * and displays them in the table view.
     *
     * @param url            The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();
        setLanguage();

        //get all contacts to map the customer_id stored in the database to; matches the rest of the application
        contacts = ConnectDB.getAllContacts();

        //get all customers from the database and load into cells
        getAllSearches(searches);
    }

    /**
     *  Logic for the show favorites only check box.
     *
     * @param searches An ObservableList of Search objects containing all searches to be displayed.
     */
    public void showFavoritesOnly(ObservableList<Search> searches){
        searches.removeAll();

        searches = ConnectDB.getAllFavoriteSearches();

        //loop through each search; adjust the dates to be displayed for the current search
        for(Search search : searches){
            search = convertSearchDates(search, fromServer);
        }

        updateTable(searches);
    }

    /**
     *  Populates the Searches table with the search Observable List. Sets the appropriate cell factories to
     *  display search information, and converts date/time values from the server time to the user's local time
     *  zone, and updates the table view.
     *
     * @param searches An ObservableList of SearchDetails objects containing all searches to be displayed.
     */
    public void getAllSearches(ObservableList<Search> searches) {

        //get searches from database
        searches = ConnectDB.getSearchesForActiveUser();

        // Create a Map<Integer, String> to store the relationship between contact ID and contact name
        Map<Integer, String> contactNameMap = new HashMap<>();

        // store a key pair of contact id and contact name in the map
        for (Contact contact : contacts) {
            contactNameMap.put(contact.getId(), contact.getName());
        }

        PropertyValueFactory<Search, Integer> idColumnFactory = new PropertyValueFactory<>("id");
        idColumn.setCellValueFactory(idColumnFactory);

        startColumn.setCellValueFactory(cellData -> {
            String value = cellData.getValue().getStart() != null ? DateHelper.convertServerToUser(cellData.getValue().getStart()) : "null";
            return new SimpleStringProperty(value);
        });

        endColumn.setCellValueFactory(cellData -> {
            String value = cellData.getValue().getEnd() != null ? DateHelper.convertServerToUser(cellData.getValue().getEnd()) : "null";
            return new SimpleStringProperty(value);
        });

        typeColumn.setCellValueFactory(cellData -> {
            String type = cellData.getValue().getType();
            return new SimpleStringProperty(type != null ? type : "null");
        });

        userIDColumn.setCellValueFactory(cellData -> {
            Integer userID = cellData.getValue().getUserId();
            System.out.println("user id: " + userID);
            return (userID == null || userID==0) ? new SimpleStringProperty("null") : new SimpleStringProperty(String.valueOf(userID));
        });

        customerIDColumn.setCellValueFactory(cellData -> {
            Integer customerID = cellData.getValue().getCustomerId();
            return (customerID == null || customerID == 0) ? new SimpleStringProperty("null") : new SimpleStringProperty(String.valueOf(customerID));
        });

        /*
         * Lambda Expression Explanation: setting the cell value factories reduced the amount of lines I had to use to
         * accomplish the same task and makes the code cleaner looking. This particular section modifies the
         * SearchDetails ContactColumn to retrieve the contact name from the contactNameMap
         */
        contactNameColumn.setCellValueFactory(cellData -> {
            int contactID = cellData.getValue().getContactId();
            String contactName = contactNameMap.get(contactID);
            return new SimpleStringProperty(contactName != null ? contactName : "null");
        });

        PropertyValueFactory<Search, String> locationColumnFactory = new PropertyValueFactory<>("location");
        locationColumn.setCellValueFactory(locationColumnFactory);

        PropertyValueFactory<Search, Boolean> favoriteColumnFactory = new PropertyValueFactory<>("favorite");
        favoriteColumn.setCellValueFactory(favoriteColumnFactory);

        //loop through each search; adjust the dates to be displayed for the current search
        for(Search search : searches){
            search = convertSearchDates(search, fromServer);
        }

        updateTable(searches);
    }

    /**
     * Back button for returning to previous screen "Appointments.fxml"
     */
    public void BackButton(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Loads Search Details screen to add a search.
     */
    public void addSearch(){
        ConnectDB.selectedSearch = null;

        currentStage = (Stage) addButton.getScene().getWindow();
        viewLoader.loadFXML("SearchDetails", currentStage);
    }

    /**
     * Loads Appointments screen with the selected searches details, or notifies
     user if no selected search.
     */
    public void search() throws SQLException {

        //get search selection from table
        selectedSearch = (Search) searchesTable.getSelectionModel().getSelectedItem();
        if(selectedSearch!=null) {
            convertSearchDates(selectedSearch, toServer);
            ConnectDB.selectedSearch = selectedSearch;
        }

        //ensure not null
        if(selectedSearch==null){
            String noSelectedSearch = languages.getString("noSelectedSearch");
            viewLoader.showAlert(noSelectedSearch);
            return;
        }

        //load search into Appointments scene
        Appointments appointment = new Appointments();
        ConnectDB.selectedSearch = selectedSearch;
        appointment.setSearch(selectedSearch);
        appointment.initialize();

        try{
            appointment.loadDetails(selectedSearch);
            BackButton();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Loads Search Details screen to view or modify an existing search
     */
    public void editSearch(){

        //get search selection from table
        selectedSearch = (Search) searchesTable.getSelectionModel().getSelectedItem();
        convertSearchDates(selectedSearch, toServer);
        ConnectDB.selectedSearch = selectedSearch;

        System.out.println("selected search: " + selectedSearch.printSearchInformation());

        //ensure not null
        if(selectedSearch == null) {
            String noSelectedSearch = languages.getString("noSelectedSearch");
            viewLoader.showAlert(noSelectedSearch);
            return;
        }

        //load search into SearchDetails form
        SearchDetails searchDetails = new SearchDetails();
        searchDetails.setSearch(selectedSearch);
        searchDetails.initialize();

        try{
            searchDetails.loadDetails(selectedSearch);
        } catch (Exception e){
            e.printStackTrace();
        }

        currentStage = (Stage) modifyButton.getScene().getWindow();

        //display SearchDetails screen
        viewLoader.loadFXML("SearchDetails", currentStage);
    }

    /**
     * Deletes a selected search.
     *
     * @throws SQLException if there is an error with the sql code or server.
     */
    public void deleteSearch() throws SQLException {

        //get search selection from table
        selectedSearch = (Search) searchesTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedSearch = selectedSearch;

        //ensure not null
        if (selectedSearch == null) {
            String noSelectedSearch = languages.getString("noSelectedSearch");
            viewLoader.showAlert(noSelectedSearch);
            return;
        }

        // Prompt user to ensure they want to continue with the deletion
        String confirmDeletion	= languages.getString("confirmDeleteSearch");
        Boolean confirmStatus	= viewLoader.confirmPrompt(confirmDeletion);

        if(confirmStatus) {

            //proceed with deletion
            int success = ConnectDB.deleteSearch(selectedSearch);

            if (success > 0) {
                searches.remove(selectedSearch);

                ResourceBundle languages = ResourceBundle.getBundle("language");
                String searchDeleted	 = languages.getString("searchDeleted");
                String SearchDetails	 = "Search ID: " + selectedSearch.getId() +"\n";

                viewLoader.showAlert(searchDeleted+"\n"+SearchDetails);

                //refresh search list
                getAllSearches(searches);

            } else {
                String searchNotDeleted = languages.getString("searchNotDeleted");
                viewLoader.showAlert(searchNotDeleted);
            }
        }

        //	--------------I feel like this error needs to be further examined.--------------
        //				  I should attempt to fail the confirmation status and see what happens
        else {
            //display error message alerting user about the appointments in the database that are assigned to the customer
            String existingAppointmentsError = languages.getString("existingAppointmentsError");
            viewLoader.showAlert(existingAppointmentsError);
        }
    }

    /**
     * Sets the language of the various GUI elements based on language selection.
     */
    public void setLanguage() {
        //get language setting from system
        ResourceBundle 	languages 	= ResourceBundle.getBundle("language");

        String 	searchId, location, type, start, end,
                customerId, userId, contact, favorite, showFavorites, search, add, view, delete, back;

        searchId 		= languages.getString("searchId");
        location		= languages.getString("location");
        type			= languages.getString("type");
        start			= languages.getString("start");
        end				= languages.getString("end");
        customerId		= languages.getString("customerId");
        userId			= languages.getString("userId");
        contact		    = languages.getString("contact");
        favorite		= languages.getString("favorite");
        search			= languages.getString("search");
        add 			= languages.getString("add");
        view 			= languages.getString("view");
        delete 			= languages.getString("delete");
        back 			= languages.getString("back");
        showFavorites	= languages.getString("showFavoritesOnly");

        idColumn.setText(searchId);
        locationColumn.setText(location);
        typeColumn.setText(type);
        startColumn.setText(start);
        endColumn.setText(end);
        customerIDColumn.setText(customerId);
        userIDColumn.setText(userId);
        contactNameColumn.setText(contact);
        favoriteColumn.setText(favorite);
        searchButton.setText(search);
        addButton.setText(add);
        modifyButton.setText(view);
        deleteButton.setText(delete);
        backButton.setText(back);
        showFavoritesCheckBox.setText(showFavorites);
    }

    /**
     * Update the table view based on the searches input.
     *
     * @param searchesList the list of searches to be shown on the table view
     */
    public void updateTable(ObservableList<Search> searchesList) {
        searchesTable.getItems().clear();
        searchesTable.getItems().setAll(searchesList);
        searchesTable.refresh();
    }

    /**
     * Converts values to/from server/user to store or display, depending on context.
     *
     * @param search		the search object that has the dates in question
     * @param fromServer    boolean value to determine which way we are converting either to or from the server.
     * @return              search object with adjust date/time
     */
    public Search convertSearchDates(Search search, Boolean fromServer) {

        //createdString used to store the created date string that's been converted either from/to server/user time
        String createdString="";

        //updatedString used to store the updated string that's been converted either from/to server/user time
        String updatedString="";

        //check if converting to or from the server
        if (fromServer) {
            //alter values to be the user's time zone
            if(search.getStart()!=null)
                createdString = DateHelper.convertServerToUser(search.getStart());
            if(search.getEnd()!=null)
                updatedString = DateHelper.convertServerToUser(search.getEnd());
        }else{
            /* Convert to Server Date-Time */
            if(search.getStart()!=null)
                createdString = DateHelper.convertUserToServer(search.getStart());
            if(search.getEnd()!=null)
                updatedString = DateHelper.convertUserToServer(search.getEnd());
        }

        //set values for the search and return search object
        if(search.getStart()!=null)
            search.setStart(DateHelper.stringToDate(createdString));
        if(search.getEnd()!=null)
            search.setEnd(DateHelper.stringToDate(updatedString));
        return search;
    }

    public void showFavoritesOnly(ActionEvent actionEvent) {
        searches.removeAll();

        searches = ConnectDB.getAllFavoriteSearches();

        //loop through each search; adjust the dates to be displayed for the current search
        for(Search search : searches){
            search = convertSearchDates(search, fromServer);
        }

        updateTable(searches);
    }
}