package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.*;
import javafx.stage.Stage;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Availability;
import main.stitesc195.Model.Contact;

import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Contains the logic and variables for the "AppointmentDetails" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection, and accepts input for
 * creating or updating Appointments.
 *
 * @author Bradley Stites
 */
public class AppointmentDetails implements Initializable {

    /**
     * Label for storing text representing "Appointment ID".
     */
    @FXML
    public Label appointmentIDLabel;

    /**
     * Label for storing text representing "Appointment Title".
     */
    @FXML
    public Label titleLabel;

    /**
     * Label for storing text representing "Appointment Type".
     */
    @FXML
    public Label appointmentTypeLabel;

    /**
     * Label for storing text representing "Appointment Description".
     */
    @FXML
    public Label appointmentDescriptionLabel;

    /**
     * Label for storing text representing "Customer ID".
     */
    @FXML
    public Label customerIDLabel;

    /**
     * Label for storing text representing "User ID".
     */
    @FXML
    public Label userIDLabel;

    /**
     * Label for storing text representing "Contact".
     */
    @FXML
    public Label contactLabel;

    /**
     * Label for storing text representing "Start Date".
     */
    @FXML
    public Label startDateLabel;

    /**
     * Label for storing text representing "End Date".
     */
    @FXML
    public Label endDateLabel;

    /**
     * Label for storing text representing "Start Time".
     */
    @FXML
    public Label startTimeLabel;

    /**
     * Label for storing text representing "End Time".
     */
    @FXML
    public Label endTimeLabel;

    /**
     * Label for storing text representing "Time Zone".
     */
    @FXML
    public Label timeZoneLabel;

    /**
     * Label for storing text representing "Appointment Location".
     */
    @FXML
    public Label locationLabel;

    /**
     * Label for storing text representing "Appointment Creation Date".
     */
    @FXML
    public Label createdDateLabel;

    /**
     * Label for storing text representing "Created By".
     */
    @FXML
    public Label createdByLabel;

    /**
     * Label for storing text representing "Last Update".
     */
    @FXML
    public Label lastUpdatedLabel;

    /**
     * Label for storing text representing "Last Updated By".
     */
    @FXML
    public Label lastUpdatedByLabel;

    /**
     * TextField representing the AppointmentId
     *
     * Field is disabled due to auto-generation.
     */
    @FXML
    public TextField appointmentIDField;

    /**
     * A ComboBox representing possible contacts.
     */
    @FXML
    public ComboBox contactComboBox;

    /**
     * A TextField representing the created date for the appointment.
     */
    @FXML
    public TextField createdDateField;

    /**
     * A TextField representing the user who created the appointment.
     */
    @FXML
    public TextField createdByField;

    /**
     * A TextField representing the customer id for the appointment.
     */
    @FXML
    public TextField customerIDField;

    /**
     * A TextField representing the appointment description.
     */
    @FXML
    public TextField appointmentDescriptionField;

    /**
     * A DatePicker used to pick the start date for the appointment.
     */
    @FXML
    public DatePicker startDatePicker;

    /**
     * A DatePicker used to pick the end date for the appointment.
     */
    @FXML
    public DatePicker endDatePicker;

    /**
     * A TextField used to store the value for the last update.
     */
    @FXML
    public TextField lastUpdatedField;

    /**
     * A TextField used to store the value for the user who last updated the appointment.
     */
    @FXML
    public TextField lastUpdatedByField;

    /**
     * A TextField used to store the Appointment Title.
     */
    @FXML
    public TextField appointmentTitleField;

    /**
     * A TextField used to store the appointment Type.
     */
    @FXML
    public TextField appointmentTypeField;

    /**
     * A TextField used to store the location of the appointment.
     */
    @FXML
    public TextField appointmentLocationField;

    /**
     * A TextField used to store the user id.
     */
    @FXML
    public TextField userIDField;

    /**
     * Button for saving values in the form to the Database as an appointment object.
     */
    @FXML
    public Button saveButton;

    /**
     * Button to cancel the input of values and return to the previous screen Appointments.fxml
     */
    @FXML
    public Button cancelButton;

    /**
     * A ComboBox used to store the value of the selected time zone. Will also be used to convert date and time values
     * in various start and end ComboBoxes such as startTimeHHComboBox,startTimeMMComboBox, etc...
     */
    @FXML
    public ComboBox timeZoneComboBox;

    /**
     * ComboBox used to store the Start Hours of the appointment represented by 24-Hour format
     */
    @FXML
    public ComboBox startTimeHHComboBox;

    /**
     * ComboBox used to store the Start Minutes of the appointment represented by 0-59
     */
    @FXML
    public ComboBox startTimeMMComboBox;

    /**
     * ComboBox used to store the End Hours of the appointment represented by 24hr format
     */
    @FXML
    public ComboBox endTimeHHComboBox;

    /**
     * ComboBox used to store the End Minutes of the appointment represented by 0-59
     */
    @FXML
    public ComboBox endTimeMMComboBox;

    /**
     * ObservableList used to store the various hour selections. Represented by 0-23, or a 24-Hour format.
     */
    ObservableList<Integer> hh;

    /**
     * ObservableList used to store the various minute selections. Represented by 0-59.
     */
    ObservableList<Integer> mm;

    /**
     * Appointment object used to store a selected appointment or new appointment
     */
    Appointment appointment;

    /**
     * ObservableList used to store all contacts from the database and to attach any selected contact to an appointment.
     */
    ObservableList<Contact> contacts;

    /**
     * Contact object used to store a contact from the ComboBox selection
     */
    Contact contact;

    /**
     * String used to hold value for dateFormatter to display dates and times in desired format
     */
    String dateFormat = "yyyy-MM-dd HH:mm:ss";

    /**
     * DateTimeFormatter used to format a date in the pattern of the 'dateFormat' String
     */
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

    /**
     * Date representing the start date
     */
    Date startDate;

    /**
     * Date representing the end date
     */
    Date endDate;

    /**
     * SimpleDateFormat used to format a date in the pattern of the 'dateFormat' String
     */
    SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert various dates and times.
     */
    DateHelper dateHelper;

    /**
     *  Initializes the AppointmentDetails screen.
     *
     *  Sets the start/end hour and minutes combo boxes to their respective values, sets the contacts' combo box to the
     *  contacts retrieved form the database, and sets the text on the various GUI elements to the match language
     *  selection.
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        if (ConnectDB.selectedAppointment != null) {
            appointment = ConnectDB.selectedAppointment;
        }

        //variable for seconds, set to 0 by default. most users will not need to set specific seconds for appointments
        int ss = 0;

        hh = FXCollections.observableArrayList();
        for (int i = 0; i < 24; i++) {
            hh.add(i);
        }

        mm = FXCollections.observableArrayList();
        for (int i = 0; i < 60; i++) {
           if(i%15==0){
                mm.add(i);
           }
        }

        //get current date, time, & zone
        DateTimeFormatter dateTimeFormat = ConnectDB.getCurrentDateTimeZone();

        Set<String> zoneIds = ZoneId.getAvailableZoneIds();
        Set<String> sortedZoneIds = new TreeSet<>(zoneIds);

        //get zoneid
        ZoneId zoneID = ConnectDB.userTimeZoneId;

        //set time zone combo box
        timeZoneComboBox.getItems().addAll(sortedZoneIds);
        timeZoneComboBox.setValue(zoneID);

        //set hh and mm boxes for both start and end
        startTimeHHComboBox.setItems(hh);
        endTimeHHComboBox.setItems(hh);

        startTimeMMComboBox.setItems(mm);
        endTimeMMComboBox.setItems(mm);

        //get list of all contacts
        contacts = ConnectDB.getAllContacts();

        //set contacts combo box items
        for (Contact c : contacts) {
            contactComboBox.getItems().add(c.getContactName());
        }

        //if updating an appointment    --- this one actually loads the info.
        if (ConnectDB.selectedAppointment != null) {
            appointmentIDField.setText("" + appointment.getAppointmentID());
            appointmentTitleField.setText(appointment.getTitle());
            appointmentDescriptionField.setText(appointment.getDescription());
            appointmentLocationField.setText(appointment.getLocation());
            appointmentTypeField.setText(appointment.getType());
            userIDField.setText("" + appointment.getUserID());
            customerIDField.setText("" + appointment.getCustomerID());
            lastUpdatedByField.setText(appointment.getLastUpdateBy());
            createdByField.setText(appointment.getCreatedBy());

            //get appointment created date & last update, adjust for time zone
            String appointmentCreateDate = DateHelper.convertServerToUser(appointment.getCreateDate());
            String appointmentUpdateDate = DateHelper.convertServerToUser(appointment.getLastUpdate());

            //set fields to adjusted values
            createdDateField.setText(appointmentCreateDate);
            lastUpdatedField.setText(appointmentUpdateDate);

            //set contacts combo box
            for (Contact c : contacts) {
                if (appointment.getContactID() == c.getContactID()) {
                    contactComboBox.setValue(c.getContactName());
                }
            }

            //get dates from the appointment object
            Date startDate = ConnectDB.stringToDate(ConnectDB.dateToString(appointment.getStart()));
            Date endDate   = ConnectDB.stringToDate(ConnectDB.dateToString(appointment.getEnd()));

            //convert date from server to users local time
            String startDateString = ConnectDB.adjustToTimeZone(startDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String endDateString   = ConnectDB.adjustToTimeZone(endDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

            //set dates to newly converted values
            startDate = ConnectDB.stringToDate(startDateString);
            endDate = ConnectDB.stringToDate(endDateString);

            //format values for fields & pickers
            String startFormatted = ConnectDB.formatAppointmentDateForEdit(startDate);
            String endFormatted = ConnectDB.formatAppointmentDateForEdit(endDate);

            //set date pickers
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
            startDatePicker.setValue(ld);

            //set start and end HH & MM combo pickers
            startTimeHHComboBox.setValue(startDate.getHours());
            startTimeMMComboBox.setValue(startDate.getMinutes());

            ld = LocalDate.parse(endFormatted, currentDateFormat);
            endDatePicker.setValue(ld);

            endTimeHHComboBox.setValue(endDate.getHours());
            endTimeMMComboBox.setValue(endDate.getMinutes());
        }

        setLanguage();
    }

    /**
     * Sets various GUI elements to match the language selected
     */
    private void setLanguage() {
        String appointmentId, title, type, description, customerId, userId, contact, startDate, endDate,
                startTime, endTime, timeZone, location, created, createdBy, lastUpdated, lastUpdatedBy,
                save, cancel, contactName, selectTimeZone;

        appointmentId = languages.getString("appointmentId");
        title = languages.getString("title");
        type = languages.getString("type");
        description = languages.getString("description");
        customerId = languages.getString("customerId");
        userId = languages.getString("userId");
        contact = languages.getString("contact");
        startDate = languages.getString("startDate");
        endDate = languages.getString("endDate");
        startTime = languages.getString("startTime");
        endTime = languages.getString("endTime");
        timeZone = languages.getString("timeZone");
        location = languages.getString("location");
        created = languages.getString("created");
        createdBy = languages.getString("createdBy");
        lastUpdated = languages.getString("updated");
        lastUpdatedBy = languages.getString("updatedBy");
        save = languages.getString("save");
        cancel = languages.getString("cancel");
        contactName = languages.getString("contactName");
        selectTimeZone = languages.getString("selectTimeZone");

        appointmentIDLabel.setText(appointmentId);
        titleLabel.setText(title);
        appointmentTypeLabel.setText(type);
        appointmentDescriptionLabel.setText(description);
        customerIDLabel.setText(customerId);
        userIDLabel.setText(userId);
        contactLabel.setText(contact);
        startDateLabel.setText(startDate);
        endDateLabel.setText(endDate);
        startTimeLabel.setText(startTime);
        endTimeLabel.setText(endTime);
        timeZoneLabel.setText(timeZone);
        locationLabel.setText(location);
        createdDateLabel.setText(created);
        createdByLabel.setText(createdBy);
        lastUpdatedLabel.setText(lastUpdated);
        lastUpdatedByLabel.setText(lastUpdatedBy);
        saveButton.setText(save);
        cancelButton.setText(cancel);
        contactComboBox.setPromptText(contactName);
        timeZoneComboBox.setPromptText(selectTimeZone);
    }

    /**
     * Returns the user to the "Appointments.fxml" screen.
     */
    public void cancel() {
        currentStage = (Stage) cancelButton.getScene().getWindow();
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Converts details in the form to an Appointment object, verifies if appointment is a viable appointment by ensuring
     * that it doesn't fall outside business hours and doesn't overlap with an existing appointment, then adds the
     * appointment or updates the appointment depending on the context.
     *
     * Display Alerts on various conditions such as: outside business hours, overlap, or success.
     *
     * @throws SQLException if there is an error with the SQL query.
     */
    public void save() throws SQLException {
        currentStage = (Stage) saveButton.getScene().getWindow();
        Appointment appointment;
        int appointmentId;

        Date createDate, update;

        Boolean withinHours = false, noOverlapWithAppointments = false, isAvailable=false;

        //variables for fields & combo boxes
        String appointmentIdString, customerId, userId, contactName, title, type, description, location, createdDate,
                timeZone, createdUser, updatedUser;

        int contactId;

        //get values from fields & combo boxes
        appointmentIdString = appointmentIDField.getText();
        title = appointmentTitleField.getText();
        type = appointmentTypeField.getText();
        description = appointmentDescriptionField.getText();
        customerId = customerIDField.getText();
        userId = userIDField.getText();
        contactName = contactComboBox.getValue().toString();
        location = appointmentLocationField.getText();
        createdDate = createdDateField.getText();

        //get user's time zone from connect DB
        ZoneId timeZoneId = ConnectDB.userTimeZoneId;

        //set default value of new Appointment to false
        Boolean newAppointment;
		
		int userIdInt = Integer.parseInt(userId);

        //check if newAppointment or not
        if(appointmentIdString == null || appointmentIdString.isEmpty()){
            // This is a new appointment
            appointmentId = ConnectDB.getNewAppointmentID();
            createdUser   = ConnectDB.activeUserName;
            updatedUser   = ConnectDB.activeUserName;
            createDate    = ConnectDB.getDateFromServer();
            newAppointment = true;
        } else{
            //This is an existing appointment
            appointmentId = Integer.parseInt(appointmentIdString);
            createdUser = createdByField.getText();
            createDate = ConnectDB.stringToDate(createdDate);
            updatedUser = ConnectDB.activeUserName;
            newAppointment = false;
        }

        //get contact id
        contact     = ConnectDB.getContactByName(contactName);
        contactId   = contact.getContactID();

        //convert start values to a date
        convertStartAndEndValuesToDate();

        if(startDate==null || endDate==null){
            // If either value is null prompt user and return
            viewLoader.showAlert("nullDates");
            return;
        }
		
		//get all availabilities for the user in question
		ObservableList<Availability> availabilitiesList = FXCollections.observableArrayList();
        ObservableList<Availability> notAvailableList   = FXCollections.observableArrayList();
		
		//initialize the lists with appropriate content
        availabilitiesList = ConnectDB.getAvailableListForUser(userIdInt, true);
        notAvailableList   = ConnectDB.getAvailableListForUser(userIdInt, false);

        //check within availabilities first - if true it's good to go, otherwise prevent saving and prompt user
        isAvailable = checkForAvailabilityOverlap(startDate, endDate, availabilitiesList);
        System.out.println("isAvailable   : "+isAvailable);

        Boolean isNotAvailable = checkForAvailabilityOverlap(startDate, endDate, notAvailableList);
		System.out.println("isNotAvailable: "+isNotAvailable);

        if(isAvailable){
            //do nothing - user is available
        }else{
            if(isNotAvailable){
                //if overlapping with not available list prompt user and prevent saving
                String overlapWithAvailabilityString = languages.getString("overlapWithAvailability");
                viewLoader.showAlert(overlapWithAvailabilityString);
                return;
            }else{
                // Check to ensure within business hours
                withinHours = checkBusinessHours(startDate, endDate);

                //if not within hours prompt user and return
                if (!withinHours) {
                    String outsideBusinessHours = languages.getString("outsideBusinessHours");
                    viewLoader.showAlert(outsideBusinessHours);
                    return;
                }
            }
        }

        //check for overlap with existing appointments
        noOverlapWithAppointments = checkOverlap(startDate, endDate, Integer.parseInt(customerId), appointmentId);

        //if there is overlap prompt user and return
        if (!noOverlapWithAppointments) {
            //show prompt
            String appointmentOverlap = languages.getString("appointmentOverlap");
            viewLoader.showAlert(appointmentOverlap);
            return;
        }

        update = ConnectDB.getDateFromServer();

        Date startDateAdjusted = DateHelper.stringToDate(dateHelper.adjustToTimeZone(startDate,timeZoneId, dateHelper.serverTimeZoneId));
        Date endDateAdjusted   = DateHelper.stringToDate(dateHelper.adjustToTimeZone(endDate,timeZoneId, dateHelper.serverTimeZoneId));

        appointment = new Appointment(appointmentId, title, description, location, type, startDateAdjusted, endDateAdjusted, createDate, createdUser, update, updatedUser, Integer.parseInt(customerId), Integer.parseInt(userId), contactId);

        Boolean success;

        if(newAppointment) {
            success = ConnectDB.addAppointment(appointment);
        }else {
            // This is an existing appointment
            success = ConnectDB.updateAppointment(appointment);
        }

        if (success) {
            if(newAppointment){
                String appointmentAdded = languages.getString("appointmentAdded");
                viewLoader.showAlert(appointmentAdded);
            }else{
                String appointmentUpdated = languages.getString("appointmentUpdated");
                viewLoader.showAlert(appointmentUpdated);
            }

            //Load Appointments
            returnToAppointments();

        } else {
            if(newAppointment){
                String appointmentNotAdded = languages.getString("appointmentNotAdded");
                viewLoader.showAlert(appointmentNotAdded);
            }else{
                String appointmentNotUpdated = languages.getString("appointmentNotUpdated");
                viewLoader.showAlert(appointmentNotUpdated);
            }
        }
    }

    /**
     * Converts the values from the various Start and End combo boxes into date objects.
     *
     * This function needs to be moved to the DateHelper class.
     */
    private void convertStartAndEndValuesToDate() {
        String start,end,startHH,startMM,endHH,endMM,timeZone;

        start       = startDatePicker.getValue().toString();       //still need HH, MM, & timeZone to be complete
        end         = endDatePicker.getValue().toString();         //still need HH, MM, & timeZone to be complete
        startHH     = startTimeHHComboBox.getValue().toString();
        startMM     = startTimeMMComboBox.getValue().toString();

        endHH       = endTimeHHComboBox.getValue().toString();
        endMM       = endTimeMMComboBox.getValue().toString();

        timeZone    = timeZoneComboBox.getValue().toString();

        String startSS="00",endSS="00";

        //generate string for start & end
        String startString  = start + " " + startHH + ":" + startMM +":"+ startSS;
        String endString    = end   + " " + endHH   + ":" + endMM   +":"+ endSS;

        try {
            startDate = dateFormatter.parse(startString);
            endDate   = dateFormatter.parse(endString);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Checks both start and end dates to see if they overlap with any existing appointments for the customers.
     *
     * @param startDate     the start date of the appointment being checked against the database for overlap
     * @param endDate       the end date of the appointment being checked against the database for overlap
     * @param customerID    the customer id being check against the database for overlap
     * @return              TRUE if there is overlap
     * @throws SQLException
     */
    private Boolean checkOverlap(Date startDate, Date endDate, int customerID, int incomingApptId) throws SQLException {

        Boolean validTime = true;

        //get appointments by customer
        ObservableList<Appointment> appointments = ConnectDB.getAppointmentsForCustomerByCustomerID(customerID);

        if(appointments.isEmpty())
            validTime = true;

        //loop through appointments
        for(Appointment a : appointments) {
            String startDateAdjusted    = dateHelper.convertServerToUser(a.getStart());
            String endDateAdjusted      = dateHelper.convertServerToUser(a.getEnd());

            Date startDateAdj = dateHelper.stringToDate(startDateAdjusted);
            Date endDateAdj   = dateHelper.stringToDate(endDateAdjusted);

            //first ensure not same appointment, then check the rest
            if (a.getAppointmentID()!=incomingApptId) {

                if (startDate.after(startDateAdj) && startDate.before(endDateAdj)) {
                    validTime = false;
                }

                if (endDate.after(startDateAdj) && endDate.before(endDateAdj)) {
                    if (a.getAppointmentID() == incomingApptId) {
                        System.out.println("Same appointmentID");
                    }

                    validTime = false;
                }

                if (startDate.equals(startDateAdj)) {
                    validTime = false;
                }

                if (endDate.equals(startDateAdj)) {
                    validTime = false;
                }

                if (startDate.equals(endDateAdj)) {
                    validTime = false;
                }

                if (endDate.equals(endDateAdj)) {
                    validTime = false;
                }
            }
        }
        return validTime;
    }

    /**
     * Checks the start and end date against the business hours.
     *
     * @param startDate the start date being checked
     * @param endDate   the end date being checked
     * @return          TRUE if values fall within business hours, FALSE if values fall outside business hours
     */
    private Boolean checkBusinessHours(Date startDate, Date endDate) {
        Boolean success         = false,
                acceptableStart = false,
                acceptableEnd   = false;

        //get acceptable range based on start date
        Date min,max;

        ZoneId timezone = ZoneId.of(timeZoneComboBox.getSelectionModel().getSelectedItem().toString());

        //convert start&end to business for comparison
        String startDateString = dateHelper.adjustToTimeZone(startDate,timezone,dateHelper.businessTimeZoneId);
        startDate = ConnectDB.stringToDate(startDateString);
        String endDateString = dateHelper.adjustToTimeZone(endDate,timezone,dateHelper.businessTimeZoneId);
        endDate = ConnectDB.stringToDate(endDateString);

        String timeZoneSelection = timeZoneComboBox.getSelectionModel().getSelectedItem().toString();
        ZoneId apptZone = ZoneId.of(timeZoneSelection);

        String startHH, endHH;
        startHH = "08"; //represents 8am
        endHH   = "22"; //represents 10pm

        int startYear = startDate.getYear()+1900;
        int startMonth = startDate.getMonth()+1;
        int startDate1 = startDate.getDate();

        String minString = startYear + "-" + startMonth +"-"+ startDate1 + " " +startHH +":"+"00:00 @ "+ConnectDB.businessTimeZoneId;

        //convert minString to date
        try {
            min = dateFormatter.parse(minString);

            //set the max to the same day, but the end of the business day represented by endHH
            max = dateFormatter.parse(minString);
            max.setHours(Integer.parseInt(endHH));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        ZonedDateTime startZdt = ZonedDateTime.ofInstant(startDate.toInstant(), apptZone);

        //check if values are in-between min and max
        if((startDate.after(min) || startDate.equals(min)) && (startDate.equals(max) || startDate.before(max))){
            acceptableStart = true;
        }
        if((endDate.equals(min) || endDate.after(min)) && (endDate.before(max) || (endDate.equals(max)))){
            acceptableEnd = true;
        }

        //if both values are good return true;
        if(acceptableStart && acceptableEnd) {
            success = true;
        }

        return success;
    }

    /**
     * Initializes any GUI elements that would be null, gets all contacts and adds the names to a combo box,
     *
     */
    public void initialize() {

        if(ConnectDB.selectedAppointment!=null){
            appointment = ConnectDB.selectedAppointment;
        }

        contacts = FXCollections.observableArrayList();

        //get contacts
        contacts = getContacts();

        //initialize field, combo boxes, and date pickers
        contactComboBox = new ComboBox<Contact>();
        appointmentIDField = new TextField();
        appointmentTitleField = new TextField();
        appointmentDescriptionField = new TextField();
        appointmentLocationField = new TextField();
        appointmentTypeField = new TextField();
        startDatePicker = new DatePicker();
        endDatePicker = new DatePicker();
        startTimeHHComboBox = new ComboBox();
        startTimeMMComboBox = new ComboBox();
        endTimeHHComboBox = new ComboBox();
        endTimeMMComboBox = new ComboBox();
        userIDField = new TextField();
        customerIDField = new TextField();
        lastUpdatedByField = new TextField();
        createdByField = new TextField();
        createdDateField = new TextField();
        lastUpdatedField = new TextField();
        timeZoneLabel   = new Label();

        //populate contacts combo box
        for(Contact c : contacts){
            contactComboBox.getItems().add(c.getContactName());
        }

        //if updating a customer
        if(ConnectDB.selectedAppointment!=null) {

            appointmentIDField.setText("" + appointment.getAppointmentID());
            appointmentTitleField.setText(appointment.getTitle());
            appointmentDescriptionField.setText(appointment.getDescription());
            appointmentLocationField.setText(appointment.getLocation());
            appointmentTypeField.setText(appointment.getType());
            userIDField.setText(""+appointment.getUserID());
            customerIDField.setText(""+customerIDField);
            lastUpdatedByField.setText(appointment.getLastUpdateBy());
            createdByField.setText(appointment.getCreatedBy());

            String createDateText = DateHelper.convertServerToUser(appointment.getCreateDate());
            String lastUpdateText = DateHelper.convertServerToUser(appointment.getLastUpdate());

            createdDateField.setText(createDateText);
            lastUpdatedField.setText(lastUpdateText);

            //need to convert dates to users time zone first
            Date start = appointment.getStart(),
                 end   = appointment.getEnd();

            String startString = DateHelper.convertServerToUser(start);
            String endString   = DateHelper.convertServerToUser(end);

            start = ConnectDB.stringToDate(startString);
            end   = ConnectDB.stringToDate(endString);

            //get dates from appointment
            String startFormatted = ConnectDB.formatAppointmentDateForEdit(start);
            String endFormatted   = ConnectDB.formatAppointmentDateForEdit(end);

            //set date pickers
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
            startDatePicker.setValue(ld);

            ld = LocalDate.parse(endFormatted, currentDateFormat);
            endDatePicker.setValue(ld);

            //set HH & MM combo boxes
            String startHH = Integer.toString(appointment.getStart().getHours());
            String startMM = Integer.toString(appointment.getStart().getMinutes());
            String endHH = Integer.toString(appointment.getEnd().getHours());
            String endMM = Integer.toString(appointment.getEnd().getMinutes());
            startTimeHHComboBox.setValue(startHH);
            startTimeMMComboBox.setValue(startMM);
            endTimeHHComboBox.setValue(endHH);
            endTimeMMComboBox.setValue(endMM);

            //select the customers country in the country combo box
            contactComboBox.getSelectionModel().select(contact);
        }
    }

    /**
     * Gets the contacts from the database.
     *
     * @return ObservableList with the contacts from the database.
     */
    private ObservableList<Contact> getContacts() {
        ObservableList<Contact> contact = ConnectDB.getAllContacts();
        return contact;
    }

    /**
     * Sets the selected appointment.
     *
     * @param selectedAppointment Appointment object representing the selected appointment.
     */
    public void setAppointment(Appointment selectedAppointment) {
        appointment = selectedAppointment;
    }

    /**
     * Returns the user to Appointments screen.
     */
    public void returnToAppointments(){
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Checks if the specified date range overlaps with the user's availability.
     * This method first checks the overlap within the user's available times. If no overlap is found,
     * it then checks whether the date range falls within the user's periods of unavailability.
     *
     * @param startDate The start date of the period to check for overlap.
     * @param endDate The end date of the period to check for overlap.
     * @return TRUE : if the specified date range is within the user's available times or doesn't conflict with not available times
     *         FALSE: if it overlaps with the user's not available times
     */
	public Boolean checkForAvailabilityOverlap(Date startDate, Date endDate, ObservableList<Availability> availabilitiesList){

        Boolean overlap;

        overlap = doDatesOverlapWithAvailability(startDate, endDate, availabilitiesList);
//        System.out.println("overlap: "+ overlap);
		
        return overlap;
	}

    /**
     * Determines if the specified date range overlaps with any of the availabilities listed for a user.
     * The method checks each availability period and its repetitions against the provided date range.
     * If any overlap is found during the iterations of the repeating availability periods, the method returns true.
     *
     * @param startDate The start date of the date range to check for overlap.
     * @param endDate The end date of the date range to check for overlap.
     * @param availabilites A list of availability periods to compare against the date range.
     * @return TRUE : if there is an overlap with any of the user's availability periods considering their repetitions,
     *         FALSE: if there is no overlap.
     */
    public Boolean doDatesOverlapWithAvailability(Date startDate, Date endDate, ObservableList<Availability> availabilites){
		Boolean overlap = false;
		
		//loop through availabilities & calculate future dates to ensure that the availabilities
		//and start and end dates do not overlap
		for(Availability availability : availabilites){
			
			//if there are no other availabilities, go ahead and return true
			if(availabilites.isEmpty())
				return true;
			
			Date   availabilityStart           = availability.getStart();
			Date   availabilityEnd             = availability.getEnd();
			Date   availabilityRepeatEnd       = availability.getRepeatEndDate();
			String availabilityRepeatFrequency = availability.getRepeatFrequency();

            //adjust dates and times from availability object to user timezone
            // Adjust start and end dates to the server's timezone.
            String startDateString      = DateHelper.adjustToTimeZone(availabilityStart, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String endDateString        = DateHelper.adjustToTimeZone(availabilityEnd, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String repeatEndDateString  = DateHelper.adjustToTimeZone(availabilityRepeatEnd, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

            // Convert adjusted date strings back to Date objects.
            availabilityStart       = ConnectDB.stringToDate(startDateString);
            availabilityEnd         = ConnectDB.stringToDate(endDateString);
            availabilityRepeatEnd   = ConnectDB.stringToDate(repeatEndDateString);

            //initialize calendar instances
			Calendar newCalendarStart     = Calendar.getInstance();
			Calendar newCalendarEnd       = Calendar.getInstance();
			Calendar oldCalendarStart     = Calendar.getInstance();
			Calendar oldCalendarEnd       = Calendar.getInstance();
			Calendar oldCalendarRepeatEnd = Calendar.getInstance();
			
			// Set calendar times
			newCalendarStart.setTime(startDate);
			newCalendarEnd.setTime(endDate);
			oldCalendarStart.setTime(availabilityStart);
			oldCalendarEnd.setTime(availabilityEnd);
			oldCalendarRepeatEnd.setTime(availabilityRepeatEnd);

            Boolean noOverlap = true;

            //initial check overlap
//            System.out.println("Initial Overlap check: \n");
            noOverlap = !checkAvailabilityOverlap(newCalendarStart, newCalendarEnd, oldCalendarStart, oldCalendarEnd);

            Date s1 = newCalendarStart.getTime();
            Date e1 = newCalendarEnd.getTime();
            Date s2 = oldCalendarStart.getTime();
            Date e2 = oldCalendarEnd.getTime();

//            System.out.println(s1 +"\t"+ e1+"\t"+s2+"\t"+e2);
//            System.out.println("noOverlap: " +noOverlap);

            if(!noOverlap){
//                System.out.println("returning noOverlap: "+!noOverlap);
                return !noOverlap;
            }

			//check dates and then increment until the repeat end date has been met
			while(oldCalendarEnd.before(oldCalendarRepeatEnd) && noOverlap){

				//check for overlap
                noOverlap = !checkAvailabilityOverlap(newCalendarStart, newCalendarEnd, oldCalendarStart, oldCalendarEnd);

                //increment dates
				Calendar[] updatedDates = incrementCalendarDates(oldCalendarStart, oldCalendarEnd, oldCalendarRepeatEnd, availabilityRepeatFrequency);
				
				oldCalendarStart = updatedDates[0];
				oldCalendarEnd   = updatedDates[1];
			}
		}

        return overlap;
	}

    /**
     * Checks whether two date ranges overlap. This method compares two pairs of start and end dates
     * to determine if there is any overlap. An overlap is considered to occur if any part of one range
     * falls within the other, or if one range completely encompasses the other.
     *
     * @param newCalendarStart The start date of the first date range.
     * @param newCalendarEnd The end date of the first date range.
     * @param oldCalendarStart The start date of the second date range.
     * @param oldCalendarEnd The end date of the second date range.
     * @return {@code true} if the date ranges overlap in any way, {@code false} otherwise.
     */
    private Boolean checkAvailabilityOverlap(Calendar newCalendarStart, Calendar newCalendarEnd, Calendar oldCalendarStart, Calendar oldCalendarEnd) {
        Date start1 = newCalendarStart.getTime();
        Date end1   = newCalendarEnd.getTime();

        Date start2 = oldCalendarStart.getTime();
        Date end2   = oldCalendarEnd.getTime();

        // Check if one range starts or ends within the other range
        Boolean start1Between   = (start1.after(start2) && start1.before(end2));
        Boolean end1Between     = (end1.after(start2) && end1.before(end2));
        Boolean start2Between   = (start2.after(start1) && start2.before(end1));
        Boolean end2Between     = (end2.after(start1) && end2.before(end1));

        // Check if one range completely encompasses the other
        boolean start1BeforeAndEnd1After = start1.before(start2) && end1.after(end2);
        boolean start2BeforeAndEnd2After = start2.before(start1) && end2.after(end1);

        if(start1Between)
            System.out.println("start1Between" + "\tS1: " +start1.toString() + "\t" +start2.toString() + " \t"+ end2.toString());
        if(end1Between)
            System.out.println("end1Between" + "\tE1: " +end1.toString() + "\t" +start2.toString() + " \t"+ end2.toString());
        if(start2Between)
            System.out.println("start2Between" + "\tS2: " +start2.toString() + "\t" +start1.toString() + " \t"+ end1.toString());
        if(end2Between)
            System.out.println("end2Between"+ "\tE2: " +end2.toString() + "\t" +start1.toString() + " \t"+ end1.toString());
        if(start1BeforeAndEnd1After)
            System.out.println("start1BeforeAndEnd1After" + "\tS1: " +start1.toString() + "\t" +start2.toString() + " \tE1: "+ end1.toString() + "\t" + end2.toString());
        if(start2Between)
            System.out.println("start2BeforeAndEnd2After" + "\tS2: " +start2.toString() + "\t" +start1.toString() + " \tE2: "+ end2.toString() + "\t" + end1.toString());

        // Return true if any of the conditions indicate overlap
        return start1Between || end1Between || start2Between || end2Between ||
                start1BeforeAndEnd1After || start2BeforeAndEnd2After;
    }

    /**
     * Increments the provided start and end calendars based on the specified repeat frequency.
     * The method adjusts the date values of the calendars and ensures that the end date does not
     * exceed the specified repeat end date. Supported frequencies include daily, weekly, monthly,
     * yearly, and none.
     *
     * @param start The calendar representing the start date to increment.
     * @param end The calendar representing the end date to increment.
     * @param repeatEnd The calendar representing the limit beyond which the end date should not be set.
     * @param repeatFrequency The frequency of the increment, e.g., "daily", "weekly", "monthly", "yearly", "none".
     * @return An array of two calendars, where the first element is the incremented start date and
     *         the second is the incremented (or adjusted) end date.
     * @throws IllegalArgumentException If the repeat frequency is not one of the expected values.
     */
    private Calendar[] incrementCalendarDates(Calendar start, Calendar end, Calendar repeatEnd, String repeatFrequency) {
		
		switch (repeatFrequency) {
			case "daily":
				start.add(Calendar.DATE, 1);
				end.add(Calendar.DATE, 1);
				break;
			case "weekly":
				start.add(Calendar.WEEK_OF_YEAR, 1);
				end.add(Calendar.WEEK_OF_YEAR, 1);
				break;
			case "monthly":
				start.add(Calendar.MONTH, 1);
				end.add(Calendar.MONTH, 1);
				break;
			case "yearly":
				start.add(Calendar.YEAR, 1);
				end.add(Calendar.YEAR, 1);
				break;
			case "none":
				// Do nothing, no increment needed
				break;
			default:
				throw new IllegalArgumentException("Invalid repeat frequency: " + repeatFrequency);
		}
		
		// Check if the updated end date exceeds the repeat end date
		if (end.after(repeatEnd)) {
			end.setTime(repeatEnd.getTime()); // Set end date to the repeat end date
		}
		
		// Return both start and end dates in an array
		return new Calendar[] {start, end};
	}
}