package main.stitesc195.Controller;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import main.stitesc195.Model.CustomerReport;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "CustomerReports" screen.
 * Launches different screens, sets texts on GUI elements based on user selection, and displays report in TableView.
 *
 * @author Bradley Stites
 */
public class CustomerReports implements Initializable {

    /**
     * ObservableList to store the customer report for display
     */
    ObservableList<CustomerReport> CustomerReports = FXCollections.observableArrayList();

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * Button for returning to previous screen, ReportSelection.
     */
    @FXML
    private Button backButton;

    /**
     * TableView for displaying report.
     */
    @FXML
    private TableView customerReportTableView;

    /**
     * TableColumn used to store month value of report
     */
    @FXML
    TableColumn<CustomerReport, String> monthColumn;

    /**
     * TableColumn used to store year value of report
     */
    @FXML
    TableColumn<CustomerReport, String> yearColumn;

    /**
     * TableColumn used to store type value of report
     */
    @FXML
    TableColumn<CustomerReport, String> typeColumn;

    /**
     * TableColumn used to store total value of report
     */
    @FXML
    TableColumn<CustomerReport, Integer> totalColumn;

    /**
     * Initializes the CustomerReports class.
     *
     * Gets the report from the database and displays on the table view and sets the text on GUI elements to appropriate
     * language.
     *
     * @param url               The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle    The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        viewLoader = new ViewLoader();

        //get customer appointment reports
        CustomerReports = ConnectDB.getCustomerAppointmentsReport();

        //attach customer reports to the table view
        customerReportTableView.getItems().clear();

        addReportsToTableView();

        customerReportTableView.getItems().setAll(CustomerReports);
        customerReportTableView.refresh();

        setLanguage();
    }

    /**
     * Sets the text of the various GUI elements to the appropriate language.
     */
    public void setLanguage(){
        String month, year, type, total;

        month = languages.getString("month");
        year = languages.getString("year");
        type = languages.getString("type");
        total = languages.getString("total");

        monthColumn.setText(month);
        yearColumn.setText(year);
        typeColumn.setText(type);
        totalColumn.setText(total);
    }

    /**
     * sets the cell value factories for the table view
     */
    private void addReportsToTableView() {
        monthColumn.setCellValueFactory(cellData -> Bindings.createStringBinding(() -> cellData.getValue().getMonth()));
        yearColumn.setCellValueFactory( cellData -> Bindings.createStringBinding(() -> cellData.getValue().getYear()));
        typeColumn.setCellValueFactory( cellData -> Bindings.createStringBinding(() -> cellData.getValue().getType()));
        totalColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getTotal()).asObject());
    }

    /**
     *  Returns the user to the ReportSelection screen.
     *
     * @throws SQLException if there is a SQLException.
     * @throws IOException if there is an IOException.
     */
    public void backButton() throws SQLException, IOException {
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("ReportSelection", currentStage);
    }
}
