package main.stitesc195.Controller;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.*;

import javafx.stage.Stage;
import main.stitesc195.Model.Contact;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Search;


/**
 * Contains the logic and variables for the "Appointments" screen, handles errors and prompts for various conditions,
 * launches different screens, and sets texts on GUI elements based on user selection in previous screen "Login",
 * shows various stages of Appointments depending on the state of the various toggles and buttons.
 *
 * @author Bradley Stites
 */
public class Appointments implements Initializable {

    /**
     * Represents the Appointments TableView on the Appointments screen.
     */
    @FXML
    private TableView appointmentsTable;

    /**
     * Represents the "Add" button on the Appointments screen.
     * When clicked, this button navigates the user to the CustomerDetails.fxml screen, which allows a user to
     * add a new customer.
     */
    @FXML
    private Button addButton;

    /**
     * Represents the "View/Modify" button on the Appointments screen.
     * When clicked, this button navigates the user to the CustomerDetails.fxml screen, which allows a user to
     * modify an existing customer.
     */
    @FXML
    private Button modifyButton;

    /**
     * Represents the "Delete" button on the Appointments screen.
     * When clicked, various checks are performed to ensure deletion is possible, then deletes any selected
     * appointment upon confirmation.
     */
    @FXML
    private Button deleteButton;

    /**
     * Represents the "Back" button on the Appointments screen.
     * When clicked, this button navigates the user back to the Appointments.fxml screen, displaying all appointments
     */
    @FXML
    private Button backButton;

    /**
     * Represents the "Search History" button on the Appointments screen.
     * When clicked, this button navigates the user to the Searches.fxml screen, which allows a user to
     * view previous searches, favorite searches, and more.
     */
    @FXML
    private Button searchHistoryButton;

    /**
     * Represents the "Appointment ID" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, Integer> IDColumn;

    /**
     * Represents the "Title" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> TitleColumn;

    /**
     * Represents the "Appointment Type" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> TypeColumn;

    /**
     * Represents the "Appointment Description" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> DescriptionColumn;

    /**
     * Represents the "Appointment Start" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> StartColumn;

    /**
     * Represents the "Appointment End" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> EndColumn;

    /**
     * Represents the "Customer ID" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, Integer> CustomerIDColumn;

    /**
     * Represents the "User ID" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, Integer> UserIDColumn;

    /**
     * Represents the "Location" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> LocationColumn;

    /**
     * Represents the "Contact Name" Column on the Appointments Table.
     */
    @FXML
    TableColumn<Appointment, String> ContactNameColumn;

    /**
     * Represents a toggle group for holding the various Radio Buttons used to filter through appointments by date range.
     */
    @FXML
    ToggleGroup filterToggle;

    /**
     * Radio button for viewing appointments on a monthly basis.
     */
    @FXML
    RadioButton viewMonthly;

    /**
     * Radio button for viewing appointments on a weekly basis.
     */
    @FXML
    RadioButton viewWeekly;

    /**
     * Radio button for viewing all appointments.
     */
    @FXML
    RadioButton viewAll;

    /**
     * Button for advancing to the next page of appointments.
     */
    @FXML
    Button nextButton;

    /**
     * Button for returning to the previous page of appointments.
     */
    @FXML
    Button prevButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * ObservableList to store all appointments.
     */
    ObservableList<Appointment> appointments = FXCollections.observableArrayList();

    /**
     * ObservableList to store all contacts.
     */
    ObservableList<Contact>     contacts     = FXCollections.observableArrayList();

    /**
     * DateHelper used to convert dates to and from various time zones
     */
    DateHelper dateHelper;

    /**
     * Appointment used to store the selected appointment.
     */
    private Appointment selectedAppointment = new Appointment();

    /**
     * Date value to store the currentDate.
     */
    Date currentDate;

    /**
     * Date value to store the minimum value for the range
     */
    Date rangeMin;

    /**
     * Date value to store the max value for the range
     */
    Date rangeMax;

    /**
     * Date value to store the first date in the appointments as an absolute minimum point for all ranges.
     */
    Date firstDateInAppointments;

    /**
     * Date value to store the first date in the appointments as an absolute maximum point for all ranges.
     */
    Date lastDateInAppointments;

    /**
     * Search object to hold the values for the selected search used to filter the results of the appointments screen.
     */
    Search selectedSearch;

    /**
     * Initializes the Appointments Screen.
     * Sets the default radio button to "ViewAll" and sets the display text of GUI elements to match language selection.
     *
     * @param url            the location used to resolve relative paths for the root object or null if the location is not known
     * @param resourceBundle resourceBundle the resources used to localize the root object or null if the root object was not localized
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //initialize ViewLoader and DateHelper
        viewLoader = new ViewLoader();
        dateHelper = new DateHelper();

        //create toggle group for radio buttons and assign them to the group.
        filterToggle = new ToggleGroup();
        viewMonthly.setToggleGroup(filterToggle);
        viewWeekly.setToggleGroup(filterToggle);
        viewAll.setToggleGroup(filterToggle);

        //set the "View All" toggle to be the default when loading the Appointments view
        viewAll.setSelected(true);

        //get all appointments and contacts
        try{
            contacts = ConnectDB.getAllContacts();

            appointments = ConnectDB.getAppointmentsForActiveUser_OrderedByStartASC();
            updateAppointmentsTable(appointments);

        } catch (SQLException e){
            e.printStackTrace();
        }

        //set the first & lastDateInAppointments
        if (!appointments.isEmpty()) {
            Appointment firstAppointment = appointments.get(0);
            Appointment lastAppointment  = appointments.get(appointments.size() - 1);

            firstDateInAppointments = firstAppointment.getStart();
            lastDateInAppointments  = lastAppointment.getStart();
        }

        if(ConnectDB.selectedSearch!=null){
            try {
                selectedSearch = ConnectDB.selectedSearch;
                System.out.println("selected search not null");
                appointments = ConnectDB.searchAppointments(selectedSearch);
                updateAppointmentsTable(appointments);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

        //set the headers on the columns to match the correct language
        setLanguage();
        viewAll();
    }

    /**
     * Sets the text of the various GUI Elements on the Appointments screen to match the language selected.
     */
    private void setLanguage() {
        String appointmentId, title, description, location, contact, type, start, end, customerId, userId,
                add,viewModify, delete, back, viewByMonth, viewByWeek, viewAll, next, prev;

        // Get values from properties file
        appointmentId = languages.getString("appointmentId");
        title = languages.getString("title");
        description = languages.getString("description");
        location = languages.getString("location");
        contact = languages.getString("contact");
        type = languages.getString("type");
        start = languages.getString("start");
        end = languages.getString("end");
        customerId = languages.getString("customerId");
        userId = languages.getString("userId");
        add = languages.getString("add");
        viewModify = languages.getString("view");
        delete = languages.getString("delete");
        back = languages.getString("back");
        viewByMonth = languages.getString("viewByMonth");
        viewByWeek = languages.getString("viewByWeek");
        viewAll = languages.getString("viewAll");
        next = languages.getString("next");
        prev = languages.getString("prev");


        IDColumn.setText(appointmentId);
        TitleColumn.setText(title);
        DescriptionColumn.setText(description);
        LocationColumn.setText(location);
        ContactNameColumn.setText(contact);
        TypeColumn.setText(type);
        StartColumn.setText(start);
        EndColumn.setText(end);
        CustomerIDColumn.setText(customerId);
        UserIDColumn.setText(userId);
        addButton.setText(add);
        modifyButton.setText(viewModify);
        deleteButton.setText(delete);
        backButton.setText(back);
        viewMonthly.setText(viewByMonth);
        viewWeekly.setText(viewByWeek);
        this.viewAll.setText(viewAll);
        nextButton.setText(next);
        prevButton.setText(prev);
    }

    /**
     *  Populates the Appointments' table with the appointments passed in as an Observable List. Sets the appropriate cell
     *  factories to display appointment information and converts date/time values from the server time to the user's local
     *  time zone. Establishes relationship between contact id and customer name, which is used to display the contact name
     *  in the appointment table.
     *
     * @param appointments An ObservableList of Appointment objects containing all appointments to be displayed.
     */
    public void updateAppointmentsTable(ObservableList<Appointment> appointments){
        IDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        TitleColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> cellData.getValue().getTitle()));
        DescriptionColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> cellData.getValue().getDescription()));
        LocationColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> cellData.getValue().getLocation()));
        TypeColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> cellData.getValue().getType()));

        // Create a Map<Integer, String> to store the relationship between contact ID and customer name
        Map<Integer, String> contactNameMap = new HashMap<>();

        // store a key pair of contact id and contact name in the map
        for (Contact contact : contacts) {
            contactNameMap.put(contact.getId(), contact.getName());
        }

//        System.out.println(contactNameMap);

        /* Lambda Expression Explanation: setting the cell value factories reduced the amount of lines I had to use to
         * accomplish the same task and makes the code cleaner looking. This particular section modifies the
         * appointmentUserIDColumn to retrieve the customer name from the contactNameMap
         */
        ContactNameColumn.setCellValueFactory(cellData -> {
            int contactID = cellData.getValue().getContactID();
            String contactName = contactNameMap.get(contactID);
            return new SimpleStringProperty(contactName);
        });

        /* Lambda Expression Explanation: setting the cell value factories reduced the amount of lines I had to use to accomplish the same task
         * and makes the code cleaner looking. */
        StartColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> DateHelper.convertServerToUser(cellData.getValue().getStart())));
        EndColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> DateHelper.convertServerToUser(cellData.getValue().getEnd())));
        CustomerIDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getCustomerID()).asObject());
        UserIDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getUserID()).asObject());

        //clear the table and set the table to the incoming appointments object
        appointmentsTable.getItems().clear();
        appointmentsTable.getItems().setAll(appointments);
        appointmentsTable.refresh();

        if(rangeMin!=null){
            // Update Previous and Next Button Navigation
            updateNavigationButtons();
        }
    }

    /**
     * Deletes the selected appointment from the table if confirmed by the user.
     */
    public void deleteAppointment(){
        //get appointment selection from table
        selectedAppointment = (Appointment) appointmentsTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedAppointment = selectedAppointment;

        String noSelectedAppointment  = languages.getString("noSelectedAppointment");

        //ensure not null
        if (selectedAppointment == null) {
            viewLoader.showAlert(noSelectedAppointment);
            return;
        }

        // Confirm Deletion
        String confirmDeletion = languages.getString("confirmDeleteAppointment");
        boolean confirmed = viewLoader.confirmPrompt(confirmDeletion);

        if(confirmed){
            //proceed with deletion
            int success = ConnectDB.deleteAppointment(selectedAppointment);

            if(success>0){
                String appointmentDeleted  = languages.getString("appointmentDeleted");
                String appointmentId       = languages.getString("appointmentId");
                String type                = languages.getString("type");
                String appointmentDetails  = appointmentId+": "+selectedAppointment.getId()+"\n"+
                        type         +": "+selectedAppointment.getType();
                viewLoader.showAlert(appointmentDeleted+"\n\n"+appointmentDetails);
                appointments.remove(selectedAppointment);

                //refresh appointments
                updateAppointmentsTable(appointments);

            }else{
                String appointmentNotDeleted = languages.getString("appointmentNotDeleted");
                viewLoader.showAlert(appointmentNotDeleted);
            }
        }
    }

    /**
     * Returns the user to the "MainScreen.fxml" screen.
     */
    public void BackButton(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("MainScreen", currentStage);
    }

    /**
     * Sends user to the "AppointmentDetails.fxml" screen to create a new appointment.
     */
    public void addAppointment(){
        ConnectDB.selectedAppointment = null;
        currentStage = (Stage) addButton.getScene().getWindow();
        viewLoader.loadFXML("AppointmentDetails", currentStage);
    }

    /**
     * Sends the user to the "AppointmentDetails.fxml" screen to update an existing appointment.
     */
    public void editAppointment(){
        String noSelectedAppointment  = languages.getString("noSelectedAppointment");

        //get appointment selection from table
        selectedAppointment = (Appointment) appointmentsTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedAppointment = selectedAppointment;

        //ensure not null
        if (selectedAppointment == null) {
            viewLoader.showAlert(noSelectedAppointment);
            return;
        }
        else{
            //load selected appointment into form
            AppointmentDetails appointmentDetails = new AppointmentDetails();
            appointmentDetails.setAppointment(selectedAppointment);
            appointmentDetails.initialize();

            currentStage = (Stage) modifyButton.getScene().getWindow();
            viewLoader.loadFXML("AppointmentDetails", currentStage);
        }
    }

    /**
     * Sets the selected appointment to the input parameter.
     *
     * @param appointment An appointment object representing the selected appointment.
     */
    public void setAppointment(Appointment appointment){
        selectedAppointment = appointment;
    }

    /**
     * Sets other radio toggles to false, disables all buttons, and displays all possible appointments on the table.
     */
    public void viewAll(){
        rangeMin=null;
        rangeMax=null;

        //set other radios to false
        viewMonthly.setSelected(false);
        viewWeekly.setSelected(false);

        //disable next and previous buttons
        setButtonEnabled(nextButton, false);
        setButtonEnabled(prevButton, false);

        updateAppointmentsTable(appointments);
    }

    /**
     * Sets other radio toggles to false, establishes a minimum date and maximum date based on current date, sets previous
     * and next buttons based on whether there are date values in either direction, and sets the table view to display
     * filtered list. This filtered list will display a months worth of appointments at a time.
     */
    public void viewMonthly(){
        //set other radios to false
        viewAll.setSelected(false);
        viewWeekly.setSelected(false);

        //get current date
        try {
            currentDate = ConnectDB.getDateFromServer();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //set Range
        setRange(currentDate, false);

        //get range
        ObservableList<Appointment> filteredList = getRange();

        //set the tables data to be appointmentsByMonth
        updateAppointmentsTable(filteredList);
    }

    /**
     * Sets other radio toggles to false, establishes a minimum date and maximum date based on current date, sets previous
     * and next buttons based on whether there are date values in either direction, and sets the table view to display
     * filtered list. This filtered list will display a weeks worth of appointments at a time.
     */
    public void viewWeekly(){
        //set other radios to false
        viewMonthly.setSelected(false);
        viewAll.setSelected(false);

        //get current date
        try {
            currentDate = ConnectDB.getDateFromServer();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //set range
        setRange(currentDate, true);

        //get range
        ObservableList<Appointment> filteredList = getRange();

        //set the table data to appointmentsByWeek and refresh
        updateAppointmentsTable(filteredList);
    }

    /**
     * Enables previous button, determines new min and max values for filtering dates based on selected toggle,
     * disables the next button if there are no further dates remaining, displays filtered list on table view.
     */
    public void nextButton() {

        ObservableList<Appointment> filteredList = FXCollections.observableArrayList();

        //enable previous button
        setButtonEnabled(prevButton, true);

        //determine which toggle is pressed
        if(viewMonthly.isSelected()){
            //set the new range
            addMonth(1);

            //get range
            filteredList = getRange();
        }

        if (viewWeekly.isSelected()){
            //set the range
            addWeek(1);

            //get range
            filteredList = getRange();
        }

        // Update previous or next buttons to suit data
        updateNavigationButtons();

        //clear table and set to filteredList
        updateAppointmentsTable(filteredList);
    }

    /**
     * adds a value of qty to the rangeMin in terms of months; can be either positive or negative value
     *
     * @param qty the amount of months to be added or subtracted
     */
    private void addMonth(int qty) {
        //set the range to +qty month
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(rangeMin);
        calendar.add(Calendar.MONTH, qty);
        rangeMin=calendar.getTime();
        setRange(rangeMin, false);
    }

    /**
     * adds a value of qty to the rangeMin in terms of weeks; can be either positive or negative value
     *
     * @param qty the amount of weeks to be added or subtracted
     */
    private void addWeek(int qty){
        //set the range to +qty weeks
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(rangeMin);
        calendar.add(Calendar.WEEK_OF_YEAR, qty);

        rangeMin=calendar.getTime();
        System.out.println("new Min: "+rangeMin);
        setRange(rangeMin, true);
    }

    /**
     * Enables next button, determines new min and max values for filtering dates based on selected toggle,
     * disables the prev button if there are no further dates remaining, displays filtered list on table view.
     */
    public void prevButton(){
        ObservableList<Appointment> filteredList;

        if(viewMonthly.isSelected()){
            //set new min and max values
            addMonth(-1);
        }

        if (viewWeekly.isSelected()){
            //set new min and max values
            addWeek(-1);
        }

        //get range
        filteredList = getRange();

        // Update previous or next buttons to suit data
        updateNavigationButtons();

        //clear table and set the table data to filteredList
        updateAppointmentsTable(filteredList);
    }

    /**
     * Enables or disables a button by toggling setDisable and setVisible.
     *
     * @param button    The button to be enabled or disabled.
     * @param enabled   A boolean value representing whether a button should be enabled or not.
     */
    private void setButtonEnabled(Button button, boolean enabled) {
        button.setDisable(!enabled);
        button.setVisible(enabled);
    }

    /**
     * Sorts through the appointments list and adds any values that fall within the min and max values to a filtered list
     * to be returned.
     *
     * @return    appointments that fall within the min and max
     */
    public ObservableList<Appointment> getRange(){
        ObservableList<Appointment> filteredList;

        //Lambda expression simplifies the returning of values to a filtered list
        filteredList = appointments.filtered(appointment ->
                appointment.getStart().compareTo(rangeMin) >= 0 && appointment.getStart().compareTo(rangeMax) <= 0);

        appointmentsTable.getItems().clear();

        return filteredList;
    }

    /**
     * This method updates the state of the previous and next buttons based on the availability of appointments in the
     * corresponding direction.
     */
    public void updateNavigationButtons(){

        //boolean variables representing the conditions of dates in ranges beyond the current range from either direction
        boolean hasPrevious = false;
        boolean hasNext = false;

        // Iterate through appointments and check if there are any that fall outside the range
        for (Appointment appointment : appointments) {
            Date start = appointment.getStart();

            System.out.println("Appointment Start: "+start + "\tRangeMin: "+rangeMin+"\tRangeMax: "+rangeMax);

            // Check if the appointment starts before rangeMin
            if (start.before(rangeMin)) {
                hasPrevious = true;
            }

            // Check if the appointment starts after rangeMax
            if (start.after(rangeMax)) {
                hasNext = true;
            }
        }

        // Update button state based on the appointment range
        setButtonEnabled(prevButton, hasPrevious);
        setButtonEnabled(nextButton, hasNext);
    }

    /**
     * sets the global variables of rangeMin and rangeMax, based on the incoming date variable to match either a week
     * or month span of time
     *
     * @param date     date used to set the range
     * @param isWeekly true or false, t= is weekly, f=monthly
     */
    public void setRange(Date date, boolean isWeekly) {

        //create a calendar instance and set the time to the incoming date
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        //create a calendar for the minimum value based on the incoming date
        Calendar minCalendar = Calendar.getInstance();
        minCalendar.setTime(date);

        //create a calendar for the max value
        Calendar maxCalendar = Calendar.getInstance();

        //set the min & max date based on the condition of isWeekly
        if (isWeekly) {
            minCalendar.set(Calendar.DAY_OF_WEEK, minCalendar.getFirstDayOfWeek());
            maxCalendar.setTime(minCalendar.getTime());
            maxCalendar.add(Calendar.DAY_OF_WEEK, 6);
        } else {
            minCalendar.set(Calendar.DAY_OF_MONTH, 1);
            maxCalendar.setTime(minCalendar.getTime());
            maxCalendar.set(Calendar.DAY_OF_MONTH, maxCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));

            System.out.println("Setting calendar to month value");
        }

        //set the time of the day on the min calendar to the earliest possible time.
        minCalendar.set(Calendar.HOUR_OF_DAY, 0);
        minCalendar.set(Calendar.MINUTE, 0);
        minCalendar.set(Calendar.SECOND, 0);
        minCalendar.set(Calendar.MILLISECOND, 0);

        //set the time of the day on the max calendar to the latest possible time
        maxCalendar.set(Calendar.HOUR_OF_DAY, 23);
        maxCalendar.set(Calendar.MINUTE, 59);
        maxCalendar.set(Calendar.SECOND, 59);
        maxCalendar.set(Calendar.MILLISECOND, 999);

        //set the range min and range max to the calendar time
        rangeMin = minCalendar.getTime();
        rangeMax = maxCalendar.getTime();

        //update minCalendar with new Date
        minCalendar.setTime(date);

        System.out.println("rangeMax: " +rangeMax);

        if (isWeekly) {
            while (maxCalendar.getTime().before(minCalendar.getTime())) {
                maxCalendar.add(Calendar.WEEK_OF_YEAR, 1);
                rangeMax = maxCalendar.getTime();
            }
        } else {
            while (maxCalendar.getTime().before(minCalendar.getTime())) {
                maxCalendar.add(Calendar.MONTH, 1);
                rangeMax = maxCalendar.getTime();
            }
        }
    }

    /**
     * Returns the user to the "Searches.fxml" screen.
     */
    public void searchHistory(){
        currentStage = (Stage) searchHistoryButton.getScene().getWindow();
        viewLoader.loadFXML("Searches", currentStage);
    }

    /**
     * Sets the selected search.
     *
     * @param selectedSearch  The search selected.
     */
    public void setSearch(Search selectedSearch) throws SQLException {
        //set selected search object
        this.selectedSearch = selectedSearch;
    }

    /**
     * sets the selected search and loads the details on the view
     * @param selectedSearch    the search to information to be loaded and parsed
     */
    public void loadDetails(Search selectedSearch) throws SQLException {

        setSearch(selectedSearch);

        try {
            // get appointments based on search
            appointments = ConnectDB.searchAppointments(selectedSearch);

            //load appointments into table
            if(!appointments.isEmpty())
                updateAppointmentsTable(appointments);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void initialize() {
    }
}