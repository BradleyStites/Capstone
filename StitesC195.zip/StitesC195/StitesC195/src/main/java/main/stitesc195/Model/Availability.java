package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

/**
 * The Availability class represents an Availability object for users to limit appointment times.
 */
public class Availability {

    /**
     * int representing the unique id value for the availability
     */
    private int availabilityID;

    /**
     * Int representing the user id for the appointment.
     */
    private int userID;

    /**
     * String representing the status for the availability.
     * Possible values include: "Available" & "Not Available"
     */
    private String status;

    /**
     * String representing the details of the availability.
     */
    private String details;

    /**
     * Timestamp representing the start value of the appointment.
     */
    private Date start;

    /**
     * Timestamp representing the end value of the appointment.
     */
    private Date end;

    /**
     * String representing the frequency the availability is repeated.
     * Possible values include: "Daily", "Weekly", "Monthly", "Yearly", & "None"
     */
    private String repeat_frequency;

    /**
     * Timestamp representing the end of the repetitions for this availability
     */
    private Date repeat_end_date;

    /**
     * Constructs an empty 'Advanced Search' object.
     */
    public Availability() {
    }

    /**
     * Constructs an Availability object with the given parameters.
     *
     * @param availabilityID  	The availabilities' unique identifier.
     * @param userID          	The id for the availabilies' user.
     * @param status    		The status of the availability.
     * @param details       	The details of the availability.
     * @param start          	The start of the availability range.
     * @param end            	The end   of the availability range.
     * @param repeat_frequency  The frequency the availability repeats.
     * @param repeat_end_date   The date at which this availability ends.
     */
    public Availability(int availabilityID, int userID, String status, String details, Date start, Date end, String repeat_frequency, Date repeat_end_date) {
        setAvailabilityID(availabilityID);
        setUserID(userID);
        setStatus(status);
        setDetails(details);
        setStart(start);
        setEnd(end);
        setRepeatFrequency(repeat_frequency);
        setRepeatEndDate(repeat_end_date);
    }

    /**
     * returns the id of the availability.
     * @return the id of the availability.
     */
    public int getAvailabilityID(){
        return availabilityID;
    }

    /**
     * returns the id of the user for the availabily.
     * @return the id of the user for the availabily.
     */
    public int getUserID(){
        return userID;
    }

    /**
     * returns the status of the availability.
     * @return the availabilities' status
     */
    public String getStatus(){
        return status;
    }

    /**
     * returns the availabilities' details.
     * @return details for the availability.
     */
    public String getDetails(){
        return details;
    }

    /**
     * returns the start value for the appointment.
     * @return the start date for the appointment.
     */
    public Date getStart(){
        return start;
    }

    /**
     * returns the end value for the appointment.
     * @return the end value for the appointment.
     */
    public Date getEnd(){
        return end;
    }

    /**
     * returns the repeat_end_date value for the availability.
     * @return the repeat_end_date value for the availability.
     */
    public Date getRepeatEndDate(){
        return repeat_end_date;
    }

    /**
     * returns the frequency for the availability repitition.
     * @return the frequency for the repetition of the availabily.
     */
    public String getRepeatFrequency(){
        return repeat_frequency;
    }

    /**
     * sets the availability id
     * @param id the availability id to be set
     */
    public void setAvailabilityID(int id){
        this.availabilityID = id;
    }

    /**
     * sets the user id for the availability.
     * @param id user id being set.
     */
    public void setUserID(int id){
        this.userID = id;
    }

    /**
     * sets the status for the availability
     * @param status the status to be set
     */
    public void setStatus(String status){
        this.status = status;
    }

    /**
     * sets the details for the availability.
     * @param details The details to be set.
     */
    public void setDetails(String details){
        this.details = details;
    }

    /**
     * sets the frequency of repitition for the availability.
     * @param frequency the frequency to be set
     */
    public void setRepeatFrequency(String frequency){
        this.repeat_frequency = frequency;
    }

    /**
     * set the start date for the appointment for the search.
     *
     * @param start the start date for the appointment for the search.
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * set the end date for the appointment.
     * @param end the end date for the appointment.
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * set the repeat end date for the availabily.
     * @param end the repeat_end_date for the availability.
     */
    public void setRepeatEndDate(Date end) {
        this.repeat_end_date = end;
    }

    /**
     * prints out availability information. Used to debug problems in the code.
     * @return String containing information regarding an availability.
     */
    public String printAvailabilityInformation() {

        //create a dateHelper object to manage the display of the date/time variables
        DateHelper dateHelper = new DateHelper();

        //original values
        String startString, endString, repeatEndDateString;

        startString      	= dateHelper.stringDateToFormatForSQL(start);
        endString        	= dateHelper.stringDateToFormatForSQL(end);
        repeatEndDateString = dateHelper.stringDateToFormatForSQL(repeat_end_date);

        String output =     availabilityID      +", '"   + userID      + "', '" +  startString    + "', '" +  endString
                + "', '" + status + "', '" + repeat_frequency + "', '" + repeatEndDateString + "', '" + details + "'";

        System.out.println(output);

        return output;
    }
}
