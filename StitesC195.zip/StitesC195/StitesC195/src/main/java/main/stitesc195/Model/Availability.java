package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;
import java.util.Date;

/**
 * The Availability class represents an Availability object for users to limit appointment times.
 */
public class Availability {

    /**
     * int representing the unique id value for the availability
     */
    private int id;

    /**
     * Int representing the user id for the availability.
     */
    private int userID;

    /**
     * String representing the status for the availability.
     * Possible values include: "Available" & "Not Available"
     */
    private String status;

    /**
     * String representing the details of the availability.
     */
    private String details;

    /**
     * Timestamp representing the start value of the appointment.
     */
    private Date start;

    /**
     * Timestamp representing the end value of the appointment.
     */
    private Date end;

    /**
     * String representing the frequency the availability is repeated.
     * Possible values include: "Daily", "Weekly", "Monthly", "Yearly", & "None"
     */
    private String frequency;

    /**
     * Timestamp representing the end of the repetitions for this availability
     */
    private Date repeatEnd;

    /**
     * Constructs an empty 'Availability' object.
     */
    public Availability() {
    }

    /**
     * Constructs an Availability object with the given parameters.
     *
     * @param id  	The availabilities' unique identifier.
     * @param userID          	The user id for the availability.
     * @param status    		The status of the availability.
     * @param details       	The details of the availability.
     * @param start          	The start of the availability range.
     * @param end            	The end   of the availability range.
     * @param frequency         The frequency the availability repeats.
     * @param repeatEnd         The date at which this availability ends.
     */
    public Availability(int id, int userID, String status, String details, Date start, Date end, String frequency, Date repeatEnd) {
        setId(id);
        setUserID(userID);
        setStatus(status);
        setDetails(details);
        setStart(start);
        setEnd(end);
        setFrequency(frequency);
        setRepeatEnd(repeatEnd);
    }

    /**
     * returns the id of the availability.
     * @return the id of the availability.
     */
    public int getId(){
        return id;
    }

    /**
     * returns the id of the user for the availability.
     * @return the id of the user for the availability.
     */
    public int getUserID(){
        return userID;
    }

    /**
     * returns the status of the availability.
     * @return the availabilities' status
     */
    public String getStatus(){
        return status;
    }

    /**
     * returns the availabilities' details.
     * @return details for the availability.
     */
    public String getDetails(){
        return details;
    }

    /**
     * returns the start value for the appointment.
     * @return the start date for the appointment.
     */
    public Date getStart(){
        return start;
    }

    /**
     * returns the end value for the appointment.
     * @return the end value for the appointment.
     */
    public Date getEnd(){
        return end;
    }

    /**
     * returns the repeat_end_date value for the availability.
     * @return the repeat_end_date value for the availability.
     */
    public Date getRepeatEnd(){
        return repeatEnd;
    }

    /**
     * returns the frequency for the availability repetition.
     * @return the frequency for the repetition of the availability.
     */
    public String getFrequency(){
        return frequency;
    }

    /**
     * sets the availability id
     * @param id the availability id to be set
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the user id for the availability.
     * @param id user id being set.
     */
    public void setUserID(int id){
        this.userID = id;
    }

    /**
     * sets the status for the availability
     * @param status the status to be set
     */
    public void setStatus(String status){
        this.status = status;
    }

    /**
     * sets the details for the availability.
     * @param details The details to be set.
     */
    public void setDetails(String details){
        this.details = details;
    }

    /**
     * sets the frequency of repetition for the availability.
     * @param frequency the frequency to be set
     */
    public void setFrequency(String frequency){
        this.frequency = frequency;
    }

    /**
     * set the start date for the appointment for the search.
     *
     * @param start the start date for the appointment for the search.
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * set the end date for the appointment.
     * @param end the end date for the appointment.
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * set the repeat end date for the availability.
     * @param end the repeat_end_date for the availability.
     */
    public void setRepeatEnd(Date end) {
        this.repeatEnd = end;
    }

    /**
     * prints out availability information. Used to debug problems in the code.
     * @return String containing information regarding an availability.
     */
    public String printAvailabilityInformation() {

        //original values
        String startString, endString, repeatEndString;

        startString     = DateHelper.stringDateToFormatForSQL(start);
        endString       = DateHelper.stringDateToFormatForSQL(end);
        repeatEndString = DateHelper.stringDateToFormatForSQL(repeatEnd);

        String output =    userID + ", '"  +  startString + "', '" +  endString          + "', '" +
                           status + "', '" + frequency    + "', '" + repeatEndString     + "', '" + details + "'";

        return output;
    }
}
