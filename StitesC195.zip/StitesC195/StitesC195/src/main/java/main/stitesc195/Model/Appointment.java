package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;
import java.util.Date;

/**
 * The Appointment class represents an appointment object from the database.
 */
public class Appointment {

    /**
     * int representing the unique id value for the appointment.
     */
    private int appointmentID;

    /**
     * String representing the title for the appointment.
     */
    private String title;

    /**
     * String representing the description of the appointment.
     */
    private String description;

    /**
     * String representing the location of the appointment.
     */
    private String location;

    /**
     * String representing the type of appointment.
     */
    private String type;

    /**
     * Date representing the start value of the appointment.
     */
    private Date start;

    /**
     * Date representing the end value of the appointment.
     */
    private Date end;

    /**
     * Date representing the date of creation for the appointment.
     */
    private Date createDate;

    /**
     * String represeting the user who created the appointment.
     */
    private String  createdBy;

    /**
     * Date representing the last update for the appointment
     */
    private Date lastUpdate;

    /**
     * String representing the name of the user who last updated the appointment.
     */
    private String  lastUpdateBy;

    /**
     * Int representing the customer id for the appointment.
     */
    private int customerID;

    /**
     * Int representing the user id for the appointment.
     */
    private int userID;

    /**
     * Int representing the contact id for the appointment.
     */
    private int contactID;

    /**
     * Constructs an empty Appointment object.
     */
    public Appointment() {
    }

    /**
     * Constructs an Appointment object with the given parameters.
     *
     * @param appointmentID  The appointment's unique identifier.
     * @param title          The title of the appointment.
     * @param description    The description of the appointment.
     * @param location       The location where the appointment takes place.
     * @param type           The type of the appointment.
     * @param start          The start date and time of the appointment.
     * @param end            The end date and time of the appointment.
     * @param createDate     The date and time when the appointment was created.
     * @param createdBy      The user who created the appointment.
     * @param lastUpdate     The date and time when the appointment was last updated.
     * @param lastUpdateBy   The user who last updated the appointment.
     * @param customerID     The ID of the customer associated with the appointment.
     * @param userID         The ID of the user associated with the appointment.
     * @param contactID      The ID of the contact associated with the appointment.
     */
    public Appointment(int appointmentID, String title, String description, String location, String type,
                    Date start, Date end, Date createDate, String createdBy, Date lastUpdate, String lastUpdateBy,
                       int customerID, int userID, int contactID) {
        setAppointmentID(appointmentID);
        setTitle(title);
        setAppointmentDescription(description);
        setLocation(location);
        setType(type);
        setStart(start);
        setEnd(end);
        setCreateDate(createDate);
        setCreatedBy(createdBy);
        setLastUpdate(lastUpdate);
        setLastUpdateBy(lastUpdateBy);
        setCustomerID(customerID);
        setUserID(userID);
        setContactID(contactID);
    }

    /**
     * returns the id of the contact.
     *
     * @return the id of the contact
     */
    public int getContactID(){ return contactID;
    }

    /**
     * returns the id of the appointment.
     *
     * @return the id of the appointment.
     */
    public int getAppointmentID(){
        return appointmentID;
    }

    /**
     * returns the title of the appointment.
     *
     * @return the appointment's title
     */
    public String getTitle(){
        return title;
    }

    /**
     * returns the appointment's location.
     *
     * @return location for the appointment.
     */
    public String getLocation(){
        return location;
    }

    /**
     * returns the type for the appointment.
     * @return the type of appointment.
     */
    public String getType(){
        return type;
    }

    /**
     * returns the start value for the appointment.
     * @return the start date for the appointment.
     */
    public Date getStart(){
        return start;
    }

    /**
     * returns the date of creation for the appointment.
     * @return the created date of the appointment.
     */
    public Date getCreateDate(){return createDate;}

    /**
     * returns the user who created the appointment.
     * @return username that created the appointment.
     */
    public String getCreatedBy(){
        return createdBy;
    }

    /**
     * returns the end value for the appointment.
     * @return the end value for the appointment.
     */
    public Date getEnd(){
        return end;
    }

    /**
     * returns the date of last update for the appointment.
     * @return the last update
     */
    public String getLastUpdateBy(){
        return lastUpdateBy;
    }

    /**
     * returns the customer id for the appointment.
     * @return the customer id being returned.
     */
    public int getCustomerID(){
        return customerID;
    }

    /**
     * returns the user id for the appointment.
     * @return the user id being returned.
     */
    public int getUserID(){ return userID; }

    /**
     * returns the description for the appointment.
     * @return the appointment description.
     */
    public String getDescription(){
        return description;
    }

    /**
     * returns the last update for the appointment.
     * @return the last update.
     */
    public Date getLastUpdate(){return lastUpdate;}

    /**
     * sets the appointment id
     * @param appointmentID the appointment id to be set
     */
    public void setAppointmentID(int appointmentID){
        this.appointmentID = appointmentID;
    }

    /**
     * sets the appointment title
     * @param title the title to be set
     */
    public void setTitle(String title){
        this.title = title;
    }

    /**
     * sets the appointment's description.
     *
     * @param desc The description to be set.
     */
    public void setAppointmentDescription(String desc){
        this.description = desc;
    }

    /**
     * sets the location of the appointment
     * @param location the location to be set
     */
    public void setLocation(String location){
        this.location = location;
    }

    /**
     * sets the type for the appointment.
     *
     * @param type the type to be set
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * Sets the username that created the appointment.
     * @param createdBy the usernamne that created the appointment.
     */
    public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }

    /**
     * sets the last update for the appointment.
     * @param update the last update for the appointment.
     */
    public void setLastUpdate(Date update){
        this.lastUpdate = update;
    }

    /**
     * sets the username of that last updated the appointment.
     * @param person the username that last updated the appointment.
     */
    public void setLastUpdateBy(String person){
        this.lastUpdateBy = person;
    }

    /**
     * sets the contact id for the appointment.
     * @param id contact id being set.
     */
    public void setContactID(int id){
        this.contactID = id;
    }

    /**
     * sets the user id for the appointment.
     * @param userID user id to be set.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * sets the customer id for the appointment.
     * @param customerID customer id being set.
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     * set the creation date for the appointment.
     * @param createDate the date of creation for the appointment
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * set the end date for the appointment.
     * @param end the end date for the appointment.
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * set the start date for the appointment.
     *
     * @param start the start date for the appointment.
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * prints out appointment information. Used to debug problems in the code.
     * @return String containing information regarding an appointment.
     */
    public String printAppointmentInformation() {

        //create a dateHelper object to manage the display of the date/time variables
        DateHelper dateHelper = new DateHelper();

        //original values
        String startString, endString, createDateString, lastUpdateString;

        //convert start value to user's time zone
//        startString         = dateHelper.convertServerToUser(start);
//        endString           = dateHelper.convertServerToUser(end);
//        createDateString    = dateHelper.convertServerToUser(createDate);
//        lastUpdateString    = dateHelper.convertServerToUser(lastUpdate);

        startString      = DateHelper.stringDateToFormatForSQL(start);
        endString        = DateHelper.stringDateToFormatForSQL(end);
        createDateString = DateHelper.stringDateToFormatForSQL(createDate);
        lastUpdateString = DateHelper.stringDateToFormatForSQL(lastUpdate);

        System.out.println("printAppointment Information: ");
        System.out.println("startString: "+startString);
        System.out.println("endString  : "+endString);


        System.out.println("lastUpdate: " +lastUpdateString);

        String output = appointmentID +", '" + title + "', '" +  description + "', '" + location + "', '" +
                            type + "', '" + startString +"', '" + endString  +"', '" + createDateString  +"', '" + createdBy  +"', '" +
                            lastUpdateString  +"', '" +  lastUpdateBy  +"', " + customerID   +", " + userID   +", " + contactID;

        System.out.println(output);

        return output;
    }
}
