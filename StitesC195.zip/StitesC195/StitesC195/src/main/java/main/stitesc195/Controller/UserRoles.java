package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.stitesc195.Model.User;
import main.stitesc195.Model.UserRole;

/**
 * Contains the logic and variables for the "User Roles" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class UserRoles implements Initializable {

    /**
     * Add button for adding roles, loads the UserRoleDetails screen when pressed.
     */
    @FXML
    private Button addButton;

    /**
     * Back button for return to previous screen, loads the Dashboard screen.
     */
    @FXML
    private Button backButton;

    /**
     * TableView for storing the various roles.
     */
    @FXML
    private TableView rolesTable;

    /**
     * Modify Button for viewing or modifying an existing search, loads AdvancedSearch screen when pressed.
     */
    @FXML
    private Button modifyButton;

    /**
     * Delete button for deleting a selected search from the table and database
     */
    @FXML
    private Button deleteButton;

    /**
     * Represents the selected role in the application.
     * This field is annotated with @FXML for JavaFX controller injection.
     */
    @FXML
    private UserRole selectedRole;

    /**
     * TableColumn for storing Role Ids
     */
    @FXML
    TableColumn<UserRole, Integer> roleIDColumn;

    /**
     * TableColumn for storing Role Description value
     */
    @FXML
    TableColumn<UserRole, String> roleDescriptionColumn;

    /**
     * TableColumn for storing a "true" or "false" for whether the role can reset passwords
     */
    @FXML
    TableColumn<UserRole, String> canResetPasswordsColumn;

    /**
     * TableColumn for storing "true" or "false" for whether the role is a super user.
     */
    @FXML
    TableColumn<UserRole, String> superUserColumn;

    /**
     * ObservableList used to store all roles
     */
    ObservableList<UserRole> roles = FXCollections.observableArrayList();

    /**
     * ObservableList used to store all users
     */
    ObservableList<User> users = FXCollections.observableArrayList();

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * DateHelper class to help convert dates
     */
    DateHelper dateHelper;

    /**
     * Initializes the Search screen.
     *
     * Sets the GUI elements to the appropriate text based on language selection and gets all roles from the database
     * and displays them in the table view.
     *
     * @param url            The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();
        setLanguage();

        //get all roles from the database and load into cells
        getAllRoles(roles);
    }

    /**
     *  Populates the Roles table with the roles Observable List.
     *
     * @param roles An ObservableList of User Role objects containing all roles to be displayed.
     */
    public void getAllRoles(ObservableList<UserRole> roles) {

        PropertyValueFactory<UserRole, Integer> roleIDColumnFactory = new PropertyValueFactory<>("roleID");
        roleIDColumn.setCellValueFactory(roleIDColumnFactory);

        PropertyValueFactory<UserRole, String> roleDescriptionColumnFactory = new PropertyValueFactory<>("description");
        roleDescriptionColumn.setCellValueFactory(roleDescriptionColumnFactory);

        PropertyValueFactory<UserRole, String> canResetPasswordsColumnFactory = new PropertyValueFactory<>("canResetPasswords");
        canResetPasswordsColumn.setCellValueFactory(canResetPasswordsColumnFactory);

        PropertyValueFactory<UserRole, String> superUserColumnFactory = new PropertyValueFactory<>("superUser");
        superUserColumn.setCellValueFactory(superUserColumnFactory);

        roles.removeAll(roles);

        roles=ConnectDB.getAllRoles();

        updateTable(roles);
        }

    /**
         * Back button for returning to previous screen "Dashboard.fxml"
         */
    public void BackButton(){
            currentStage = (Stage) backButton.getScene().getWindow();
            viewLoader.loadFXML("Dashboard", currentStage);
        }

    /**
         * Loads UserRolesDetails screen to add a role.
         */
    public void addRole(){
            ConnectDB.selectedRole = null;

            currentStage = (Stage) addButton.getScene().getWindow();
            viewLoader.loadFXML("UserRoleDetails", currentStage);
        }

    /**
         * Loads UserRoleDetails screen to view or modify an existing role
         */
    public void editRole(){
            //get role selection from table
            selectedRole = (main.stitesc195.Model.UserRole) rolesTable.getSelectionModel().getSelectedItem();
            ConnectDB.selectedRole = selectedRole;

            //ensure not null
            if(selectedRole == null){
                String noSelectedRole = languages.getString("noSelectedRole");
                viewLoader.showAlert(noSelectedRole);
                return;
            }

            //load role into UserRoleDetails form
            UserRoleDetails roleDetails = new UserRoleDetails();
            roleDetails.setRole(selectedRole);
            roleDetails.initialize();

            try{
                roleDetails.loadDetails(selectedRole);
            } catch (Exception e){
                e.printStackTrace();
            }

            currentStage = (Stage) modifyButton.getScene().getWindow();
            viewLoader.loadFXML("UserRoleDetails", currentStage);
        }

    /**
         * Deletes a selected role.
         *
         * @throws SQLException if there is an error with the sql code or server.
         */
    public void deleteRole() throws SQLException {
            //get role selection from table
            selectedRole = (main.stitesc195.Model.UserRole) rolesTable.getSelectionModel().getSelectedItem();
            ConnectDB.selectedRole = selectedRole;
            ResourceBundle languages = ResourceBundle.getBundle("language");

            //ensure not null
            if (selectedRole == null) {
                String noSelectedRole = languages.getString("noSelectedRole");
                viewLoader.showAlert(noSelectedRole);
                return;
            }

            // Prompt user to ensure they want to continue with the deletion
            String confirmDeletion	= languages.getString("confirmDeleteRole");
            Boolean confirmStatus	= viewLoader.confirmPrompt(confirmDeletion);

            if(confirmStatus) {

                //check for users with the role id first
                Boolean userAssignedToRole = ConnectDB.checkForUsersAssignedToRole(selectedRole.getRoleID());

                //if there is a user assigned to the role, prompt the user and prevent deletion.
                if(userAssignedToRole){
                    String userAssigned = languages.getString("userAssignedToRole");
                    viewLoader.showAlert(userAssigned);

                }else{
                    //proceed with deletion
                    int success = ConnectDB.deleteRole(selectedRole);

                    if (success > 0) {
                        roles.remove(selectedRole);
                        String roleDeleted		 = languages.getString("roleDeleted");
                        String roleDetails		 = "Role ID: " + selectedRole.getRoleID() +"\n";

                        viewLoader.showAlert(roleDeleted+"\n"+roleDetails);

                        //refresh role list
                        getAllRoles(roles);

                    } else {
                        String roleNotDeleted = languages.getString("roleNotDeleted");
                        viewLoader.showAlert(roleNotDeleted);
                    }
                }
            }
        }

    /**
         * Sets the language of the various GUI elements based on language selection.
         */
    public void setLanguage() {
            //get language setting from system
            Locale 			currentLoc 	= Locale.getDefault();
            ResourceBundle 	languages 	= ResourceBundle.getBundle("language");
            String 			language 	= currentLoc.getLanguage();

            //Strings for GUI, values are retrieved from language properties to adjust for the different language options
            String 	roleId, description, canResetPasswords, superUser, addButtonLabel, modifyButtonLabel, deleteButtonLabel, backButtonLabel;

            //Table Field Labels
            roleId	 			= languages.getString("roleId");
            description 		= languages.getString("roleDesc");
            canResetPasswords	= languages.getString("canResetPassword");
            superUser			= languages.getString("superUser");

            //Button Labels
            addButtonLabel		= languages.getString("add");
            modifyButtonLabel 	= languages.getString("view");
            deleteButtonLabel	= languages.getString("delete");
            backButtonLabel		= languages.getString("back");

            roleIDColumn.setText(roleId);
            roleDescriptionColumn.setText(description);
            canResetPasswordsColumn.setText(canResetPasswords);
            superUserColumn.setText(superUser);

            addButton.setText(addButtonLabel);
            modifyButton.setText(modifyButtonLabel);
            deleteButton.setText(deleteButtonLabel);
            backButton.setText(backButtonLabel);
        }

    /**
         * Update the table view based on the searches input.
         *
         * @param searchesList the list of searches to be shown on the table view
         */
    public void updateTable(ObservableList<UserRole> searchesList) {
            rolesTable.getItems().clear();
            rolesTable.getItems().setAll(searchesList);
            rolesTable.refresh();
        }
}