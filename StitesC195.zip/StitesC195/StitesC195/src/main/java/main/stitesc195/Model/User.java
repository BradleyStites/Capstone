package main.stitesc195.Model;

import java.util.Date;

/**
 * The User class represents a user object from the database.
 */
public class User {

    /**
     * the unique user id for the user
     */
    private int userID;

    /**
     * the username for the user
     */
    private String userName;

    /**
     * the password for the user
     */
    private String password;

    private Date created;

    private String createdBy;

    private Date updated;

    private String updatedBy;

    /**
     * Empty constructor
     */
    public User(){
        userID      =   0;
        userName    = null;
        password    = null;
    }

    /**
     * Constructor for user with the following parameters:
     * @param userID    the unique user id
     * @param userName  the username
     * @param password  user's password
     */
    public User(int userID, String userName, String password){
        this.userID     = userID;
        this.userName   = userName;
        this.password   = password;
    }

    public User(int userID, String userName){
        setUserID(userID);
        setUserName(userName);
    }

    public User(int userID, String userName, String password, Date created, String createdBy, Date updated, String updatedBy){
        setUserID(userID);
        setUserName(userName);
        setPassword(password);
        setCreated(created);
        setCreatedBy(createdBy);
        setUpdated(updated);
        setUpdatedBy(updatedBy);
    }

    public Date getCreated(){return created;}

    public Date getUpdated(){return updated;}

    public  String getCreatedBy(){return createdBy;}

    public  String getUpdatedBy(){return updatedBy;}

    public void setCreated(Date created){
        this.created = created;
    }

    public void setUpdated(Date updated){
        this.updated = updated;
    }

    public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }

    public void setUpdatedBy(String updatedBy){
        this.updatedBy = updatedBy;
    }

    /**
     * returns the user id
     * @return user id
     */
    public int getUserID(){
        return userID;
    }

    /**
     * returns the username
     * @return username
     */
    public String getUserName(){
        return userName;
    }

    /**
     * returns the password for the user
     * @return password
     */
    public String getPassword(){
        return password;
    }

    /**
     * sets the unique user id
     * @param userID the user id
     */
    public void setUserID(int userID){
        this.userID = userID;
    }

    /**
     * sets the username
     * @param name username
     */
    public void setUserName(String name){
        this.userName = name;
    }

    /**
     * sets the password for the user
     * @param pass password
     */
    public void setPassword(String pass){
        this.password = pass;
    }
}
