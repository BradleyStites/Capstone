package main.stitesc195.Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

import main.stitesc195.Model.UserRole;

/**
 * Contains the logic and variables for the "Dashboard" screen, mostly just launches different screens
 *
 * @author Bradley Stites
 */
public class Dashboard implements Initializable {

    /**
     * Represents the "Manage TimeZone" button on the dashboard view.
     *
     * When clicked, this button navigates the user to the TimeZone.fxml screen, which displays all a
     * dropbox to edit current user's active timezone.
     */
    @FXML
    private Button timeZoneButton;

    /**
     * Represents the "Manage Users" button on the dashboard view.
     *
     * When clicked, this button navigates the user to the Users.fxml screen, which displays all users.
     */
    @FXML
    private Button usersButton;

    /**
     * Represents the "Manage Roles" button on the dashboard view.
     *
     * When clicked, this button navigates the user to the Roles.fxml screen, which displays all roles for users.
     */
    @FXML
    private Button rolesButton;

    /**
     * Represents the "Back" button on the dashboard view.
     *
     * When clicked,this button navigates the user to the MainScreen.fxml screen, which displays the main screen.
     */
    @FXML
    private Button backButton;

    /**
     * Represents the "Exit" button on the main screen.
     *
     * When clicked, closes the application and database connection.
     */
    @FXML
    private Button exitButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options.
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     *  Initializes the Main Screen.
     *  Checks for appointments within 15 minutes and displays the information if there is one.
     *  Sets GUI elements text to match language selected.
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //get the active user role
        UserRole activeUserRole = ConnectDB.activeUserRole;
        int activeUserRoleId = activeUserRole.getRoleID();

        //check for user role id and disable buttons if the user shouldn't have access
        if(activeUserRoleId == 1){
            usersButton.setDisable(true);
            rolesButton.setDisable(true);
        }

        //initialize viewloader
        viewLoader = new ViewLoader();
        setFieldByLanguage();
    }

    /**
     * Loads the TimeZone.FXML screen and hides the current screen.
     */
    @FXML
    private void TimeZoneButton(){
        currentStage = (Stage) timeZoneButton.getScene().getWindow();
        viewLoader.loadFXML("TimeZone", currentStage);
    }

    /**
     * Loads the Users.FXML screen and hides the current screen.
     */
    @FXML
    private void UsersButton(){
        currentStage = (Stage) usersButton.getScene().getWindow();
        viewLoader.loadFXML("Users", currentStage);
    }

    /**
     * Loads the Roles.FXML screen and hides the current screen.
     */
    @FXML
    private void RolesButton(){
        currentStage = (Stage) rolesButton.getScene().getWindow();
        viewLoader.loadFXML("UserRoles", currentStage);
    }

    /**
     * Loads the MainScreen.FXML screen and hides the current screen.
     */
    public void backButton(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("MainScreen", currentStage);
    }

    /**
     * Exits the application and closes the connection to the database.
     */
    public void exit() {
        try {
            ConnectDB.closeConnection();
        }catch(Exception e){
            System.out.println("Error Closing Connection: \n"+e.toString());
        }
        System.exit(0);
    }

    /**
     * Sets various GUI elements to match the language selected
     */
    private void setFieldByLanguage() {
        ResourceBundle languages = ResourceBundle.getBundle("language");

        String timeZoneButtonLabel  = languages.getString("manageTimeZone");
        String usersButtonLabel 	= languages.getString("manageUsers");
        String rolesButtonLabel 	= languages.getString("manageRoles");
        String backButtonLabel  	= languages.getString("back");
        String exitButtonLabel  	= languages.getString("Exit");

        usersButton.setText(usersButtonLabel);
        rolesButton.setText(rolesButtonLabel);
        backButton.setText(backButtonLabel);
        exitButton.setText(exitButtonLabel);
        timeZoneButton.setText(timeZoneButtonLabel);
    }
}