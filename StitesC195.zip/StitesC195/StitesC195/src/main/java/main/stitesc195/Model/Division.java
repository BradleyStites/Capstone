package main.stitesc195.Model;

import java.util.Date;

/**
 * The Division class represents a division object from the database.
 */
public class Division {

    /**
     * an integer representing the unique division ids
     */
    private int id;

    /**
     * a string for the division names
     */
    private String  division;

    /**
     * a date for the creation of the division
     */
    private Date created;

    /**
     * a string for the username that created the division
     */
    private String  createdBy;

    /**
     * a date used to store the last update for the division
     */
    private Date updated;

    /**
     * a string for the username that last updated the division
     */
    private String updatedBy;

    /**
     * an integer for the country id associated with the division
     */
    private int countryId;

    /**
     * Constructs an empty Division object.
     */
    public Division() {
    }

    /**
     * Constructs a Division object with the following parameters.
     * @param id            the unique division id
     * @param division      the name of the division
     * @param created       the date of creation
     * @param createdBy     the username that created the division
     * @param updated       the date the division was last updated
     * @param updatedBy     the username that updated the division
     * @param countryId     the country id associated with the division
     */
    public Division(int id, String division, Date created, String createdBy, Date updated,
                    String updatedBy, int countryId) {
        setId(id);
        setDivision(division);
        setCreated(created);
        setCreatedBy(createdBy);
        setUpdated(updated);
        setUpdatedBy(updatedBy);
        setCountryId(countryId);
    }

    /**
     * returns the division id
     * @return the division id
     */
    public int getId()     {return id;}

    /**
     * returns the division name
     * @return the name of the division
     */
    public String   getDivision()       {return division;}

    /**
     * returns the date of creation
     * @return the date of creation
     */
    public Date getCreated()    {return created;}

    /**
     * returns the username that created the division
     * @return username that created the division
     */
    public String   getCreatedBy()      {return createdBy;}

    /**
     * returns the last update for the division
     * @return the last update
     */
    public Date getUpdated()     {return updated;}

    /**
     * returns the username that last updated the division
     * @return the username
     */
    public String getUpdatedBy()  {return updatedBy;}

    /**
     * returns the country id associated with teh division
     * @return the country id
     */
    public int getCountryId()      {return countryId;}

    /**
     * sets the unique division id
     * @param id the division id
     */
    public void setId(int id)               {this.id = id;}

    /**
     * sets the division name
     * @param div the division name
     */
    public void setDivision(String div)             {this.division = div;}

    /**
     * sets the creation date
     * @param date date of creation
     */
    public void setCreated(Date date)               {this.created = date;}

    /**
     * sets the username that created the division
     * @param createdBy username
     */
    public void setCreatedBy(String createdBy)      {this.createdBy = createdBy;}

    /**
     * sets the last update for the division
     * @param date last update
     */
    public void setUpdated(Date date)            {this.updated = date;}

    /**
     * sets the username that last updated the division
     * @param updatedBy username
     */
    public void setUpdatedBy(String updatedBy)  {this.updatedBy = updatedBy;}

    /**
     * sets the country id for the division
     * @param id country id
     */
    public void setCountryId(int id)                {this.countryId = id;}
	
	/**
	 * Output division information, for debugging and sql input
	 */
	public String outputInformation(){
		String 	output 	= 	"\'";

        output	+=	getDivision()		+"\', \'";
        output 	+=	getCreated()	+"\', \'";
        output	+=	getCreatedBy()		+"\', \'";
        output	+=	getUpdated()		+"\', \''";
        output	+=	getUpdatedBy()	+"\', ";
        output	+=	getCountryId();

        return output;
	}
}
