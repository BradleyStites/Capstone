package main.stitesc195.Model;

import java.util.Date;

/**
 * The Division class represents a division object from the database.
 */
public class Division {

    /**
     * an integer representing the unique division ids
     */
    private int     divisionID;

    /**
     * a string for the division names
     */
    private String  division;

    /**
     * a date for the creation of the division
     */
    private Date    createdDate;

    /**
     * a string for the username that created the division
     */
    private String  createdBy;

    /**
     * a date used to store the last update for the division
     */
    private Date    lastUpdate;

    /**
     * a string for the username that last updated the division
     */
    private String  lastUpdatedBy;

    /**
     * an integer for the country id associated with the division
     */
    private int     countryID;

    /**
     * Constructs an empty Division object.
     */
    public Division() {
    }

    /**
     * Constructs a Division object with the following parameters.
     * @param id            the unique division id
     * @param division      the name of the division
     * @param created       the date of creation
     * @param createdBy     the username that created the division
     * @param lastUpdate    the date the division was last updated
     * @param lastUpdatedBy the username that updated the division
     * @param countryID     the country id associated with the division
     */
    public Division(int id, String division, Date created, String createdBy, Date lastUpdate,
                    String lastUpdatedBy, int countryID) {
        setDivisionID(id);
        setDivision(division);
        setCreated(created);
        setCreatedBy(createdBy);
        setLastUpdate(lastUpdate);
        setLastUpdatedBy(lastUpdatedBy);
        setCountryID(countryID);
    }

    /**
     * returns the division id
     * @return the division id
     */
    public int      getDivisionID()     {return divisionID;}

    /**
     * returns the division name
     * @return the name of the division
     */
    public String   getDivision()       {return division;}

    /**
     * returns the date of creation
     * @return the date of creation
     */
    public Date     getCreatedDate()    {return createdDate;}

    /**
     * returns the username that created the division
     * @return username that created the division
     */
    public String   getCreatedBy()      {return createdBy;}

    /**
     * returns the last update for the division
     * @return the last update
     */
    public Date     getLastUpdate()     {return lastUpdate;}

    /**
     * returns the username that last updated the division
     * @return the username
     */
    public String   getLastUpdatedBy()  {return lastUpdatedBy;}

    /**
     * returns the country id associated with teh division
     * @return the country id
     */
    public int      getCountryID()      {return countryID;}

    /**
     * sets the unique division id
     * @param id the division id
     */
    public void setDivisionID(int id)               {this.divisionID = id;}

    /**
     * sets the division name
     * @param div the division name
     */
    public void setDivision(String div)             {this.division = div;}

    /**
     * sets the creation date
     * @param date date of creation
     */
    public void setCreated(Date date)               {this.createdDate = date;}

    /**
     * sets the username that created the division
     * @param createdBy username
     */
    public void setCreatedBy(String createdBy)      {this.createdBy = createdBy;}

    /**
     * sets the last update for the division
     * @param date last update
     */
    public void setLastUpdate(Date date)            {this.lastUpdate = date;}

    /**
     * sets the username that last updated the division
     * @param updatedBy username
     */
    public void setLastUpdatedBy(String updatedBy)  {this.lastUpdatedBy = updatedBy;}

    /**
     * sets the country id for the division
     * @param id country id
     */
    public void setCountryID(int id)                {this.countryID = id;}
}
