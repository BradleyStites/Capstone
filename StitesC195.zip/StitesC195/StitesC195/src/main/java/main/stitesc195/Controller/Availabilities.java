package main.stitesc195.Controller;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.*;

import javafx.stage.Stage;
import main.stitesc195.Model.Availability;


/**
 * Contains the logic and variables for the "Availabilities" screen, handles errors and prompts for various conditions,
 * launches different screens, and sets texts on GUI elements based on user selection in previous screen "Main Menu",
 * shows various stages of Availabilities depending on the state of the various toggles and buttons.
 *
 * @author Bradley Stites
 */
public class Availabilities implements Initializable {

    /**
     * Represents the Availabilities TableView on the Availabilities screen.
     */
    @FXML
    private TableView availabilitiesTable;

    /**
     * Represents the "Add" button on the Availabilities screen.
     *
     * When clicked, this button navigates the user to the AvailabilityDetails.fxml screen, which allows a user to
     * add a new availability.
     */
    @FXML
    private Button addButton;

    /**
     * Represents the "View/Modify" button on the Availabilities screen.
     *
     * When clicked, this button navigates the user to the AvailabilityDetails.fxml screen, which allows a user to
     * modify an existing availability.
     */
    @FXML
    private Button modifyButton;

    /**
     * Represents the "Delete" button on the Availabilities screen.
     *
     * When clicked, various checks are performed to ensure deletion is possible, then deletes any selected
     * availability upon confirmation.
     */
    @FXML
    private Button deleteButton;

    /**
     * Represents the "Back" button on the Main Menu screen.
     *
     * When clicked, this button navigates the user back to the MainMenu.fxml screen
     */
    @FXML
    private Button backButton;

    /**
     * Represents the "Availability ID" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, Integer> availabilityIDColumn;

    /**
     * Represents the "User Id" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, Integer> availabilityUserIDColumn;

    /**
     * Represents the "Status" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, String> statusColumn;

    /**
     * Represents the "Availability Details" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, String> detailsColumn;

    /**
     * Represents the "Availability Start" Column on the Availability Table.
     */
    @FXML
    TableColumn<Availability, String> startColumn;

    /**
     * Represents the "Availability End" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, String> endColumn;

    /**
     * Represents the "Repeat Frequency" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, String> repeatFrequencyColumn;

    /**
     * Represents the "Repeat End Date" Column on the Availabilities Table.
     */
    @FXML
    TableColumn<Availability, String> repeatEndColumn;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * ObservableList to store all appointments.
     */
    ObservableList<Availability> availabilities = FXCollections.observableArrayList();

    /**
     * DateHelper used to convert dates to and from various time zones
     */
    DateHelper dateHelper;

    /**
     * Availability used to store the selected availability.
     */
    private Availability selectedAvailability = new Availability();

    /**
     * Initializes the Availabilities Screen.
     *
     * Initializes GUI Objects and loads text.
     *
     * @param url            the location used to resolve relative paths for the root object or null if the location is not known
     * @param resourceBundle resourceBundle the resources used to localize the root object or null if the root object was not localized
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //initialize current stage and ViewLoader
        viewLoader = new ViewLoader();
        dateHelper = new DateHelper();

        //get all availabilities for the active user
        availabilities = ConnectDB.getAvailabilitiesForUser(ConnectDB.userID);
        updateAvailabilitiesTable(availabilities);

        //set the headers on the columns to match the correct language
        setLanguage();
    }

    /**
     * Sets the text of the various GUI Elements on the Appointments screen to match the language selected.
     */
    private void setLanguage() {
        String availabilityId, userId, details, status, start, end, repeatEndDate, repeatFrequency, add,viewModify, delete, back;

        // Get values from properties file
        availabilityId = languages.getString("availabilityId");
        userId = languages.getString("userId");
        details = languages.getString("details");
        status = languages.getString("status");

        repeatEndDate = languages.getString("repeatEndDate");
        repeatFrequency = languages.getString("repeatFrequency");

        start = languages.getString("start");
        end = languages.getString("end");

        add = languages.getString("add");
        viewModify = languages.getString("view");
        delete = languages.getString("delete");
        back = languages.getString("back");

        //set gui elements
        availabilityIDColumn.setText(availabilityId);
//        availabilityUserIDColumn.setText(userId);
        detailsColumn.setText(details);
        statusColumn.setText(status);

        repeatFrequencyColumn.setText(repeatFrequency);
        repeatEndColumn.setText(repeatEndDate);

        startColumn.setText(start);
        endColumn.setText(end);

        addButton.setText(add);
        modifyButton.setText(viewModify);
        deleteButton.setText(delete);
        backButton.setText(back);
    }

    /**
     *  Populates the Availabilities' table with the availabilities passed in as an Observable List. Sets the appropriate cell
     *  factories to display availability information and converts date/time values from the server time to the user's local
     *  time zone.
     *
     * @param availabilities An ObservableList of Appointment objects containing all appointments to be displayed.
     */
    public void updateAvailabilitiesTable(ObservableList<Availability> availabilities){

        availabilityIDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAvailabilityID()).asObject());
//        availabilityUserIDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getUserID()).asObject());
        statusColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStatus()));
        repeatFrequencyColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getRepeatFrequency()));
        detailsColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDetails()));
        startColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> dateHelper.convertServerToUser(cellData.getValue().getStart())));
        endColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> dateHelper.convertServerToUser(cellData.getValue().getEnd())));
        repeatEndColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> dateHelper.convertServerToUser(cellData.getValue().getRepeatEndDate())));

        //clear the table and set the table to the incoming appointments object
        availabilitiesTable.getItems().clear();
        availabilitiesTable.getItems().setAll(availabilities);
        availabilitiesTable.refresh();
    }

    /**
     * Deletes the selected availability from the table if confirmed by the user.
     */
    public void deleteAvailability(){
        //get appointment selection from table
        selectedAvailability = (Availability) availabilitiesTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedAvailability = selectedAvailability;

        String noSelectedAvailability  = languages.getString("noSelectedAvailability");

        //ensure not null
        if (selectedAvailability == null) {
            viewLoader.showAlert(noSelectedAvailability);
            return;
        }

        // Confirm Deletion
        String confirmDeletion = languages.getString("confirmDeleteAvailability");
        boolean confirmed = viewLoader.confirmPrompt(confirmDeletion);

        if(confirmed){
            //proceed with deletion
            int success = ConnectDB.deleteAvailability(selectedAvailability);

            if(success>0){
                String availabilityDeleted = languages.getString("availabilityDeleted");
                String availabilityId      = languages.getString("availabilityId");
                String details             = languages.getString("details");
                String availabilityDetails = availabilityId+": "+selectedAvailability.getAvailabilityID()+"\n"+
                        details         +": "+selectedAvailability.getDetails();
                viewLoader.showAlert(availabilityDeleted+"\n\n"+availabilityDetails);
                availabilities.remove(selectedAvailability);

                //refresh appointments
                updateAvailabilitiesTable(availabilities);

                ConnectDB.selectedAvailability = null;

            }else{
                String appointmentNotDeleted = languages.getString("appointmentNotDeleted");
                viewLoader.showAlert(appointmentNotDeleted);
            }
        }
    }

    /**
     * Returns the user to the "MainScreen.fxml" screen.
     */
    public void BackButton(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("MainScreen", currentStage);
    }

    /**
     * Sends user to the "AavailabilityDetails.fxml" screen to create a new availability.
     */
    public void addAvailability(){
        ConnectDB.selectedAppointment = null;
        currentStage = (Stage) addButton.getScene().getWindow();
        viewLoader.loadFXML("AvailabilityDetails", currentStage);
    }

    /**
     * Sends the user to the "AvailabilityDetails.fxml" screen to update an existing availability.
     */
    public void editAvailability(){

        String okay                   = languages.getString("okay");
        String noSelectedAvailability = languages.getString("noSelectedAvailability");

        //get appointment selection from table
        selectedAvailability = (Availability) availabilitiesTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedAvailability = selectedAvailability;

        //ensure not null
        if (selectedAvailability == null) {
            viewLoader.showAlert(noSelectedAvailability);
            return;
        }
        else{
            //load selected appointment into form
            AvailabilityDetails availabilityDetails = new AvailabilityDetails();
            availabilityDetails.setAvailability(selectedAvailability);
            availabilityDetails.initialize();

            currentStage = (Stage) modifyButton.getScene().getWindow();
            viewLoader.loadFXML("AvailabilityDetails", currentStage);
        }
    }

    /**
     * Sets the selected availability to the input parameter.
     *
     * @param availability An availability object representing the selected availability.
     */
    public void setAvailabilities(Availability availability){
        selectedAvailability = availability;
    }
}