package main.stitesc195;

import javafx.application.Application;
import javafx.stage.Stage;
import main.stitesc195.Controller.ConnectDB;
import main.stitesc195.Controller.ViewLoader;

import java.io.File;
import java.io.IOException;

/**
 * MainApplication
 * This loads the login screen and creates the log file which is used for storing login attempts.
 *
 * @author Bradley Stites
 */
public class MainApplication extends Application {

    /**
     * The current stage of the application used to denote the current stage to be hidden by the ViewLoader
     */
    Stage currentStage;

    /**
     * The view loader for the application used to change views/stages or display alerts
     */
    ViewLoader viewLoader;

    /**
     * Starts the application by loading the login screen and creating the log file if it does not already exist.
     *
     * @param stage the primary stage for the application
     * @throws IOException if an error occurs while loading the login screen
     */
    @Override
    public void start(Stage stage) throws IOException {

        currentStage = null;
        viewLoader = new ViewLoader();

        // Check if Log File exists
        Boolean exists = checkIfLogFileExists();

        if(!exists){
            // Log File Does Not Exist - create log file
            createLogFile();
        }

        viewLoader.loadFXML("Login", currentStage);
    }

    /**
     * Connects to the database and launches the application.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ConnectDB.connect();
        String currentDatabaseVersion = getCurrentDatabaseVersion();
        String LatestDatabaseVersion  = getLatestDatabaseVersion();
        launch();
    }

    /**
     * Retrieves the current version of the database.
     *
     * @return The current version of the database as a String.
     */
    private static String getCurrentDatabaseVersion() {
        String databaseVersion;
        databaseVersion = ConnectDB.getCurrentDatabaseVersion();
        return databaseVersion;
    }

    /**
     * Retrieves the latest version of the database.
     *
     * @return The latest version of the database as a String.
     */
    private static String getLatestDatabaseVersion(){
        String databaseVersion = "1.0.1"; // hard coded for now
        return databaseVersion;
    }

    /**
     * Creates the log file for storing login attempts.
     */
    private void createLogFile() {
        File logFile = new File(ConnectDB.logFile);

        try{
            if (logFile.createNewFile()) {
//                System.out.println("File created: " + logFile.getName());
            } else {
//                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Checks if the log file exists.
     *
     * @return true if the log file exists, false otherwise
     */
    private Boolean checkIfLogFileExists() {

        File logFile = new File(ConnectDB.logFile);

        if(logFile.exists() && !logFile.isDirectory()) {
            return true;
        }else{
            return false;
        }
    }
}