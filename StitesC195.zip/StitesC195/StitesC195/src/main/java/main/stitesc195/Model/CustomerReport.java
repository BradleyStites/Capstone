package main.stitesc195.Model;

/**
 * The Contact class represents a Customer Report object.
 */
public class CustomerReport {

    /**
     * string used to store the name of the month on the report
     */
    private String month;

    /**
     * string used to store the year on the report
     */
    private String year;

    /**
     * string used to store the type on the report.
     */
    private String type;

    /**
     * int used to store the total
     */
    private int total;

    /**
     * Constructs an empty CustomerReport object.
     */
    public CustomerReport() {
    }

    /**
     * Constructs a CustomerReport object with the following parameters.
     *
     * @param month the name of the month
     * @param year  the year
     * @param type  the type
     * @param total the total number of appointments based on type, month, and year.
     */
    public CustomerReport(String month, String year, String type, int total){
        setMonth(month);
        setYear(year);
        setType(type);
        setTotal(total);
    }

    /**
     * sets the year for the customer report
     * @param year the year to be set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * returns the year for the customer report
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * sets the month for the customer report
     * @param month the name of the month
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * sets the type on the customer report
     * @param type the type of appointment
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * sets the total for the customer report
     * @param total total appointments by type,month, and year.
     */
    public void setTotal(int total) {
        this.total = total;
    }

    /**
     * returns the total number of appointments for the customer report
     * @return total appointments
     */
    public int getTotal() {
        return total;
    }

    /**
     * returns the name of the month for the customer report.
     * @return name of the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * gets the type for the customer report
     * @return the type of appointment for this customer report
     */
    public String getType() {
        return type;
    }
}
