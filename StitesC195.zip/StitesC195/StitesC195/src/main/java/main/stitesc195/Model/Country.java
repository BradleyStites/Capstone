package main.stitesc195.Model;

import java.util.Date;

/**
 * The Country class represents a country object from the database.
 */
public class Country {

    /**
     * int representing the unique country id value
     */
    private int     countryID;

    /**
     * string representing the country name
     */
    private String  country;

    /**
     * date representing the creation date for the country in the database
     */
    private Date    createdDate;

    /**
     * string representing the username that created the country in the database
     */
    private String  createdBy;

    /**
     * date representing the last update for the country in the database
     */
    private Date    lastUpdate;

    /**
     * string representing the username that last updated the country
     */
    private String  lastUpdateBy;

    /**
     * Constructs an empty Country object.
     */
    public Country() {
    }

    /**
     * Constructs a Country Object with the following parameters
     * @param countryID     unique country id
     * @param country       country name
     * @param created       creation date
     * @param createdBy     username that created object
     * @param lastUpdate    date of last update
     * @param lastUpdateBy  username that last updated object
     */
    public Country(int countryID, String country, Date created,String createdBy,
                    Date lastUpdate, String lastUpdateBy) {
        setCountryID(countryID);
        setCountry(country);
        setCreatedDate(created);
        setCreatedBy(createdBy);
        setLastUpdate(lastUpdate);
        setLastUpdateBy(lastUpdateBy);
    }

    /**
     * returns the unique country id
     * @return the country id
     */
    public int getCountryID(){
        return countryID;
    }

    /**
     * returns the country name
     * @return the country name
     */
    public String getCountry(){
        return country;
    }

    /**
     * returns the created date
     * @return the created date
     */
    public Date getCreatedDate(){
        return createdDate;
    }

    /**
     * returns username that created object
     * @return username that created object
     */
    public String getCreatedBy(){
        return createdBy;
    }

    /**
     * return date of last update
     * @return date of last update
     */
    public Date getLastUpdate(){
        return lastUpdate;
    }

    /**
     * returns name of user who last updated object
     * @return name of user who last updated object
     */
    public String getLastUpdateBy(){
        return lastUpdateBy;
    }

    /**
     * sets the country id
     * @param id country id to be set
     */
    public void setCountryID(int id){
        this.countryID = id;
    }

    /**
     * sets the country name
     * @param country the name to be set
     */
    public void setCountry(String country){
        this.country = country;
    }

    /**
     * set the creation date
     * @param date the date of creation
     */
    public void setCreatedDate(Date date){
        this.createdDate = date;
    }

    /**
     * sets the username that created the object
     * @param name user that created object
     */
    public void setCreatedBy(String name){
        this.createdBy = name;
    }

    /**
     * set the last update
     * @param date date of last update
     */
    public void setLastUpdate(Date date){
        this.lastUpdate = date;
    }

    /**
     * sets the username that last updated object
     * @param name username that updated object.
     */
    public void setLastUpdateBy(String name){
        this.lastUpdateBy = name;
    }
}
