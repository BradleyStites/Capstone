package main.stitesc195.Model;

import java.util.Date;

/**
 * The Country class represents a country object from the database.
 */
public class Country {

    /**
     * int representing the unique country id value
     */
    private int id;

    /**
     * string representing the country name
     */
    private String  country;

    /**
     * date representing the creation date for the country in the database
     */
    private Date created;

    /**
     * string representing the username that created the country in the database
     */
    private String  createdBy;

    /**
     * date representing the last update for the country in the database
     */
    private Date updated;

    /**
     * string representing the username that last updated the country
     */
    private String updatedBy;

    /**
     * Constructs an empty Country object.
     */
    public Country() {
    }

    /**
     * Constructs a Country Object with the following parameters
     * @param countryID     unique country id
     * @param country       country name
     * @param created       creation date
     * @param createdBy     username that created the country
     * @param update        date of last update
     * @param updatedBy     username that updated the country
     */
    public Country(int countryID, String country, Date created,String createdBy,
                    Date update, String updatedBy) {
        setId(countryID);
        setCountry(country);
        setCreated(created);
        setCreatedBy(createdBy);
        setUpdated(update);
        setUpdatedBy(updatedBy);
    }

    /**
     * returns the unique country id
     * @return the country id
     */
    public int getId(){
        return id;
    }

    /**
     * returns the country name
     * @return the country name
     */
    public String getCountry(){
        return country;
    }

    /**
     * returns the created date
     * @return the created date
     */
    public Date getCreated(){
        return created;
    }

    /**
     * returns username that created object
     * @return username that created object
     */
    public String getCreatedBy(){
        return createdBy;
    }

    /**
     * return date of last update
     * @return date of last update
     */
    public Date getUpdated(){
        return updated;
    }

    /**
     * returns name of user who last updated object
     * @return name of user who last updated object
     */
    public String getUpdatedBy(){
        return updatedBy;
    }

    /**
     * sets the country id
     * @param id country id to be set
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the country name
     * @param country the name to be set
     */
    public void setCountry(String country){
        this.country = country;
    }

    /**
     * set the creation date
     * @param date the date of creation
     */
    public void setCreated(Date date){
        this.created = date;
    }

    /**
     * sets the username that created the object
     * @param name user that created object
     */
    public void setCreatedBy(String name){
        this.createdBy = name;
    }

    /**
     * set the last update
     * @param date date of last update
     */
    public void setUpdated(Date date){
        this.updated = date;
    }

    /**
     * sets the username that last updated object
     * @param name username that updated object.
     */
    public void setUpdatedBy(String name){
        this.updatedBy = name;
    }
	
	public String printInformation(){
		String output =  "";
		
		output 		  	+= getCountry()		+", ";
        output		  	+= getCreated() +", ";
        output 			+= getCreatedBy()	+", ";
        output			+= getUpdated()	+", ";
        output			+= getUpdatedBy();
		
		return output;
	}
}
