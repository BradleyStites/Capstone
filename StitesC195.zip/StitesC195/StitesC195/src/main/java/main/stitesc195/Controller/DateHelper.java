package main.stitesc195.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Contains the logic for converting dates to and from various time zones.
 *
 * @author Bradley Stites
 */
public class DateHelper {

    /**
     * ZoneId used to store the time zone of the active user.
     */
    public static ZoneId userTimeZoneId;

    /**
     * ZoneId used to store the time zone of the server - represented by UTC
     */
    public static ZoneId serverTimeZoneId   = ZoneId.of("UTC");       //UTC

    /**
     * ZoneId used to store the time zone of the business - represented by EST or America/New_York
     */
    public static ZoneId businessTimeZoneId = ZoneId.of("America/New_York");    //EST

    /**
     * Adjusts an incoming date from one time zone to another based on input parameters.
     *
     * @param date represents the date being converted.
     * @param from represents the timezone it's being converted from.
     * @param to   represents the timezone it's being converted to.
     * @return                the adjustedTime as a String.
     */
    public static String adjustToTimeZone(java.util.Date date, ZoneId from, ZoneId to) {

        //Create formatter
        String dateFormat = "yyyy-MM-dd HH:mm:ss";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        TimeZone tz = TimeZone.getTimeZone(from);
        sdf.setTimeZone(tz);

        Calendar c = Calendar.getInstance();
        SimpleDateFormat yearSDF = new SimpleDateFormat("yyyy");
        SimpleDateFormat monthSDF = new SimpleDateFormat("MM");
        SimpleDateFormat daySDF = new SimpleDateFormat("dd");
        SimpleDateFormat hourSDF = new SimpleDateFormat("HH");
        SimpleDateFormat minuteSDF = new SimpleDateFormat("mm");
        SimpleDateFormat secondSDF = new SimpleDateFormat("ss");

        String year     = yearSDF.format(date);
        String month    = monthSDF.format(date);
        String day      = daySDF.format(date);
        String hour     = hourSDF.format(date);
        String minute   = minuteSDF.format(date);
        String second   = secondSDF.format(date);

        c.set(Integer.parseInt(year),Integer.parseInt(month)-1,Integer.parseInt(day),Integer.parseInt(hour),Integer.parseInt(minute),Integer.parseInt(second));

        LocalDateTime startLDT = LocalDateTime.of(Integer.parseInt(year),Integer.parseInt(month),Integer.parseInt(day),Integer.parseInt(hour),Integer.parseInt(minute),Integer.parseInt(second));
        ZonedDateTime startZDT = ZonedDateTime.of(startLDT, from);

        ZonedDateTime startZDTAdjusted = startZDT.withZoneSameInstant(to);

        String output = startZDTAdjusted.format(formatter);

        return output;
    }

    /**
     * Adjust a date from server time to user time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public static String convertServerToUser(java.util.Date date) {
        return adjustToTimeZone(date, serverTimeZoneId, userTimeZoneId);
    }

    /**
     * Adjust a date from server time to business time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public String convertServerToBusiness(java.util.Date date) {
        return adjustToTimeZone(date, serverTimeZoneId, businessTimeZoneId);
    }

    /**
     * Adjust a date from user time to server time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public String convertUserToServer(java.util.Date date) {
        return adjustToTimeZone(date, userTimeZoneId, serverTimeZoneId);
    }

    /**
     * Adjust a date from user time to business time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public String convertUserToBusiness(java.util.Date date) {
        return adjustToTimeZone(date, userTimeZoneId, businessTimeZoneId);
    }

    /**
     * Adjust a date from business time to server time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public String convertBusinessToServer(java.util.Date date) {
        return adjustToTimeZone(date, businessTimeZoneId, serverTimeZoneId);
    }

    /**
     * Adjust a date from business time to user time
     * @param date  the date being converted
     * @return      the converted date as a string.
     */
    public String convertBusinessToUser(java.util.Date date) {
        return adjustToTimeZone(date, businessTimeZoneId, userTimeZoneId);
    }

    /**
     * Converts an incoming string input to a date variable.
     *
     * @param input incoming date as string.
     * @return      Date object reflecting the input as a Date.
     */
    public static java.util.Date stringToDate(String input){
        java.util.Date date;

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = df.parse(input);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

//        try {
//            System.out.println("in dateHelper: \nstringToDate: "+date +"\ndf.parse: "+df.parse(input));
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }

        return date;
    }

    /**
     * convert dates to a string representation for ease of use with database
     *
     * @param input the date to be converted to string
     * @return      the string representation of the input date
     */
    public static String stringDateToFormatForSQL(Date input){
        String output;

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        output = df.format(input);

//        System.out.println("in dateHelper: \nstringDateFormatter: "+output);

        return output;
    }
}
