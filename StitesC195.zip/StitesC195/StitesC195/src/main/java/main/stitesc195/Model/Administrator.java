package main.stitesc195.Model;

/**
 * The Administrator class represents an administrator object from the database.
 */
public class Administrator {
    /**
     * int representing the administrator id for the tuple
     */
    private int id;

    /**
     * int representing the user id for the tuple
     */
    private int User_ID;

    /**
     * int representing the role id for the tuple
     */
    private int Role_ID;

	/**
	 * constructor for administrator
	 * @param id		- the admin id for the administrator object
	 * @param UserId	- the user id for the administrator object
	 * @param RoleId	- the role id for the administrator object
	 */
    public Administrator(int id,int UserId, int RoleId){
        setId(id);
        setUserId(UserId);
        setRoleId(RoleId);
    }

	/**
	 * returns the id for the administrator object
	 */
    public int getId(){
        return id;
    }
	
	/**
	 * returns the user id for the administrator object
	 */
    public int getUserId(){ 
	return User_ID;
	}

	/**
	 * returns the role id for the administrator object
	 */
    public int getRoleId(){
		return Role_ID;
	}

	/**
	 * sets the admin id for the administrator object
	 */
    public void setId(int id){this.id =id;}
	
	/**
	 * sets the user id for the administrator object
	 */
    public void setUserId(int id){this.User_ID=id;}
	
	/**
	 * sets the role id for the administrator object
	 */
    public void setRoleId(int id){this.Role_ID=id;}

	/**
     * prints out Administrator information. Used to debug problems in the code and insert into SQL statements.
     * @return String containing information regarding an appointment.
     */
	public String printInformation(){
		String output = "";
		
		output +=	this.getUserId()	+", "+	
					this.getRoleId()	+";";
		
		return output;
	}
}
