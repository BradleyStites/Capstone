package main.stitesc195.Model;

import java.util.Date;

/**
 * The Administrator class represents an administrator object from the database.
 */
public class Administrator {
    /**
     * int representing the administrator id for the tuple
     */
    private int Admin_ID;

    /**
     * int representing the user id for the tuple
     */
    private int User_ID;

    /**
     * int representing the role id for the tuple
     */
    private int Role_ID;

    /**
     * date representing the creation of the tuple
     */
    private Date Create_Date;

    /**
     * string representing the value of the name of the user that created the tuple
     */
    private String Created_by;

    /**
     * date representing the value of the update for the tuple
     */
    private Date Date_Updated;

    /**
     * a string value representing the name of the user that last updated the tuple
     */
    private String Updated_By;

    public Administrator(int AdminId,int UserId, int RoleId, Date creation, String creator, Date updated, String updater){
        setAdminId(AdminId);
        setUserId(UserId);
        setRoleId(RoleId);
        setCreation(creation);
        setCreator(creator);
        setUpdated(updated);
        setUpdater(updater);
    }

    public int getAdminId(){
        return Admin_ID;
    }
    public int getUserId(){ return User_ID;}
    public int getRoleId(){ return Role_ID;}
    public Date getCreationDate(){ return Create_Date;}
    public String getCreator(){return Created_by;}
    public Date getUpdatedDate(){return Date_Updated;}
    public String getUpdater(){return Updated_By;}

    public void setAdminId(int id){this.Admin_ID=id;};
    public void setUserId(int id){this.User_ID=id;};
    public void setRoleId(int id){this.Role_ID=id;};
    public void setCreation(Date date){this.Create_Date = date;}
    public void setCreator(String name){this.Created_by = name;}
    public void setUpdated(Date date){this.Date_Updated = date;}
    public void setUpdater(String name){this.Updated_By = name;}
}
