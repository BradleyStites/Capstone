package main.stitesc195.Controller;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import main.stitesc195.Model.Appointment;

import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "MainScreen" screen, launches different screens, and sets texts on GUI
 * elements based on user selection in previous screen "Login".
 *
 * @author Bradley Stites
 */
public class MainScreen implements Initializable {

    /**
     * Represents the "Customers" button on the main screen.
     * When clicked, this button navigates the user to the Customers.fxml screen, which displays all customers.
     */
    @FXML
    private Button customersButton;

    /**
     * Represents the "Appointments" button on the main screen.
     * When clicked, this button navigates the user to the Appointments.fxml screen, which displays all appointments.
     */
    @FXML
    private Button appointmentsButton;

    /**
     * Represents the "Reports" button on the main screen.
     * When clicked, this button navigates the user to the ReportSelection.fxml screen.
     */
    @FXML
    private Button reportsButton;

    /**
     * Represents the "Availability" button on the main screen.
     */
    @FXML
    private Button availabilityButton;

    /**
     * Represents the "Dashboard" button on the main screen.
     */
    @FXML
    private Button dashboardButton;

    /**
     * Represents the "Exit" button on the main screen.
     * When clicked, closes the application and database connection.
     */
    @FXML
    private Button exitButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options.
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     *  Initializes the Main Screen.
     *  Checks for appointments within 15 minutes and displays the information if there is one.
     *  Sets GUI elements text to match language selected.
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //initialize view loader
        viewLoader = new ViewLoader();

        ObservableList<Appointment> appointments;

        ConnectDB.setTimezoneOnServer();

        try {
            ConnectDB.setDBtoUTC();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //check for appointments within 15 minutes and display result
        try {
            appointments = ConnectDB.getAppointmentsIn15Minutes();
        } catch (SQLException | ParseException e) {
            throw new RuntimeException(e);
        }

        if(!appointments.isEmpty()){
            String appointmentWithin15Minutes = languages.getString("appointmentWithin15Minutes");
            String appointmentId              = languages.getString("appointmentId");
            String start                      = languages.getString("start");
            String end                        = languages.getString("end");
            String appointmentsOutput         = "";

            for(Appointment appointment : appointments){

                Date startDate = appointment.getStart();
                Date endDate   = appointment.getEnd();

                // Define the date format
                String dateFormat = "EEE MMM dd yyyy 'at' hh:mm a";

                // Create a SimpleDateFormat object with the desired format
                SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

                // Format the dates
                String formattedStartDateTime = formatter.format(startDate);
                String formattedEndDateTime = formatter.format(endDate);


                appointmentsOutput = "\n"+appointmentId +": "+appointment.getId()+"\n"+start+": "
                                   + formattedStartDateTime+"\n"+end+": "+formattedEndDateTime+"\n";
            }

            viewLoader.showAlert(appointmentWithin15Minutes+"\n"+appointmentsOutput);
        }else{
            String noAppointmentWithin15Minutes = languages.getString("noAppointmentWithin15Minutes");
            viewLoader.showAlert(noAppointmentWithin15Minutes);
        }

        setFieldByLanguage();
    }

    /**
     * Loads the Customers.FXML screen and hides the current screen.
     */
    @FXML
    private void CustomersButton(){
        currentStage = (Stage) customersButton.getScene().getWindow();
        viewLoader.loadFXML("Customers", currentStage);
    }

    /**
     * Loads the Availabilities.FXML screen and hides the current screen.
     */
    @FXML
    private void availabilityButton(){
        currentStage = (Stage) availabilityButton.getScene().getWindow();
        viewLoader.loadFXML("Availabilities", currentStage);
    }

    /**
     * Loads the Dashboard.FXML screen and hides the current screen.
     */
    @FXML
    private void dashboardButton(){
        currentStage = (Stage) dashboardButton.getScene().getWindow();
        viewLoader.loadFXML("Dashboard", currentStage);
    }

    /**
     * Loads the Appointments.FXML screen and hides the current screen.
     */
    @FXML
    private void AppointmentsButton(){
        currentStage = (Stage) appointmentsButton.getScene().getWindow();
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Loads the ReportSelection.FXML screen and hides the current screen.
     */
    public void reportsButton(){
        currentStage = (Stage) reportsButton.getScene().getWindow();
        viewLoader.loadFXML("ReportSelection", currentStage);
    }

    /**
     * Exits the application and closes the connection to the database.
     */
    public void exit() {
        try {
            ConnectDB.closeConnection();
        }catch(Exception e){
            System.out.println("Error Closing Connection: \n"+e.toString());
        }
        System.exit(0);
    }

    /**
     * Sets various GUI elements to match the language selected
     */
    private void setFieldByLanguage() {
        ResourceBundle languages = ResourceBundle.getBundle("language");

        String customerButtonLabel,
                appointmentButtonLabel,
                reportsButtonLabel,
                exitButtonLabel;

        customerButtonLabel     = languages.getString("Customers");
        appointmentButtonLabel  = languages.getString("Appointments");
        reportsButtonLabel      = languages.getString("ReportSelection");
        exitButtonLabel         = languages.getString("Exit");

        customersButton.setText(customerButtonLabel);
        appointmentsButton.setText(appointmentButtonLabel);
        reportsButton.setText(reportsButtonLabel);
        exitButton.setText(exitButtonLabel);
    }
}