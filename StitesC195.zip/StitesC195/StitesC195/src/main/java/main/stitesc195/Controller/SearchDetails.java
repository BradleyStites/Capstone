package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.stage.Stage;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Contact;
import main.stitesc195.Model.Search;


/**
 * Contains the logic and variables for the "Search Details" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on Search selection.
 *
 * @author Bradley Stites
 */
public class SearchDetails implements Initializable {

    /**
     * button to run test selected in test combo box
     */
    public Button testButton;

    /**
     * combo Box for storing tests
     */
    public ComboBox testComboBox;

    /**
     * Label used to store text "Search ID".
     */
    @FXML
    public Label searchIdLabel;

    /**
     * Field used to store text for "Search ID".
     */
    @FXML
    public TextField searchIdField;

    /**
     * Label used to store text "type".
     */
    @FXML
    public Label typeLabel;
	
	/**
     * Label used to store text "description".
     */
    @FXML
    public Label descriptionLabel;

    /**
     * Field used to store the value of the description
     */
    @FXML
    public TextField descriptionField;

    /**
     * Field used to store search type.
     */
    @FXML
    public TextField typeField;
	
    /**
     * Label used to store text "title".
     */
    @FXML
    public Label titleLabel;

    /**
     * Field used to store search title.
     */
    @FXML
    public TextField titleField;
	
    /**
     * Label used to store text "user ID".
     */
    @FXML
    public Label userIdLabel;

    /**
     * Field used to store search userId.
     */
    @FXML
    public TextField userIdField;

    /**
     * Label used to store text "Customer ID".
     */
    @FXML
    public Label customerIdLabel;

    /**
     * Field used to store text for "Customer ID".
     */
    @FXML
    public TextField customerIdField;

    /**
     * Label used to store text "Contact".
     */
    @FXML
    public Label contactLabel;

    /**
     * Field used to store text for Search Variable for foreign Contact: "Contact Name".
     */
    @FXML
    public ComboBox contactComboBox;

    /**
     * Label for storing text representing "Start Date".
     */
    @FXML
    public Label startDateLabel;

    /**
     * A DatePicker used to pick the start date for the appointment.
     */
    @FXML
    public DatePicker startDatePicker;

    /**
     * Label for storing text representing "End Date".
     */
    @FXML
    public Label endDateLabel;

    /**
     * A DatePicker used to pick the end date for the appointment.
     */
    @FXML
    public DatePicker endDatePicker;

    /**
     * Label for storing text representing "Start Time".
     */
    @FXML
    public Label startTimeLabel;

    /**
     * ComboBox used to store the Start Hours of the appointment represented by 24-Hour format
     */
    @FXML
    public ComboBox startTimeHHComboBox;

    /**
     * ComboBox used to store the Start Minutes of the appointment represented by 0, 15, 30, 45
     */
    @FXML
    public ComboBox startTimeMMComboBox;

    /**
     * Label for storing text representing "End Time".
     */
    @FXML
    public Label endTimeLabel;

    /**
     * ObservableList used to store the various hour selections. Represented by 0-23, or a 24-Hour format.
     */
    ObservableList<Integer> hh;

    /**
     * ObservableList used to store the various minute selections. Represented by 0, 15, 30, 45.
     */
    ObservableList<Integer> mm;

    /**
     * ComboBox used to store the End Hours of the appointment represented by 24hr format
     */
    @FXML
    public ComboBox endTimeHHComboBox;

    /**
     * ComboBox used to store the End Minutes of the appointment represented by 0, 15, 30, 45
     */
    @FXML
    public ComboBox endTimeMMComboBox;

    /**
     * ObservableList used to store all contacts from the database and to attach any selected contact to an appointment.
     */
    ObservableList<Contact> contacts;

    /**
     * Contact object used to store a contact from the ComboBox selection
     */
    Contact contact;

    /**
     * Date representing the start date
     */
    Date startDate;

    /**
     * Date representing the end date
     */
    Date endDate;

    /**
     * String used to hold value for dateFormatter to display dates and times in desired format
     */
    String dateFormat = "yyyy-MM-dd HH:mm:ss";

    /**
     * SimpleDateFormat used to format a date in the pattern of the 'dateFormat' String
     */
    SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    /**
     * Label for storing text representing "Appointment Location" for an SearchDetails object.
     */
    @FXML
    public Label locationLabel;

    /**
     * A TextField used to store the location of the appointment for the SearchDetails object.
     */
    @FXML
    public TextField locationField;

    /**
     * Checkbox for storing value representing "Favorite".
     */
    @FXML
    public CheckBox favoriteCheckBox;

    /**
     * Button to save the form details into new or existing availability depending on context.
     */
    @FXML
    private Button searchButton;

    /**
     * Button to cancel input and return to previous screen, MainScreen.fxml
     */
    @FXML
    private Button cancelButton;

    /**
     * Button to send users to view search history screen, Searches.fxml
     */
    @FXML
    private Button searchHistoryButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert dates and times easily
     */
    DateHelper dateHelper;

    /**
     * SearchDetails object used to store a selected searches details or new search details
     */
    SearchDetails searchDetails;

    /**
     * Search object to hold the variables for the selected search
     */
    Search selectedSearch;

    /**
     * Sets the selected search.
     *
     * @param search  The search selected.
     */
    public void setSearch(Search search){
        this.selectedSearch = search;
    }

    /**
     * Sets the search id field to the input id.
     * @param id    the id of the selected role.
     */
    public void setSearchIDField(String id){
        this.searchIdField.setText(id);
    }

    /**
     * Initializes the SearchDetails class.
     * Sets the text of various gui elements to match language selection and loads details of search, if possible.
     *
     * @param url             The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle  The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //get list of all contacts
        contacts = ConnectDB.getAllContacts();

        //set contacts combo box items
        for (Contact c : contacts) {
            contactComboBox.getItems().add(c.getName());
        }

        for(int i=0; i<8; i++){
            testComboBox.getItems().add("test"+(i+1));
        }

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        hh = FXCollections.observableArrayList();
        for (int i = 0; i < 24; i++) {
            hh.add(i);
        }

        mm = FXCollections.observableArrayList();
        for (int i = 0; i < 60; i++) {
            if(i%15==0){
                mm.add(i);
            }
        }

        //set hh and mm boxes for both start and end
        startTimeHHComboBox.setItems(hh);
        endTimeHHComboBox.setItems(hh);

        startTimeMMComboBox.setItems(mm);
        endTimeMMComboBox.setItems(mm);

        //if updating a search
        if(ConnectDB.selectedSearch!=null) {
            selectedSearch = ConnectDB.selectedSearch;

            searchIdField.setText(""+ selectedSearch.getId());
			descriptionField.setText(selectedSearch.getDescription());
			locationField.setText(selectedSearch.getLocation());
			typeField.setText(selectedSearch.getType());
			titleField.setText(selectedSearch.getTitle());
            if(selectedSearch.getCustomerId()>0)
                customerIdField.setText("" + selectedSearch.getCustomerId());
            if(selectedSearch.getUserId()>0)
                userIdField.setText("" + selectedSearch.getUserId());

            //set contacts combo box
            for (Contact c : contacts) {
                if (selectedSearch.getContactId() == c.getId()) {
                    contactComboBox.setValue(c.getName());
                }
            }

			Boolean favorite = selectedSearch.getFavorite();
			favoriteCheckBox.setSelected(favorite);

            Date startDate, endDate;
            LocalDate ld;
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            if(selectedSearch.getStart()!=null){
                //get start date from the search object
                startDate = DateHelper.stringToDate(DateHelper.dateToString(selectedSearch.getStart()));

                //convert date from server to users local time
                String startDateString = DateHelper.adjustToTimeZone(startDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

                //set dates to newly converted values
                startDate 	= DateHelper.stringToDate(startDateString);

                //format values for fields & pickers
                String startFormatted 	= DateHelper.formatAppointmentDateForEdit(startDate);

                //set date picker
                ld = LocalDate.parse(startFormatted, currentDateFormat);
                startDatePicker.setValue(ld);

                //set start HH & MM combo picker
                startTimeHHComboBox.setValue(startDate.getHours());
                startTimeMMComboBox.setValue(startDate.getMinutes());
            }

            if(selectedSearch.getEnd()!=null){
                //get end date from the search object
                endDate   = DateHelper.stringToDate(DateHelper.dateToString(selectedSearch.getEnd()));

                //convert date from server to users local time
                String endDateString   = DateHelper.adjustToTimeZone(endDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

                //set dates to newly converted values
                endDate 	= DateHelper.stringToDate(endDateString);

                //format values for fields & picker
                String endFormatted 	= DateHelper.formatAppointmentDateForEdit(endDate);

                //set date picker
                ld = LocalDate.parse(endFormatted, currentDateFormat);
                endDatePicker.setValue(ld);

                //set end HH & MM combo picker
                endTimeHHComboBox.setValue(endDate.getHours());
                endTimeMMComboBox.setValue(endDate.getMinutes());
            }
        }
        setLanguage();
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
        String searchId, type, title, userId, customerId, contact, startDate, endDate, startTime, endTime, location, search, cancel, favorite, searchHistory, contactName, description;

        searchId 		= languages.getString("searchId");
		description		= languages.getString("description");
        location 		= languages.getString("location");
        type 			= languages.getString("type");
        title 			= languages.getString("title");
        startDate 		= languages.getString("startDate");
        endDate 		= languages.getString("endDate");
        startTime 		= languages.getString("startTime");
        endTime 		= languages.getString("endTime");
        customerId 		= languages.getString("customerId");
        userId 			= languages.getString("userId");
        contact 		= languages.getString("contact");
        contactName		= languages.getString("contactName");
        favorite 		= languages.getString("favorite");
        search 			= languages.getString("search");
        cancel 			= languages.getString("cancel");
        searchHistory 	= languages.getString("searchHistory");

        searchIdLabel.setText(searchId);
		descriptionLabel.setText(description);
		locationLabel.setText(location);
        typeLabel.setText(type);
		titleLabel.setText(title);

		startDateLabel.setText(startDate);
        endDateLabel.setText(endDate);
        startTimeLabel.setText(startTime);
        endTimeLabel.setText(endTime);

        customerIdLabel.setText(customerId);
        userIdLabel.setText(userId);
        contactLabel.setText(contact);
        contactComboBox.setValue(contactName);
        favoriteCheckBox.setText(favorite);

        searchButton.setText(search);
        cancelButton.setText(cancel);
        searchHistoryButton.setText(searchHistory);
    }

    /**
     * Logic for search button.
     * Determines if new or existing search and saves details from form. Adds search to the searches table.
     *
     * @throws SQLException if there is an error with the SQL statement or server.
     */
    public void search()throws SQLException{

        int searchId;
        Integer userId=-1;
        Integer customerId=-1;

        String description, title, type, location;

        //get values from fields
        String  searchIdString  = searchIdField.getText();

        description = descriptionField.getText();
        if (description != null && !description.trim().isEmpty()) {
            description = description.trim();
        }
        else
            description     = null;

        location = locationField.getText();
        if(location!=null && !location.trim().isEmpty())
            location		= location.trim();
        else
            location        = null;

        type = typeField.getText();
        if(type!=null && !type.trim().isEmpty())
            type	        = type.trim();
        else
            type            = null;


        title			= titleField.getText();
        if(title!=null && !title.trim().isEmpty())
            title           = title.trim();
        else
            title           = null;

        if(userIdField.getText() != null && !userIdField.getText().trim().isEmpty() && userIdField.getText()!="") {
            userId = Integer.valueOf(userIdField.getText());
        }

        if(!customerIdField.getText().trim().isEmpty()) {
            customerId = Integer.valueOf(customerIdField.getText());
        }

        //get values from contact combo box
        String contactName = contactComboBox.getValue().toString();

        /* get values for start and end dates */
        //convert start values to a date
        convertStartAndEndValuesToDate();

        //get favorite value
        boolean fav = favoriteCheckBox.isSelected();

        //set default value of new search to false
        Boolean newSearch;

        //check if new search or not
        if(searchIdString == null || searchIdString.isEmpty()){
            // This is a new search
            searchId = 0;
            newSearch = true;
        }else{
            //This is an existing search
            searchId = Integer.parseInt(searchIdString);
            newSearch = false;
        }

        int contactId;

        //get contact id
        contact = ConnectDB.getContactByName(contactName);
        if(contact!=null) {
            contactId = contact.getId();
        }else{
            contactId = -1;
        }

        //get the active user id
        int activeUserId = ConnectDB.userID;

        System.out.println("activeUserId: "+activeUserId);

        Search search = new Search(searchId, description, title, location, type, startDate, endDate, customerId, userId,
                contactId, fav, activeUserId);

		selectedSearch = search;

        Boolean success;

        if(newSearch) {
            success = ConnectDB.addSearch(search);
        }else {
            // This is an existing search
            success = ConnectDB.updateSearch(search);
        }

        if (success) {
            //search successful
            if(fav){
                String searchAdded = languages.getString("searchFavorite");
                viewLoader.showAlert(searchAdded);
            }

			//set the search object variable in ConnectDB to be pulled from the appointments screen
            ConnectDB.selectedSearch = selectedSearch;

			String searching = languages.getString("searching");
			viewLoader.showAlert(searching);

            //ensure not null
            if (selectedSearch == null) {
                String searchNull  = languages.getString("searchNull");
                viewLoader.showAlert(searchNull);
                return;
            }
            else{
                //load selected search into form
                Appointments appointments = new Appointments();
                appointments.setSearch(selectedSearch);
                appointments.initialize();
            }

            //Loads the Appointments screen
            loadAppointmentsScreen();

        } else {
            //there was a problem saving the search
            if(newSearch){
                String searchNotAdded = languages.getString("searchNotAdded");
                viewLoader.showAlert(searchNotAdded);
            }else{
                String searchNotUpdated = languages.getString("searchNotUpdated");
                viewLoader.showAlert(searchNotUpdated);
            }
        }
    }

    /**
     * Loads the Appointments screen.
     */
    public void loadAppointmentsScreen(){
        currentStage = (Stage) searchButton.getScene().getWindow();
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Sends the user to the search history screen, "Searches.fxml".
     */
    @FXML
    private void searchHistoryButton() {
        currentStage = (Stage) searchHistoryButton.getScene().getWindow();
        viewLoader.loadFXML("Searches", currentStage);
    }

    /**
     * Returns the user to the previous screen, "Searches.fxml".
     */
    private void returnToSearches() {
        currentStage = (Stage) cancelButton.getScene().getWindow();
        viewLoader.loadFXML("Searches", currentStage);
    }

    /**
     * Returns the user to the previous screen, "Searches.fxml".
     */
    public void cancel(){
        returnToSearches();
    }

    /**
     * Converts the values from the various Start and End combo boxes into date objects.
     * This function needs to be moved to the DateHelper class.
     */
    private void convertStartAndEndValuesToDate() {
        String start,end,startHH,startMM,endHH,endMM;
        String startSS="00",endSS="00";

        if(startDatePicker!=null && startDatePicker.getValue()!=null){
            start       = startDatePicker.getValue().toString();        //still need HH & MM
            startHH     = startTimeHHComboBox.getValue().toString();
            startMM     = startTimeMMComboBox.getValue().toString();
            String startString  = start + " " + startHH + ":" + startMM +":"+ startSS;
            try {
                startDate = dateFormatter.parse(startString);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }

        if(endDatePicker!=null && endDatePicker.getValue()!=null){
            end         = endDatePicker.getValue().toString();          //still need HH & MM
            endHH       = endTimeHHComboBox.getValue().toString();
            endMM       = endTimeMMComboBox.getValue().toString();
            String endString    = end   + " " + endHH   + ":" + endMM   +":"+ endSS;
            try {
                endDate   = dateFormatter.parse(endString);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void loadDetails(Search selectedSearch) {
        this.selectedSearch = selectedSearch;
    }

    public void initialize() {
    }

    private void runTest(Search search) {
        titleField.setText(search.getTitle());
        descriptionField.setText(search.getDescription());
        locationField.setText(search.getLocation());
        typeField.setText(search.getType());

        if(search.getStart()!=null){
            startDate = search.getStart();

            //set date pickers
            String startFormatted = DateHelper.formatAppointmentDateForEdit(startDate);
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
            startDatePicker.setValue(ld);

            //set start and end HH & MM combo pickers
            startTimeHHComboBox.setValue(startDate.getHours());
            startTimeMMComboBox.setValue(startDate.getMinutes());
        }


        if(search.getEnd()!=null){
            endDate = search.getEnd();

            //set date pickers
            String endFormatted = DateHelper.formatAppointmentDateForEdit(endDate);
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate ld = LocalDate.parse(endFormatted, currentDateFormat);
            endDatePicker.setValue(ld);

            endTimeHHComboBox.setValue(endDate.getHours());
            endTimeMMComboBox.setValue(endDate.getMinutes());
        }

        if(search.getCustomerId()>-1)
            customerIdField.setText(String.valueOf(search.getCustomerId()));
        if(search.getUserId()>-1)
            userIdField.setText(String.valueOf(search.getUserId()));

        favoriteCheckBox.setSelected(search.getFavorite());

        // !!! - also need to get the contact id from the combo box to match the id passed via GUI
    }

    public void test1(){

        int     searchId        = 0;
        String  title           = "Title_User2";
        String  description     = "";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = -1;
        int     userId          = 2;
        int     contactId       = -1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        //create an appointment for testing
        int     apptId          = -1;
        String  testName        = title;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, 1, userId, 1);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, description, title, location, type, null, null, customerId,
                userId, contactId, favorite, activeUserId);

        runTest(search);
    }

    public void test2(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "";
        String  location        = "";
        String  type            = "Type_User2";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = type;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, null, type, null, null, 0,
                userId, 0, favorite, activeUserId);

        runTest(search);
    }

    public void test3(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "Description_User2";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = -1;
        int     userId          = 2;
        int     contactId       = 0;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = description;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, 1, userId, 1);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, description, null, null, null, null, null,
                0, userId, 0, favorite, activeUserId);

        runTest(search);
    }

    public void test4(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "CustomerId_User2";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = description;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, null, null, null,
                null, customerId, userId, 0, favorite, activeUserId);

        runTest(search);
    }

    public void test5(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = description;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, null, null,
                null, null, 0, userId, contactId, favorite, activeUserId);

        runTest(search);
    }

    public void test6(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = description;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, null, null,
                startDate, null, 0, userId, 0, favorite, activeUserId);

        runTest(search);
    }

    public void test7(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "";
        String  location        = "";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = description;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, null, null, null,
                endDate, 0, userId, 0, favorite, activeUserId);

        runTest(search);
    }


    public void test8(){
        int     searchId        = 0;
        String  title           = "";
        String  description     = "";
        String  location        = "Location_User2";
        String  type            = "";
        Date    startDate;
        Date    endDate;
        int     customerId      = 1;
        int     userId          = 2;
        int     contactId       = 1;
        boolean favorite        = false;
        int     activeUserId    = 2;

        // create appointment for testing
        int     apptId          = 0;
        String  testName        = location;
        String  existingStartHH = "16";
        String  existingStartMM = "00";
        String  existingEndHH   = "16";
        String  existingEndMM   = "45";
        String  existingDate    = "2024-04-30";
        String  existingStart   = existingDate+ " "+existingStartHH +":"+existingStartMM+":00";
        String  existingEnd     = existingDate+ " "+existingEndHH   +":"+existingEndMM  +":00";
        startDate               = DateHelper.stringToDate(existingStart);
        endDate                 = DateHelper.stringToDate(existingEnd);

        //first delete all appointments
        System.out.println("Deleting all appointments: " + ConnectDB.deleteAllAppointments());

        //create a new appointment to force overlap
        Appointment appointment = new Appointment(apptId,testName,testName,testName,testName,startDate, endDate, startDate, testName, startDate, testName, customerId, userId, contactId);
        System.out.println("Creating appointment for testing: "+appointment.printAppointmentInformation());
        ConnectDB.addAppointment(appointment);

        Search search = new Search(searchId, null, null, location, null, null, null,
                0, userId, 0, favorite, activeUserId);

        runTest(search);
    }

    public void runTests() {
//get the test number from the combo box
        int selection = testComboBox.getSelectionModel().getSelectedIndex();

        //run test based on selection
        switch(selection) {
            case 0:
                test1();
                break;
            case 1:
                test2();
                break;
            case 2:
                test3();
                break;
            case 3:
                test4();
                break;
            case 4:
                test5();
                break;
            case 5:
                test6();
                break;
            case 6:
                test7();
                break;
            case 7:
                test8();
                break;
        }
    }
}