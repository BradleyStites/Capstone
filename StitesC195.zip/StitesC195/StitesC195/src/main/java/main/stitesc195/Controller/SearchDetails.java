package main.stitesc195.Controller;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;
import java.time.ZoneId;

import javafx.stage.Stage;
import main.stitesc195.Model.Contact;
import main.stitesc195.Model.Search;


/**
 * Contains the logic and variables for the "Search Details" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on Search selection.
 *
 * @author Bradley Stites
 */
public class SearchDetails implements Initializable {

    /**
     * Label used to store text "Search ID".
     */
    @FXML
    public Label searchIdLabel;

    /**
     * Field used to store text for "Search ID".
     */
    @FXML
    public TextField searchIdField;

    /**
     * Label used to store text "Title".
     */
    @FXML
    public Label titleLabel;

    /**
     * Field used to store search title.
     */
    @FXML
    public TextField titleField;

    /**
     * Label used to store text "Descrition".
     */
    @FXML
    public Label descriptionLabel;

    /**
     * Field used to store search description.
     */
    @FXML
    public TextField descriptionField;

    /**
     * Label used to store text "Type".
     */
    @FXML
    public Label typeLabel;

    /**
     * Field used to store text for Search Variable: "Type".
     */
    @FXML
    public TextField typeField;

    /**
     * Label used to store text "User ID".
     */
    @FXML
    public Label userIdLabel;

    /**
     * Field used to store text for "User ID".
     */
    @FXML
    public TextField userIdField;

    /**
     * Label used to store text "Customer ID".
     */
    @FXML
    public Label customerIdLabel;

    /**
     * Field used to store text for "Customer ID".
     */
    @FXML
    public TextField customerIdField;

    /**
     * Label used to store text "Contact".
     */
    @FXML
    public Label contactLabel;

    /**
     * Field used to store text for Search Variable for foreign Contact: "Contact Name".
     */
    @FXML
    public ComboBox contactComboBox;

    /**
     * Label for storing text representing "Start Date".
     */
    @FXML
    public Label startDateLabel;

    /**
     * A DatePicker used to pick the start date for the appointment.
     */
    @FXML
    public DatePicker startDatePicker;

    /**
     * Label for storing text representing "End Date".
     */
    @FXML
    public Label endDateLabel;

    /**
     * A DatePicker used to pick the end date for the appointment.
     */
    @FXML
    public DatePicker endDatePicker;

    /**
     * Label for storing text representing "Start Time".
     */
    @FXML
    public Label startTimeLabel;

    /**
     * ComboBox used to store the Start Hours of the appointment represented by 24-Hour format
     */
    @FXML
    public ComboBox startTimeHHComboBox;

    /**
     * ComboBox used to store the Start Minutes of the appointment represented by 0-59
     */
    @FXML
    public ComboBox startTimeMMComboBox;

    /**
     * Label for storing text representing "End Time".
     */
    @FXML
    public Label endTimeLabel;

    /**
     * ObservableList used to store the various hour selections. Represented by 0-23, or a 24-Hour format.
     */
    ObservableList<Integer> hh;

    /**
     * ObservableList used to store the various minute selections. Represented by 0-59.
     */
    ObservableList<Integer> mm;

    /**
     * ComboBox used to store the End Hours of the appointment represented by 24hr format
     */
    @FXML
    public ComboBox endTimeHHComboBox;

    /**
     * ComboBox used to store the End Minutes of the appointment represented by 0-59
     */
    @FXML
    public ComboBox endTimeMMComboBox;

    /**
     * ObservableList used to store all contacts from the database and to attach any selected contact to an appointment.
     */
    ObservableList<Contact> contacts;

    /**
     * Contact object used to store a contact from the ComboBox selection
     */
    Contact contact;

    /**
     * Date representing the start date
     */
    Date startDate;

    /**
     * Date representing the end date
     */
    Date endDate;

    /**
     * String used to hold value for dateFormatter to display dates and times in desired format
     */
    String dateFormat = "yyyy-MM-dd HH:mm:ss";

    /**
     * SimpleDateFormat used to format a date in the pattern of the 'dateFormat' String
     */
    SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    /**
     * DateTimeFormatter used to format a date in the pattern of the 'dateFormat' String
     */
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

    /**
     * Label for storing text representing "Time Zone".
     */
    @FXML
    public Label timeZoneLabel;

    /**
     * A ComboBox used to store the value of the selected time zone. Will also be used to convert date and time values
     * in various start and end ComboBoxes such as startTimeHHComboBox,startTimeMMComboBox, etc...
     */
    @FXML
    public ComboBox timeZoneComboBox;

    /**
     * Label for storing text representing "Appointment Location" for an SearchDetails object.
     */
    @FXML
    public Label locationLabel;

    /**
     * A TextField used to store the location of the appointment for the SearchDetails object.
     */
    @FXML
    public TextField locationField;

    /**
     * Label used to store text for "Favorite".
     */
    @FXML
    public Label favoriteLabel;

    /**
     * Checkbox for storing value representing "Favorite".
     */
    @FXML
    public CheckBox favoriteCheckBox;

    /**
     * Button to save the form details into new or existing availability depending on context.
     */
    @FXML
    private Button searchButton;

    /**
     * Button to cancel input and return to previous screen, MainScreen.fxml
     */
    @FXML
    private Button cancelButton;

    /**
     * Button to send users to view search history screen, Searches.fxml
     */
    @FXML
    private Button searchHistoryButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert dates and times easily
     */
    DateHelper dateHelper;

    /**
     * SearchDetails object used to store a selected searches details or new search details
     */
    SearchDetails searchDetails;

    /**
     * Search object to hold the variables for the selected search
     */
    Search selectedSearch;


    /**
     * Sets the selected search.
     *
     * @param searchDetails  The search selected.
     */
    public void setSearchDetails(SearchDetails searchDetails){
        this.searchDetails = searchDetails;
    }

    /**
     * Sets the search id field to the input id.
     * @param id    the id of the selected role.
     */
    public void setSearchIDField(String id){
        this.searchIdField.setText(id);
    }

    /**
     * Initializes the SearchDetails class.
     *
     * Sets the text of various gui elements to match language selection and loads details of search, if possible.
     *
     * @param url             The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle  The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        searchIdField = new TextField();
        searchIdField.setText(""+ selectedSearch.getSearchID());

        titleField = new TextField();
        titleField.setText(""+ selectedSearch.getTitle());

        descriptionField = new TextField();
        descriptionField.setText(""+ selectedSearch.getDescription());

        typeField = new TextField();
        typeField.setText(""+ selectedSearch.getType());

        userIdField = new TextField();
        userIdField.setText(""+ selectedSearch.getUserID());

        customerIdField = new TextField();
        customerIdField.setText(""+ selectedSearch.getCustomerID());

        //set start date
        startDateLabel = new Label();
        startDatePicker = new DatePicker();
        endDateLabel = new Label();
        endDatePicker = new DatePicker();
        startTimeLabel = new Label();
        startTimeHHComboBox = new ComboBox();
        startTimeMMComboBox = new ComboBox();
        endTimeLabel = new Label();
        endTimeHHComboBox = new ComboBox();
        endTimeMMComboBox = new ComboBox();

        //set time zone
        timeZoneLabel   = new Label();
        timeZoneComboBox = new ComboBox();

        //set location
        locationLabel = new Label();
        locationField = new TextField();

        //set search button and cancel buttons
        searchButton = new Button();
        cancelButton = new Button();

        //set favorite
        favoriteCheckBox = new CheckBox();

        //set search history
        searchHistoryButton = new Button();

        //if updating a search
        if(ConnectDB.selectedSearch!=null) {
            searchIdField.setText("" + selectedSearch.getSearchID());
            typeField.setText("" + selectedSearch.getType());
            userIdField.setText("" + selectedSearch.getUserID());
            customerIdField.setText("" + selectedSearch.getCustomerID());

            //set contacts combo box
            for (Contact c : contacts) {
                if (selectedSearch.getContactID() == c.getContactID()) {
                    contactComboBox.setValue(c.getContactName());
                }
            }

            //get dates from the search object
            Date startDate = ConnectDB.stringToDate(ConnectDB.dateToString(selectedSearch.getStart()));
            Date endDate   = ConnectDB.stringToDate(ConnectDB.dateToString(selectedSearch.getEnd()));

            //convert date from server to users local time
            String startDateString = ConnectDB.adjustToTimeZone(startDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String endDateString   = ConnectDB.adjustToTimeZone(endDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

            //set dates to newly converted values
            startDate 	= ConnectDB.stringToDate(startDateString);
            endDate 	= ConnectDB.stringToDate(endDateString);

            //format values for fields & pickers
            String startFormatted 	= ConnectDB.formatAppointmentDateForEdit(startDate);
            String endFormatted 	= ConnectDB.formatAppointmentDateForEdit(endDate);

            //set date pickers
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
            startDatePicker.setValue(ld);

            //set start and end HH & MM combo pickers
            startTimeHHComboBox.setValue(startDate.getHours());
            startTimeMMComboBox.setValue(startDate.getMinutes());

            ld = LocalDate.parse(endFormatted, currentDateFormat);
            endDatePicker.setValue(ld);

            endTimeHHComboBox.setValue(endDate.getHours());
            endTimeMMComboBox.setValue(endDate.getMinutes());
        }

        setLanguage();
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
        String searchId, type, userId, customerId, contact, startDate, endDate, startTime, endTime,
                timeZone, location, search, cancel, favorite, searchHistory, title, description, contactName,
                selectTimeZone;

        searchId 		= languages.getString("searchId");
        title 			= languages.getString("title");
        description 	= languages.getString("description");
        type 			= languages.getString("type");
        userId 			= languages.getString("userId");
        customerId 		= languages.getString("customerId");
        contact 		= languages.getString("contact");
        startDate 		= languages.getString("startDate");
        endDate 		= languages.getString("endDate");
        startTime 		= languages.getString("startTime");
        endTime 		= languages.getString("endTime");
        timeZone 		= languages.getString("timeZone");
        location 		= languages.getString("location");
        search 			= languages.getString("search");
        cancel 			= languages.getString("cancel");
        favorite 		= languages.getString("favorite");
        searchHistory 	= languages.getString("searchHistory");
        selectTimeZone 	= languages.getString("selectTimeZone");
        contactName		= languages.getString("contactName");


        searchIdLabel.setText(searchId);
        titleLabel.setText(title);
        descriptionLabel.setText(description);
        typeLabel.setText(type);
        userIdLabel.setText(userId);
        customerIdLabel.setText(customerId);

        contactLabel.setText(contact);
        contactComboBox.setValue(contactName);

        startDateLabel.setText(startDate);
        endDateLabel.setText(endDate);
        startTimeLabel.setText(startTime);
        endTimeLabel.setText(endTime);

        timeZoneLabel.setText(timeZone);
        timeZoneComboBox.setValue(selectTimeZone);
        locationLabel.setText(location);

        searchButton.setText(search);
        cancelButton.setText(cancel);
        favoriteCheckBox.setText(favorite);
        searchHistoryButton.setText(searchHistory);
    }

    /**
     * Logic for search button.
     *
     * Determines if new or existing search and saves details from form. Adds search to the searches table.
     *
     * @throws SQLException if there is an error with the SQL statement or server.
     */
    public void search()throws SQLException{

        int searchId;

        //get values from fields
        String  searchIdString  = searchIdField.getText();
        String  title	        = titleField.getText();
        String  desc		    = descriptionField.getText();
        String  type		    = typeField.getText();
        Integer userId          = Integer.valueOf(userIdField.getText());
        Integer customerId      = Integer.valueOf(customerIdField.getText());
        String  location        = locationField.getText();

        //get values from contact combo box
        String contactName = contactComboBox.getValue().toString();

        /* get values for start and end dates */
        //convert start values to a date
        convertStartAndEndValuesToDate();

        //get favorite value
        boolean fav = favoriteCheckBox.isSelected();

        //get zone id for timezone
        String timeZone = timeZoneComboBox.getSelectionModel().getSelectedItem().toString();
        ZoneId timeZoneId = ZoneId.of(timeZone);
        String timeZoneIdString = String.valueOf(timeZoneId);

        //set default value of new search to false
        Boolean newSearch;

        //check if new search or not
        if(searchIdString == null || searchIdString.isEmpty()){
            // This is a new search
            searchId = ConnectDB.generateNewSearchID();
            newSearch = true;
        }else{
            //This is an existing search
            searchId = Integer.parseInt(searchIdString);
            newSearch = false;
        }

        //get contact id
        contact = ConnectDB.getContactByName(contactName);
        int contactId = contact.getContactID();

        //get the active user id
        int activeUserId = ConnectDB.activeUserId;

        Search search = new Search(searchId, title, desc, location, type, startDate, endDate, customerId, userId,
                contactId, fav, timeZoneIdString, activeUserId);

        Boolean success;

        if(newSearch) {
            success = ConnectDB.addSearch(search);
        }else {
            // This is an existing search
            success = ConnectDB.updateSearch(search);
        }

        if (success) {
            //search successful
            if(fav){
                String searchAdded = languages.getString("searchFavorited");
                viewLoader.showAlert(searchAdded);
            }else{
                String searching = languages.getString("searching");
                viewLoader.showAlert(searching);
            }

            //set the search object variable in the appointments screen? -might be akin to loading details pages with objects
            ConnectDB.selectedSearch = selectedSearch;

            //ensure not null
            if (searchDetails == null) {
                String searchNull  = languages.getString("searchNull");
                viewLoader.showAlert(searchNull);
                return;
            }
            else{
                //load selected search into form
                Appointments appointments = new Appointments();
                appointments.setSearch(selectedSearch);
                appointments.initialize();
            }

            //Loads the Appointments screen
            loadAppointmentsScreen();

        } else {
            //there was a problem saving the search
            if(newSearch){
                String searchNotAdded = languages.getString("searchNotAdded");
                viewLoader.showAlert(searchNotAdded);
            }else{
                String searchNotUpdated = languages.getString("searchNotUpdated");
                viewLoader.showAlert(searchNotUpdated);
            }
        }
    }

    /**
     * Loads the Appointments screen.
     */
    public void loadAppointmentsScreen(){
        viewLoader.loadFXML("Appointments", currentStage);
    }

    /**
     * Sends the user to the search history screen, "Searches.fxml".
     */
    private void searchHistoryButton() {
        currentStage = (Stage) searchHistoryButton.getScene().getWindow();
        viewLoader.loadFXML("Searches", currentStage);
    }

    /**
     * Returns the user to the previous screen, "Admin.fxml".
     */
    private void returnToAdmin() {
        currentStage = (Stage) searchButton.getScene().getWindow();
        viewLoader.loadFXML("Admin", currentStage);
    }

    /**
     * Returns the user to the previous screen, "Admin.fxml".
     */
    public void cancel(){
        returnToAdmin();
    }

    /**
     * Converts the values from the various Start and End combo boxes into date objects.
     *
     * This function needs to be moved to the DateHelper class.
     */
    private void convertStartAndEndValuesToDate() {
        String start,end,startHH,startMM,endHH,endMM,timeZone;

        start       = startDatePicker.getValue().toString();       //still need HH, MM, & timeZone to be complete
        end         = endDatePicker.getValue().toString();         //still need HH, MM, & timeZone to be complete
        startHH     = startTimeHHComboBox.getValue().toString();
        startMM     = startTimeMMComboBox.getValue().toString();

        endHH       = endTimeHHComboBox.getValue().toString();
        endMM       = endTimeMMComboBox.getValue().toString();

        timeZone    = timeZoneComboBox.getValue().toString();

        String startSS="00",endSS="00";

        //generate string for start & end
        String startString  = start + " " + startHH + ":" + startMM +":"+ startSS;
        String endString    = end   + " " + endHH   + ":" + endMM   +":"+ endSS;

        try {
            startDate = dateFormatter.parse(startString);
            endDate   = dateFormatter.parse(endString);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
}