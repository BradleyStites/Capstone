package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.stitesc195.Model.*;

import java.io.InputStream;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.Scanner;

/**
 * Contains the logic,functions,and variables that are useful for connecting to the Database.
 *
 * @author Bradley Stites
 */
public class ConnectDB {

    /**
     * a role object used to hold the role values of the active user
     */
    public static UserRole activeUserRole;

    /**
     * User Role object represents a selected user role.
     */
    public static UserRole selectedRole;

    /**
     * Availability object represents a selected availability.
     */
    public static Availability selectedAvailability;

    /**
     * String to store the name of the database
     */
    private static final String databaseName 				= "client_schedule";

    /**
     * string to store the url connection for the database
     */
    private static final String url = "jdbc:mysql://127.0.0.1:3306/" + databaseName + "?useSSL=false&allowPublicKeyRetrieval=true";

    /**
     * username to connect to the database
     */
    private static final String userName 					= "sqlUser";

    /**
     * password for the database
     */
    private static final String password 					= "Passw0rd!";

    /**
     * string for the mysql driver
     */
    private static final String driver 						= "com.mysql.jdbc.Driver";

    /**
     * name of the customers table
     */
    private static final String customerTable 				= "customers";

    /**
     * name of the appointments table
     */
    private static final String appointmentsTable		 	= "appointments";

    /**
     * name of the contacts table
     */
    private static final String contactsTable 				= "contacts";

    /**
     * name of countries table
     */
    private static final String countriesTable 				= "countries";

    /**
     * string for the name of the role table
     */
    private static final String rolesTable 					= "user_roles";

    //Administrator Table
    /**
     * string for the name of the administrators table
     */
    private static final String administratorsTable 		= "administrators";

    /**
     * string for the name of the admin id column in the administrators table
     */
    private static final String adminIDCol      			= "Admin_ID";

    /**
     * string for the name of the role id column in the administrators table
     */
    private static final String adminRoleIdCol  			= "Role_ID";

    /**
     * string for the name of the user id column in the administrators table
     */
    private static final String adminUserIdCol  			= "User_ID";

    //user availabilities table
    /**
     * string for the name of the user availability table
     */
    private static final String userAvailabilityTable       = "user_availability";

    /**
     * string for the name of the availability id column in the user availabilities table
     */
    private static final String availabilitiesIdCol         = "Availability_ID";

    /**
     * string for the name of the user id column in the user availabilities table
     */
    private static final String availabilitiesUserIdCol     = "User_ID";

    /**
     * string for the name of the start column in the user availabilities table
     */
    private static final String availabilitiesStartCol      = "Start";

    /**
     * string for the name of the end column in the user availabilities table
     */
    private static final String availabilitiesEndCol        = "End";

    /**
     * string for the name of the status column in the user availabilities table
     */
    private static final String availabilitiesStatusCol     = "Status";

    /**
     * string for the name of the repeat frequency column in the user availabilities table
     */
    private static final String availabilitiesRepeatFreqCol = "RepeatFrequency";

    /**
     * string for the name of the repeat end date column in the user availabilities table
     */
    private static final String availabilitiesRepeatEndCol  = "Repeat_End_Date";

    /**
     * string for the name of the details column in the user availabilities table
     */
    private static final String availabilitiesDetailsCol    = "Details";

    //Searches Table
    /**
     * string for the name of the searches table
     */
    private static final String searchesTable           	= "searches";

    /**
     * string for the name of the search id column in the searches table
     */
    private static final String searchIDCol             	= "Search_ID";

    /**
     * string for the name of the user id column in the searches table
     */
    private static final String searchUserIdCol         	= "User_ID";

    /**
     * string for the name of the start column in the searches table
     */
    private static final String searchStartCol          	= "Start";

    /**
     * string for the name of the end column in the searches table
     */
    private static final String searchEndCol            	= "End";

    /**
     * string for the name of the type column in the searches table
     */
    private static final String searchTypeCol           	= "Type";

    /**
     * string for the name of the title column in the searches table
     */
    private static final String searchTitleCol          	= "Title";

    /**
     * string for the name of the description column in the searches table
     */
    private static final String searchDescriptionCol    	= "Description";

    /**
     * string for the name of the favorite column in the searches table
     */
    private static final String searchFavoriteCol       	= "Favorite";

    /**
     * string for the name of the customer id column in the searches table
     */
    private static final String searchCustomerIdCol     	= "Customer_ID";

    /**
     * string for the name of the contact id column in the searches table
     */
    private static final String searchContactIdCol      	= "Contact_ID";

    /**
     * string for the name of the location column in the searches table
     */
    private static final String searchLocationCol       	= "Location";

    /**
     * string for the name of the owner id column in the searches table
     */
    private static final String searchOwnerIdCol        	= "Owner_ID";

    /**
     * string for the row count column - used in function: checkForUsersAssignedToRole
     */
    private static final String rowCountCol 				= "count(*)";

    /**
     * string for the name of the role description field
     */
    private static final String roleDescCol 				= "Role_Description";

    /**
     * string value for the name of the 'canResetPassword' variable
     */
    private static final String roleAdminCol 				= "Administrator";

    /**
     * first level divisions table name
     */
    private static final String firstLevelDivisionsTable 	= "first_level_divisions";

    /**
     * string for the users table name
     */
    private static final String usersTable 					= "users";

    // Columns for Roles Table
    /**
     * string for the role id column name
     */
    private static final String roleIDCol 					= "Role_ID";

    // Columns for Users Table
    /**
     * string for the user id column for user table
     */
    private static final String userIDCol 					= "User_ID";

    /**
     * string for the username column for user table
     */
    private static final String userNameCol 				= "User_Name";

    /**
     * string for the password column for user table
     */
    private static final String userPassCol 				= "Password";

    /**
     * string for storing the column name of the creation date for user table
     */
    private static final String userCreateDateCol 			= "Create_Date";

    /**
     * string for the created by column in the user table
     */
    private static final String userCreatedByCol 			= "Created_By";

    /**
     * string for the last updated column in the user table
     */
    private static final String userLastUpdateCol 			= "Last_update";

    /**
     * string for the last updated by column in the user table
     */
    private static final String userLastUpdatedByCol 		= "Last_updated_by";

    // Customer Table Columns
    /**
     * string for the customer id column in the customer table
     */
    private static final String customerIDCol 				= "Customer_ID";

    /**
     * string for the customer name column
     */
    private static final String customerNameCol 			= "Customer_Name";

    /**
     * string for the customer address column
     */
    private static final String customerAddressCol 			= "Address";

    /**
     * string for the customer postal code column
     */
    private static final String customerPostCodeCol 		= "Postal_Code";

    /**
     * string for the customer phone column
     */
    private static final String customerPhoneCol 			= "Phone";

    /**
     * string for the customer create date column
     */
    private static final String customerCreateDateCol 		= "Create_Date";

    /**
     * string for the customer created by column
     */
    private static final String customerCreatedByCol 		= "Created_By";

    /**
     * string for the customer last update column
     */
    private static final String customerLastUpdateCol       = "Last_Update";

    /**
     * string for the customer last updated by column
     */
    private static final String customerLastUpdatedByCol    = "Last_updated_by";

    /**
     * string for the customer division id column
     */
    private static final String customerDivisionIDCol 		= "Division_id";

    // Appointment Table Columns
    /**
     * string for the appointment id column
     */
    private static final String appointmentIDCol 			= "Appointment_ID";

    /**
     * string for appointment title column
     */
    private static final String appointmentTitleCol 		= "Title";

    /**
     * string for appointment description column
     */
    private static final String appointmentDescriptionCol 	= "Description";

    /**
     * string for appointment location column
     */
    private static final String appointmentLocationCol 		= "Location";

    /**
     * string for appointment type column
     */
    private static final String appointmentTypeCol 			= "Type";

    /**
     * string for appointment start column
     */
    private static final String appointmentStartCol 		= "Start";

    /**
     * string for appointment end column
     */
    private static final String appointmentEndCol 			= "End";

    /**
     * string for appointment created date column
     */
    private static final String appointmentCreateDateCol 	= "Create_Date";

    /**
     * string for appointment created by column
     */
    private static final String appointmentCreatedByCol 	= "Created_By";

    /**
     * string for appointment last update column
     */
    private static final String appointmentLastUpdateCol 	= "Last_Update";

    /**
     * string for appointment last updated by column
     */
    private static final String appointmentLastUpdateByCol 	= "Last_updated_by";

    /**
     * string for appointment customer id column
     */
    private static final String appointmentCustomerIDCol 	= "Customer_id";

    /**
     * string for appointment user id column
     */
    private static final String appointmentUserIDCol 		= "User_id";

    /**
     * string for appointment contact id column
     */
    private static final String appointmentContactIDCol 	= "Contact_id";

    // Country Table Columns
    /**
     * string for country id column
     */
    private static final String countryIDCol 				= "Country_ID";

    /**
     * string for country name column
     */
    private static final String countryCol 					= "Country";

    /**
     * string for country created date column
     */
    private static final String countryCreatedDateCol 		= "Create_Date";

    /**
     * string for country created by column
     */
    private static final String countryCreatedByCol 		= "Created_By";

    /**
     * string for country last updated column
     */
    private static final String countryLastUpdateCol 		= "Last_Update";

    /**
     * string for country last updated by column
     */
    private static final String countryLastUpdatedByCol 	= "Last_Updated_By";

    // Division Table Columns
    /**
     * string for division id column
     */
    private static final String divisionIDCol 				= "Division_ID";

    /**
     * string for division name column
     */
    private static final String divisionCol 				= "Division";

    /**
     * string for division created date column
     */
    private static final String divisionCreatedDateCol 		= "Create_Date";

    /**
     * string for division created by column
     */
    private static final String divisionCreatedByCol 		= "Created_By";

    /**
     * string for division last updated column
     */
    private static final String divisionLastUpdatedCol 		= "Last_Update";

    /**
     * string for division last updated by column
     */
    private static final String divisionLastUpdatedByCol 	= "Last_Updated_By";

    /**
     * string for division country id column
     */
    private static final String divisionCountryIDCol 		= "Country_ID";

    // Contact Columns
    /**
     * string for contact id column
     */
    private static final String contactIDCol 				= "Contact_ID";

    /**
     * string for contact name column
     */
    private static final String contactNameCol 				= "Contact_Name";

    /**
     * string for contact email column
     */
    private static final String contactEmailCol 			= "Email";

    /**
     * string for storing the name and extension of the logfile
     */
    public static final String logFile 						= "login_activity.txt";

    /**
     * Represents a static Connection object that can be used by other classes to connect to a database.
     */
    public static Connection conn;

    /**
     * int represents the active user id
     */
    public static int userID = -1;

    /**
     * string represents the active username
     */
    public static String activeUserName 					= "";

    /**
     * Customer object represents a selected customer
     */
    public static Customer selectedCustomer;

    /**
     * User object represents a selected user
     */
    public static User selectedUser;

    /**
     * Appointment object represents a selected appointment.
     */
    public static Appointment selectedAppointment;

    /**
     * Search object represents a selected search`.
     */
    public static Search selectedSearch;

    /**
     * ZoneId used to represent the user's time zone
     */
    public static ZoneId userTimeZoneId = ZoneId.systemDefault();                       //ZoneId for User

    /**
     * ZoneId used to represent the server's time zone
     */
    public static ZoneId serverTimeZoneId = ZoneId.of("UTC");                    //UTC

    /**
     * zone id used to represent the business's time zone
     */
    public static ZoneId businessTimeZoneId = ZoneId.of("America/New_York");    //EST

    /**
     * a string used to get the current time stamp
     */
    public static String currentTimeString 					= "current_timestamp()";

    /**
     * a string to get the now value from the database
     */
    public static String nowString 							= "now()";

    /**
     * a string used to hold the value of a sql command
     */
    public static String sqlString;

    /**
     * an integer used to hold the value of the application's active user id.
     */
    public static int activeUserId;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    static ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * This method establishes a connection to the database using the specified driver, url, username, and password.
     * It returns a connection object that represents the database connection.
     *
     * @return the connection object representing the database connection.
     */
    public static Connection connect() {
        try {
            conn = DriverManager.getConnection(url, userName, password);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("[ConnectDB.java] Error establishing connection.");
        }
        return conn;
    }

    /**
     * Closes the connection to the database
     *
     * @throws SQLException if there is an error with the sql statement or server.
     */
    public static void closeConnection() throws SQLException {
        conn.close();
    }

    /**
     * Gets the date from the server.
     *
     * @return the current date from the server.
     * @throws SQLException If there is an error with the server or sql command.
     */
    public static java.util.Date getDateFromServer() throws SQLException {

        java.util.Date date = null;
        sqlString = "Select " + nowString;
        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            String outputString = result.getString("now()");
            date = DateHelper.stringToDate(outputString);
        }

        return date;
    }

    /**
     * sets the database to UTC to ensure operation as intended
     *
     * @throws SQLException SQLException in case something goes wrong
     */
    public static void setDBtoUTC() throws SQLException {
        String sqlString = "SET GLOBAL time_zone = '+00:00'";
        Statement statement = ConnectDB.conn.createStatement();
        int rowsAffected = statement.executeUpdate(sqlString);

        if (rowsAffected >= 0) {
            System.out.println("Time zone set successfully");
        } else {
            System.out.println("Failed to set time zone");
        }
    }

    /**
     * Converts a string to a date
     *
     * @param input String value of a date
     * @return the date represented by the string
     */
    public static java.util.Date stringToDate(String input) {
        java.util.Date date;

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = df.parse(input);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        return date;
    }

    /**
     * gets the countries from the database
     *
     * @return an observable list with the countries
     * @throws SQLException if there is an error with the sql command or server
     */
    public static ObservableList<Country> getCountries() throws SQLException {
        ObservableList<Country> countries = FXCollections.observableArrayList();

        sqlString = "Select * from " + countriesTable;

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Country country;

        while (result.next()) {
            Integer countryID = result.getInt(countryIDCol);
            String countryName = result.getString(countryCol);
            Timestamp countryCreatedDate = result.getTimestamp(countryCreatedDateCol);
            String countryCreatedBy = result.getString(countryCreatedByCol);
            Timestamp countryLastUpdate = result.getTimestamp(countryLastUpdateCol);
            String countryLastUpdatedBy = result.getString(countryLastUpdatedByCol);

            country = new Country(countryID, countryName, countryCreatedDate, countryCreatedBy, countryLastUpdate, countryLastUpdatedBy);
            countries.add(country);
        }

        return countries;
    }

    /**
     * gets the country by the country id
     *
     * @param id the id of the country
     * @return the country
     * @throws SQLException if there is an error with the server or sql command.
     */
    public static Country getCountryById(int id) throws SQLException {

        Country country = null;


        sqlString = "Select * from " + countriesTable +
					" WHERE " + countryIDCol + "=" + id;
        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            String countryName = result.getString(countryCol);
            Integer countryID = result.getInt(countryIDCol);
            Timestamp created = result.getTimestamp(countryCreatedDateCol);
            String createdBy = result.getString(countryCreatedByCol);
            Timestamp updated = result.getTimestamp(countryLastUpdateCol);
            String updatedBy = result.getString(countryLastUpdatedByCol);

            country = new Country(countryID, countryName, created, createdBy, updated, updatedBy);
        }

        return country;
    }

    /**
     * gets the country name by the division id
     *
     * @param id the id of the division
     * @return the country name
     * @throws SQLException if there is an error with the server or sql command.
     */
    public static String getCountryNameByDivisionId(int id) throws SQLException {

        sqlString = "SELECT DISTINCT Country " + "\n" +
                    "FROM first_level_divisions " + "\n" +
                    "JOIN countries ON first_level_divisions.Country_ID =  countries.Country_ID " + "\n" +
                    "WHERE first_level_divisions.Division_ID=" + id;
        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        String countryName = null;

        while (result.next()) {
            countryName = result.getString(countryCol);
        }

        return countryName;
    }

    /**
     * gets the country by the country name
     *
     * @param name the name of the country
     * @return the country represented by the name
     * @throws SQLException if there is an error with the sql server or sql command
     */
    public static Country getCountryByName(String name) throws SQLException {

        Country country = null;

        sqlString = "SELECT * FROM " + countriesTable + "\n" +
					"WHERE " + countryCol + "='" + name + "'";

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            String countryName = result.getString(countryCol);
            Integer countryID = result.getInt(countryIDCol);
            Timestamp created = result.getTimestamp(countryCreatedDateCol);
            String createdBy = result.getString(countryCreatedByCol);
            Timestamp updated = result.getTimestamp(countryLastUpdateCol);
            String updatedBy = result.getString(countryLastUpdatedByCol);

            country = new Country(countryID, countryName, created, createdBy, updated, updatedBy);
        }

        return country;
    }

    /**
     * gets the division by the division id
     *
     * @param id the division id
     * @return the division
     * @throws SQLException if there is an error with the sql or server
     */
    public static Division getDivisionByID(int id) throws SQLException {

        Division div = new Division();

        String sqlString = "Select * from " + firstLevelDivisionsTable +
						   " WHERE " + divisionIDCol + "=" + id;
        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            Integer divisionID = result.getInt(divisionIDCol);
            String division = result.getString(divisionCol);
            Timestamp created = result.getTimestamp(divisionCreatedDateCol);
            String createdBy = result.getString(divisionCreatedByCol);
            Timestamp updated = result.getTimestamp(divisionLastUpdatedCol);
            String updatedBy = result.getString(divisionLastUpdatedByCol);
            Integer countryID = result.getInt(divisionCountryIDCol);

            div = new Division(divisionID, division, created, createdBy, updated, updatedBy, countryID);
        }

        return div;
    }

    /**
     * gets the divisions by country name
     *
     * @param countryName the country name
     * @return observable list of the divisions that are represented by the country name
     * @throws SQLException if there is an error with the sql or server
     */
    public static ObservableList<Division> getDivisionsByCountryName(String countryName) throws SQLException {

        ObservableList<Division> filteredDivisionsList = FXCollections.observableArrayList();

        //get the country id for the country name
        Country country = getCountryByName(countryName);

        String sqlString = "Select * from " + firstLevelDivisionsTable +
						   " WHERE " + countryIDCol + "=" + country.getId();

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            Integer divisionID = result.getInt(divisionIDCol);
            String division = result.getString(divisionCol);
            Timestamp created = result.getTimestamp(divisionCreatedDateCol);
            String createdBy = result.getString(divisionCreatedByCol);
            Timestamp updated = result.getTimestamp(divisionLastUpdatedCol);
            String updatedBy = result.getString(divisionLastUpdatedByCol);
            Integer countryID = result.getInt(divisionCountryIDCol);

            Division div = new Division(divisionID, division, created, createdBy, updated, updatedBy, countryID);
            filteredDivisionsList.add(div);
        }

        return filteredDivisionsList;
    }

    /**
     * gets the divisions from the database
     *
     * @return the list of divisions
     * @throws SQLException if there is an error with the sql or server
     */
    public static ObservableList<Division> getDivisions() throws SQLException {
        ObservableList<Division> divisionsList = FXCollections.observableArrayList();

        sqlString = "SELECT * " + "\n" +
                    "FROM " + firstLevelDivisionsTable;

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Division div;

        while (result.next()) {
            Integer divisionID = result.getInt(divisionIDCol);
            String division = result.getString(divisionCol);
            Timestamp divisionCreatedDate = result.getTimestamp(divisionCreatedDateCol);
            String divisionCreatedBy = result.getString(divisionCreatedByCol);
            Timestamp divisionLastUpdate = result.getTimestamp(divisionLastUpdatedCol);
            String divisionLastUpdatedBy = result.getString(divisionLastUpdatedByCol);
            Integer divisionCountryID = result.getInt(divisionCountryIDCol);

            div = new Division(divisionID, division, divisionCreatedDate, divisionCreatedBy, divisionLastUpdate, divisionLastUpdatedBy, divisionCountryID);
            divisionsList.add(div);
        }


        return divisionsList;
    }

    /**
     * gets the username by the user id
     *
     * @param id the user id
     * @return the username
     * @throws SQLException if there is an error in the sql or server
     */
    public static String getUserNameById(int id) throws SQLException {

        String name = "";

        sqlString = "SELECT "   + userNameCol   + "\n"  +
                    "FROM "     + databaseName  + "."   + usersTable    + "\n" +
					"WHERE "    + userIDCol     + "="   + id            + ";";

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            name = result.getString(userNameCol);
        }

        return name;
    }

    /**
     * gets all contacts from the database
     *
     * @return list of contacts
     */
    public static ObservableList<Contact> getAllContacts() {
        ObservableList<Contact> contacts = FXCollections.observableArrayList();

        sqlString = "SELECT * " + "\n" +
                    "FROM " + databaseName + "." + contactsTable;

        try {
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while (result.next()) {
                Integer id = result.getInt(contactIDCol);
                String name = result.getString(contactNameCol);
                String email = result.getString(contactEmailCol);

                contacts.add(new Contact(id, name, email));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contacts;
    }

    /**
     * gets a contact from a contact's name
     *
     * @param contactName the contact name
     * @return the contact
     */
    public static Contact getContactByName(String contactName) {
        Contact contact = null;

        sqlString = "SELECT *"  + "\n"              +
                    "FROM "     + databaseName      + "."  + contactsTable  +
					" WHERE "   + contactNameCol    + "='" + contactName    + "';";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while (result.next()) {
                Integer id = result.getInt(contactIDCol);
                String name = result.getString(contactNameCol);
                String email = result.getString(contactEmailCol);

                contact = new Contact(id, name, email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contact;
    }

    /**
     * gets the customers from the database
     *
     * @return the list of customers
     * @throws SQLException if there is an error in the sql or server
     */
    public static ObservableList<Customer> getCustomers() throws SQLException {
        ObservableList<Customer> customerList = FXCollections.observableArrayList();

        sqlString = "Select *"  + "\n" +
                    "from "     + customerTable;

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Customer customer;

        while (result.next()) {
            Integer id = result.getInt(customerIDCol);
            String name = result.getString(customerNameCol);
            String addr = result.getString(customerAddressCol);
            String postcode = result.getString(customerPostCodeCol);
            String phone = result.getString(customerPhoneCol);
            Timestamp createDate = result.getTimestamp(customerCreateDateCol);
            String createdBy = result.getString(customerCreatedByCol);
            Timestamp lastUpdate = result.getTimestamp(customerLastUpdateCol);
            String lastUpdatedBy = result.getString(customerLastUpdatedByCol);
            Integer divisionID = result.getInt(customerDivisionIDCol);

            customer = new Customer(id, name, addr, postcode, phone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
            customerList.add(customer);
        }

        return customerList;
    }

    /**
     * adds a customer to the database. returns true or false depending on success.
     *
     * @param   customer      customer to be added to the database
     * @return  TRUE  if successful,
	 *			FALSE if unsuccessful
     */
    public static Boolean addCustomer(Customer customer) {

        sqlString = "INSERT INTO " + databaseName   + "." + customerTable + "(" +
					customerNameCol 		        + ","   +
					customerAddressCol  	        + ","   +
					customerPostCodeCol 	        + ","   +
					customerPhoneCol 		        + ","   +
					customerCreateDateCol 	        + ","   +
					customerCreatedByCol 	        + ","   +
                    customerLastUpdateCol           + ","   +
                    customerLastUpdatedByCol        + ","   +
					customerDivisionIDCol 	        + ")\n" +

					"VALUES(" 				 +
					customer.printCustomerInfo() +");";

                    System.out.println(sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * edits a customer object in the database. returns an integer depending on success.
     *
     * @param customer the customer object being edited.
     * @return >0 = success
     */
    public static Integer editCustomer(Customer customer) {

        sqlString = "UPDATE " + databaseName + "." + customerTable + "\n" +
                    "SET " 	  +
					customerNameCol 		 + "='" + customer.getName() 	+ "', "   +
                    customerAddressCol 		 + "='" + customer.getAddress() 		+ "', "   +
                    customerPostCodeCol 	 + "='" + customer.getPostalCode() 		+ "', "   +
                    customerPhoneCol 		 + "='" + customer.getPhone() 			+ "', "   +
                    customerLastUpdateCol    + "="  + currentTimeString 			+ ", "    +
                    customerLastUpdatedByCol + "='" + customer.getUpdatedBy() 	+ "', "   +
                    customerDivisionIDCol 	 + "='" + customer.getDivisionID() 		+ "' \n"  +
                    "WHERE " + customerIDCol + "="  + customer.getId();

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return result;
            } else {
                return -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * deletes a customer object from the database. returns an integer depending on the success.
     *
     * @param customer the selected customer to be deleted.
     * @return >0 = success.
     */
    public static int deleteCustomer(Customer customer) {

        sqlString = "DELETE FROM " + databaseName + "." + customerTable +
					" WHERE " + customerIDCol + "='" + customer.getId() + "'";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return result;
            } else {
                return -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * gets the current date time zone
     *
     * @return the formatter for the date time formatter
     */
    public static DateTimeFormatter getCurrentDateTimeZone() {

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

        return formatter;
    }

    /**
     * adds an appointment object to the database
     *
     * @param appointment the appointment object to be added
     * @return true if successful, false if unsuccessful
     */
    public static Boolean addAppointment(Appointment appointment) {

        sqlString = "INSERT INTO " + databaseName + "." + appointmentsTable + "(" +
					appointmentTitleCol 		+ ","  +
					appointmentDescriptionCol 	+ ","  +
					appointmentLocationCol 		+ ","  +
					appointmentTypeCol 			+ ","  +
					appointmentStartCol 		+ ","  +
					appointmentEndCol 			+ ","  +
					appointmentCreateDateCol 	+ ","  +
					appointmentCreatedByCol 	+ ","  +
					appointmentLastUpdateCol 	+ ","  +
					appointmentLastUpdateByCol 	+ ","  +
					appointmentCustomerIDCol 	+ ","  +
					appointmentUserIDCol 		+ ","  +
					appointmentContactIDCol 	+ ") " + "\n" +
					"VALUES (" + appointment.printAppointmentInformation() + ");";

        System.out.println("addAppointment: \n"+sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * set timezone on database to be the correct value - sometimes it isn't set properly to 'UTC'
     *
     * @return True if successful, false if not successful
     */
    public static Boolean setTimezoneOnServer() {

        sqlString = "set time_zone = '+00:00';";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * updates an existing appointment object in the database
     *
     * @param appointment appointment being updated
     * @return True if successful, false if not successful
     */
    public static Boolean updateAppointment(Appointment appointment) {
        String startString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(appointment.getStart());
        String endString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(appointment.getEnd());
        String lastUpdateString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(appointment.getUpdate());

        sqlString = "UPDATE " + databaseName + "." + appointmentsTable + "\n" +
                "SET " +
				appointmentTitleCol 		+ "='"  + appointment.getTitle() 		+ "', "  +
                appointmentTypeCol 			+ "= '" + appointment.getType() 		+ "', "  +
                appointmentDescriptionCol 	+ "= '" + appointment.getDescription() 	+ "', "  +
                appointmentCustomerIDCol 	+ "= "  + appointment.getCustomerID() 	+ ", "   +
                appointmentUserIDCol 		+ "= "  + appointment.getUserID() 		+ ", "   +
                appointmentStartCol 		+ "= '" + startString 					+ "', "  +
                appointmentEndCol 			+ "= '" + endString 					+ "', "  +
                contactIDCol 				+ "= "  + appointment.getContactID() 	+ ",  "  +
                appointmentLocationCol 		+ "= '" + appointment.getLocation() 	+ "', "  +
                appointmentLastUpdateCol 	+ "= '" + lastUpdateString 				+ "'\n"  +

                "WHERE " + appointmentIDCol + "= "  + appointment.getId();

//        System.out.println(sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * deletes an appointment object from the database
     *
     * @param appointment the appointment being deleted
     * @return >0 means successful, else failure
     */
    public static int deleteAppointment(Appointment appointment) {

        sqlString = "DELETE FROM " + databaseName + "." + appointmentsTable +
					" WHERE " + appointmentIDCol + "='" + appointment.getId() + "'";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return result;
            } else {
                return -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * gets appointments within 15 minutes from the server
     *
     * @return a list of appointments within 15 minutes
     * @throws SQLException   if there is a problem with the sql or server
     * @throws ParseException if there is a problem parsing the data
     */
    public static ObservableList<Appointment> getAppointmentsIn15Minutes() throws SQLException, ParseException {

        ObservableList<Appointment> appointments = FXCollections.observableArrayList();

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        java.util.Date currentDate = getDateFromServer();

        long timeInSec = currentDate.getTime();
        int minutesToAdd = 15;
        int milliSecondsPerMinute = 60000;
        long timeToAdd = (minutesToAdd * milliSecondsPerMinute) + timeInSec;
        java.util.Date dateIn15Minutes = new Date(timeToAdd);

        String minDate = df.format(currentDate);
        String maxDate = df.format(dateIn15Minutes.getTime());

        sqlString = "SELECT * FROM " + databaseName + "." + appointmentsTable +
					" WHERE " + userIDCol 			+ "=" + userID +
					" and "   + appointmentStartCol + " BETWEEN '" + minDate + "' and '" + maxDate + "';";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while (result.next()) {
                Integer id              = result.getInt(appointmentIDCol);
                Integer custId          = result.getInt(appointmentCustomerIDCol);
                Integer userId          = result.getInt(userID);
                Integer contactId       = result.getInt(appointmentContactIDCol);

                String title            = result.getString(appointmentTitleCol);
                String desc             = result.getString(appointmentDescriptionCol);
                String location         = result.getString(appointmentLocationCol);
                String type             = result.getString(appointmentTypeCol);
                String createdBy        = result.getString(appointmentCreatedByCol);
                String updatedBy        = result.getString(appointmentLastUpdateByCol);

                java.util.Date start    = result.getTimestamp(appointmentStartCol);
                java.util.Date end      = result.getTimestamp(appointmentEndCol);
                java.util.Date created  = result.getTimestamp(appointmentCreateDateCol);
                java.util.Date updated  = result.getTimestamp(appointmentLastUpdateCol);

                String startString      = DateHelper.convertServerToUser(start);
                String endString        = DateHelper.convertServerToUser(end);
                start                   = DateHelper.stringToDate(startString);
                end                     = DateHelper.stringToDate(endString);

                Appointment appt = new Appointment(id, title, desc, location, type, start, end, created, createdBy, updated, updatedBy, custId, userId, contactId);
                appt.printAppointmentInformation();
                appointments.add(appt);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointments;
    }

    /**
     * gets appointments for customer by customer id
     *
     * @param id customer id
     * @return appointments for customer
     * @throws SQLException if there is a problem with the sql or server.
     */
    public static ObservableList<Appointment> getAppointmentsForCustomerByCustomerID(Integer id) throws SQLException {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();

        String sqlString = "Select * from " + appointmentsTable +
						   " WHERE " + customerIDCol + "=" + id;

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Appointment appointment;

        while (result.next()) {
            Integer appointmentID   = result.getInt(appointmentIDCol);
            String title            = result.getString(appointmentTitleCol);
            String description      = result.getString(appointmentDescriptionCol);
            String location         = result.getString(appointmentLocationCol);
            String type             = result.getString(appointmentTypeCol);
            Timestamp start         = result.getTimestamp(appointmentStartCol);
            Timestamp end           = result.getTimestamp(appointmentEndCol);
            Timestamp createdDate   = result.getTimestamp(appointmentCreateDateCol);
            String createdBy        = result.getString(appointmentCreatedByCol);
            Timestamp lastUpdate    = result.getTimestamp(appointmentLastUpdateCol);
            String lastUpdatedBy    = result.getString(appointmentLastUpdateByCol);
            Integer customerID      = result.getInt(appointmentCustomerIDCol);
            Integer userID          = result.getInt(appointmentUserIDCol);
            Integer contactID       = result.getInt(appointmentContactIDCol);

            appointment = new Appointment(appointmentID, title, description, location, type, start, end, createdDate, createdBy, lastUpdate, lastUpdatedBy, customerID, userID, contactID);
            appointments.add(appointment);
        }

        return appointments;
    }

    /**
     * gets the appointments for the active user ordered by the start ascending
     *
     * @return the appointments list sorted by start
     * @throws SQLException if there is a problem with the sql or server
     */
    public static ObservableList<Appointment> getAppointmentsForActiveUser_OrderedByStartASC() throws SQLException {
        ObservableList<Appointment> appointmentsList = FXCollections.observableArrayList();

        sqlString = "Select * from " + appointmentsTable +
					" WHERE User_id=" + ConnectDB.userID + " ORDER BY Start ASC";

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Appointment appointment;

        while (result.next()) {
            Integer appointmentID   = result.getInt(appointmentIDCol);
            String title            = result.getString(appointmentTitleCol);
            String description      = result.getString(appointmentDescriptionCol);
            String location         = result.getString(appointmentLocationCol);
            String type             = result.getString(appointmentTypeCol);
            Timestamp start         = result.getTimestamp(appointmentStartCol);
            Timestamp end           = result.getTimestamp(appointmentEndCol);
            Timestamp createdDate   = result.getTimestamp(appointmentCreateDateCol);
            String createdBy        = result.getString(appointmentCreatedByCol);
            Timestamp lastUpdate    = result.getTimestamp(appointmentLastUpdateCol);
            String lastUpdatedBy    = result.getString(appointmentLastUpdateByCol);
            Integer customerID      = result.getInt(appointmentCustomerIDCol);
            Integer userID          = result.getInt(appointmentUserIDCol);
            Integer contactID       = result.getInt(appointmentContactIDCol);

            appointment = new Appointment(appointmentID, title, description, location, type, start, end, createdDate, createdBy, lastUpdate, lastUpdatedBy, customerID, userID, contactID);
            appointmentsList.add(appointment);
        }

        return appointmentsList;
    }

    /**
     * gets customer appointment reports
     *
     * @return a list of customer appointment reports
     */
    public static ObservableList<CustomerReport> getCustomerAppointmentsReport() {
        ObservableList<CustomerReport> CustomerReports = FXCollections.observableArrayList();

        sqlString = "Select monthname(" + appointmentStartCol + ") as Month, year(" + appointmentStartCol + ") as Year, " +
                    appointmentTypeCol + ", COUNT(" + appointmentTypeCol + ") as Total\n" +
                    "FROM " + databaseName + "." + appointmentsTable + "\n" +
                    "GROUP BY monthname(" + appointmentStartCol + "), year(" + appointmentStartCol + "), " + appointmentTypeCol + ";";

        Statement statement;
        ResultSet result;

        System.out.println(sqlString);

        try {
            statement = ConnectDB.conn.createStatement();
            result = statement.executeQuery(sqlString);

            while (result.next()) {
                String year     = result.getString("Year");
                String month    = result.getString("Month");
                String type     = result.getString(appointmentTypeCol);
                Integer total   = result.getInt("Total");

                CustomerReport report = new CustomerReport(month, year, type, total);
                CustomerReports.add(report);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return CustomerReports;
    }

    /**
     * gets contact appointment reports for a contact
     *
     * @param currentContact the contact to get the reports for
     * @return the appointments for the selected contact
     */
    public static ObservableList<Appointment> getContactAppointmentReportForContact(Contact currentContact) {
        ObservableList<Appointment> contactAppointmentReport = FXCollections.observableArrayList();
        Appointment appointment;

        sqlString = "Select *\n" +
                    "FROM " + appointmentsTable + "\n" +
                    "WHERE " + contactIDCol + "=" + currentContact.getId() + "\n" +
                    "ORDER BY " + contactIDCol + " ASC, " + appointmentStartCol + " ASC";

        System.out.println(sqlString);

        Statement statement;
        ResultSet result;

        try {
            statement = ConnectDB.conn.createStatement();
            result = statement.executeQuery(sqlString);

            while (result.next()) {
                Integer appointmentID   = result.getInt(appointmentIDCol);
                String title            = result.getString(appointmentTitleCol);
                String description      = result.getString(appointmentDescriptionCol);
                String location         = result.getString(appointmentLocationCol);
                String type             = result.getString(appointmentTypeCol);
                Timestamp start         = result.getTimestamp(appointmentStartCol);
                Timestamp end           = result.getTimestamp(appointmentEndCol);
                Timestamp createdDate   = result.getTimestamp(appointmentCreateDateCol);
                String createdBy        = result.getString(appointmentCreatedByCol);
                Timestamp lastUpdate    = result.getTimestamp(appointmentLastUpdateCol);
                String lastUpdatedBy    = result.getString(appointmentLastUpdateByCol);
                Integer customerID      = result.getInt(appointmentCustomerIDCol);
                Integer userID          = result.getInt(appointmentUserIDCol);
                Integer contactID       = result.getInt(appointmentContactIDCol);

                appointment = new Appointment(appointmentID, title, description, location, type, start, end, createdDate, createdBy, lastUpdate, lastUpdatedBy, customerID, userID, contactID);
                contactAppointmentReport.add(appointment);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return contactAppointmentReport;
    }

    /**
     * gets the divisions reports
     *
     * @return the list of division reports
     */
    public static ObservableList<main.stitesc195.Model.DivisionReport> getDivisionReports() {
        ObservableList<DivisionReport> divisionReports = FXCollections.observableArrayList();
        DivisionReport divisionReport;

        sqlString = "SELECT c.Division_ID, d.Division, COUNT(*) AS \'Customers\'" +
                    "FROM customers as c\n" +
                    "JOIN first_level_divisions as d on c.Division_ID = d.Division_ID\n" +
                    "GROUP BY c.Division_ID;";

        Statement statement;
        ResultSet result;

        System.out.println(sqlString);

        try {
            statement   = ConnectDB.conn.createStatement();
            result      = statement.executeQuery(sqlString);

            while (result.next()) {
                Integer divisionId  = result.getInt(divisionIDCol);
                String title        = result.getString(divisionCol);
                Integer total       = result.getInt("Customers");
                divisionReport      = new DivisionReport(divisionId, title, total);
                divisionReports.add(divisionReport);

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return divisionReports;
    }

    /**
     * Retrieves the current version of the database.
     *
     * @return a string representing the current database version
     */
    public static String getCurrentDatabaseVersion() {
        String databaseVersion = "1.0.0";
        Statement statement = null;

        try {
            // Check if the table exists
            if (!doesTableExist(conn, "software_version")) {

                // perform update database for the initial update to add the software version table and others
                System.out.println("Updating database to version: 1.0.1");
                updateDatabase("1-0-1");
				databaseVersion = "1.0.1";
                return databaseVersion;
            }else{
                /*not initial update

                // some sample code that may be run to perform updates in the future - likely will need updated to
                // accommodate any changes

//                statement       = conn.createStatement();
//                String query    = getLatestUpdate();
//
//                if(!query.equals(null) || !query.equals("") || query!=""){
//                    result = statement.executeQuery(query);
//
//                    if (result.next()) {
//                        return result.getString("version_number");
//                    } else {
//                        return databaseVersion;
//                    }
//                }*/
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception appropriately
            return databaseVersion;
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace(); // Handle or log the exception appropriately
                }
            }
        }

        return databaseVersion;
    }

    /**
     * Retrieves the latest update for the database.
     *
     * @return  a string representing the latest update; currently returns an empty string as there is only one update
     *          for the database and the update are currently taken care of via other methods.
     */
    private static String getLatestUpdate() {
        //currently there is only one update for the database. this can be filled with logic when other updates come up

        //String[] updatesList;

        //get updates from software version table
        //updatesList = getAllUpdates();

        return "";
    }

    /**
     * Updates the database with SQL statements from a file.
     *
     * @param s     the name of the file containing SQL update statements
     * @return      true if the database was successfully updated, false otherwise
     */
    private static boolean updateDatabase(String s) {
        //get text from updates folder
        String updateData = readUpdatesSQLFile(s);
        String[] statements = updateData.split(";");

        //process update
        try {

            try (Statement statement = ConnectDB.conn.createStatement()) {
                // Execute each statement separately
                for (String statementText : statements) {
                    statement.execute(statementText.trim()); // trim() removes leading and trailing whitespaces
                }

                System.out.println("Database Updated");
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Reads the content of an SQL file and returns it as a String.
     *
     * @param s the path to the SQL file to be read
     * @return the content of the SQL file as a String
     * @throws RuntimeException if the specified file is not found
     */
    public static String readUpdatesSQLFile(String s) {
        String output = "";
        Scanner myReader;
        InputStream inputStream = ConnectDB.class.getResourceAsStream("/updates/databaseUpdate_"+s+".sql");
        myReader = new Scanner(inputStream);
        try {
            while (myReader.hasNextLine()) {
                output += myReader.nextLine();
            }

            return output;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (myReader != null) {
                myReader.close();
            }
        }
    }

    /**
     * gets all roles from the database
     *
     * @return list of roles
     */
    public static ObservableList<UserRole> getAllRoles() {
        ObservableList<UserRole> roles = FXCollections.observableArrayList();

        sqlString = "select * from "+databaseName+"."+rolesTable;

        try{
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while(result.next()){
                Integer id   		= result.getInt(roleIDCol);
                String 	desc  		= result.getString(roleDescCol);
                Boolean admin 	    = result.getBoolean(roleAdminCol);

                UserRole newRole = new UserRole(id, desc, admin);

                roles.add(newRole);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }

        return roles;
    }

    /**
     * Checks if a table exists in the database.
     *
     * @param connection the database connection
     * @param tableName  the name of the table to check for existence
     * @return true if the table exists, false otherwise
     * @throws SQLException if a database access error occurs
     */
    public static boolean doesTableExist(Connection connection, String tableName) throws SQLException {
        ResultSet resultSet = null;
        try {
            DatabaseMetaData metaData = connection.getMetaData();
            resultSet = metaData.getTables(null, null, tableName, null);
            return resultSet.next(); // If next() returns true, the table exists
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
        }
    }

    /**
     * Checks the database to see if any users are assigned to a particular userRole - determined by the roleID variable
     * @param roleID    the id of the role being checked
     * @return          true if a user is assigned, false otherwise
     */
    public static Boolean checkForUsersAssignedToRole(int roleID) {
        Boolean userAssigned = false;

        ResultSet result;
        String sqlString = 	"Select count(*) from " + administratorsTable +
							" WHERE " + roleIDCol + "=" + roleID;

        Statement statement;
        try {
            statement   = ConnectDB.conn.createStatement();
            result      = statement.executeQuery(sqlString);

            while(result.next()) {
                Integer rowCount   = result.getInt(rowCountCol);

                if(rowCount>1){
                    // user assigned
                    return true;
                }else{
                    return false;
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return userAssigned;
    }

    /**
     * Deletes a UserRole from the database based on the userRole Object
     * @param selectedRole  the selected role to be deleted
     * @return              returns >0 if successful, otherwise returns a -1
     */
    public static int deleteRole(UserRole selectedRole) {

        sqlString = "DELETE FROM " + databaseName + "." + rolesTable +
					" WHERE " + roleIDCol + "='" + selectedRole.getId() + "'";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return result;
            } else {
                return -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Deletes a search from the database
     * @param selectedSearch    the search to be deleted
     * @return                  returns >0 if successful, otherwise returns a -1
     */
    public static int deleteSearch(Search selectedSearch) {

        sqlString = "DELETE FROM " + databaseName + "." + searchesTable +
					" WHERE " + searchIDCol + "='" + selectedSearch.getId() + "'";

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return result;
            } else {
                return -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Retrieves the searches for the currently active user from the database
     * @return  the list of searches for the active user from the database
     */
    public static ObservableList<Search> getSearchesForActiveUser() {
        ObservableList<Search> searchesForActiveUser = FXCollections.observableArrayList();

        sqlString = "select * from "+databaseName     +"."+searchesTable+
					" WHERE "		+searchOwnerIdCol +" = "+userID+";";

        System.out.println(sqlString);

        try{
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while(result.next()){
                Integer     searchId    = result.getInt(searchIDCol);
                Timestamp   start       = result.getTimestamp(searchStartCol);
                Timestamp   end         = result.getTimestamp(searchEndCol);
                String      type        = result.getString(searchTypeCol);
                String      title       = result.getString(searchTitleCol);
                Integer     userId      = result.getInt(searchUserIdCol);
                String      description = result.getString(searchDescriptionCol);
                Boolean     favorite    = result.getBoolean(searchFavoriteCol);
                Integer     customerId  = result.getInt(searchCustomerIdCol);
                Integer     contactId   = result.getInt(searchContactIdCol);
                String      location    = result.getString(searchLocationCol);
                Integer     ownerId     = result.getInt(searchOwnerIdCol);

                Search search = new Search(searchId, description, title, location, type, start, end, customerId, userId, contactId, favorite, ownerId);

                System.out.println(search.printSearchInformation());

                searchesForActiveUser.add(search);
            }
        } catch (SQLException e){
            e.printStackTrace();
        }

        return searchesForActiveUser;
    }

    /**
     * Retrieves the list of favorite searches for an active user from the database.
     * @return list of searches that are favorite for the active user
     */
    public static ObservableList<Search> getAllFavoriteSearches() {
        ObservableList<Search> searches = FXCollections.observableArrayList();

        sqlString = "select * from "+databaseName	  +"."  +searchesTable +
					" WHERE "		+searchUserIdCol  +" = "+activeUserId  +
					" AND "			+searchFavoriteCol+"=true;";

        try{
            Statement statement = ConnectDB.conn.createStatement();
            ResultSet result = statement.executeQuery(sqlString);

            while(result.next()){
                Integer     searchId    = result.getInt(searchIDCol);
                Date        start       = result.getDate(searchStartCol);
                Date        end         = result.getDate(searchEndCol);
                String      type        = result.getString(searchTypeCol);
                Integer     userId      = result.getInt(searchUserIdCol);
                String      title       = result.getString(searchTitleCol);
                String      description = result.getString(searchDescriptionCol);
                Integer     customerId  = result.getInt(searchCustomerIdCol);
                Integer     contactId   = result.getInt(searchContactIdCol);
                String      location    = result.getString(searchLocationCol);
                Integer     ownerId     = result.getInt(searchOwnerIdCol);
                Boolean     favorite    = result.getBoolean(searchFavoriteCol);

                searches.add(new Search(searchId, title, description, location, type, start, end, customerId, userId, contactId, favorite, ownerId));
            }
        } catch (SQLException e){
            e.printStackTrace();
        }

        return searches;
    }

    /**
     * Adds a search to the database
     * @param search    the search object to be added to the database
     * @return          returns >0 if successful, otherwise returns a -1
     */
    public static Boolean addSearch(Search search) {

        String start="", end="";

        if(search.getStart()!=null){
            start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(search.getStart());
        }

        if(search.getEnd()!=null) {
            end = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(search.getEnd());
        }

        sqlString = "INSERT INTO " + databaseName + "." + searchesTable + "(" +
				searchStartCol			+ ", "  	+
				searchEndCol			+ ", "  	+
				searchTypeCol			+ ", "  	+
				searchTitleCol			+ ", "  	+
				searchUserIdCol 		+ ", "  	+
				searchDescriptionCol 	+ ", "  	+
				searchFavoriteCol 		+ ", "  	+
				searchCustomerIdCol 	+ ", "  	+
				searchContactIdCol 		+ ", "  	+
				searchLocationCol 		+ ", "		+
				searchOwnerIdCol 		+ ")\n"		+

                "VALUES(" 				;

                if(search.getStart()==null){
        sqlString += "null, ";
                }else {
        sqlString += "'" + start            + "', ";
                }

                if(search.getEnd()==null){
        sqlString += "null, ";
                }else{
        sqlString += "'" + end 				+ "', ";
                }

                if(search.getType()==null){
        sqlString += "null, ";
                }else{
        sqlString+= "'" + search.getType()  + "', ";
                }

                if(search.getTitle()==null){
        sqlString += "null, ";
                }else{
        sqlString += "'" + search.getTitle() +"', ";
                }

                if(search.getUserId() <=0) {
        sqlString+= "null, ";
                }else{
        sqlString+= search.getUserId() 		+ ", ";
                }

                if(search.getDescription()==null){
        sqlString += "null, ";
                }else{
        sqlString += "'" + search.getDescription() +"', ";
                }

        sqlString+=
				search.getFavorite() 	+ ", " 		;

                if(search.getCustomerId()<=0){
        sqlString+= "null, ";
                }else{
        sqlString+= search.getCustomerId() 	+ ", " 		;
                }

				if(search.getContactId()<=0){
        sqlString+="null, ";
                }else{
        sqlString+= search.getContactId() 	+ ", " 	;
                }

                if(search.getLocation()==null){
        sqlString+= "null, ";
                }else{
        sqlString+= "'" + search.getLocation() 	+ "', " 	;
                }

                if(search.getOwnerId()<=0){
        sqlString+="null);";
                }else{
        sqlString+= search.getOwnerId() 	+");";
                }

        System.out.println(sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }

    /**
     * Update a search in the database
     * @param search    the search object to be updated
     * @return          returns >0 if successful, otherwise returns a -1
     */
    public static Boolean updateSearch(Search search) {

        String startString="", endString="";

        if(search.getStart()!=null)
            startString      = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(search.getStart());
        if(search.getEnd()!=null)
            endString        = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(search.getEnd());

        sqlString = "UPDATE " + databaseName + "." + searchesTable + "\n" +
                    "SET " ;

        if(search.getStart()!=null){
            sqlString +=
                    searchStartCol              + "= '" + startString                           + "', " ;
        }else{
            sqlString +=
                    searchStartCol              + "=null, ";
        }

        if (search.getEnd() != null) {
            sqlString +=
                    searchEndCol                + "= '" + endString                             + "', " ;
        }else{
            sqlString +=
                    searchEndCol                + "=null, ";
        }

        if (search.getType() != null) {
            sqlString +=
                    searchTypeCol                + "= '" + search.getType()                     + "', " ;
        }else{
            sqlString +=
                    searchTypeCol                + "=null, ";
        }

        if (search.getTitle() != null) {
            sqlString +=
                    searchTitleCol                + "= '" + search.getTitle()                     + "', " ;
        }else{
            sqlString +=
                    searchTitleCol                + "=null, ";
        }

        if (search.getUserId()>0) {
            sqlString +=
                    searchUserIdCol               + "= '" + search.getUserId()                     + "', " ;
        }else{
            sqlString +=
                    searchUserIdCol                + "=null, ";
        }

        if (search.getDescription() != null) {
            sqlString +=
                    searchDescriptionCol                + "= '" + search.getDescription()                     + "', " ;
        }else{
            sqlString +=
                    searchDescriptionCol                + "=null, ";
        }

        sqlString +=
                searchFavoriteCol           + "= " + search.getFavorite()                  + ", ";


        if (search.getCustomerId()>0) {
            sqlString +=
                    searchCustomerIdCol     + "= '" + search.getCustomerId()                     + "', " ;
        }else{
            sqlString +=
                    searchCustomerIdCol     + "=null, ";
        }

        if (search.getContactId()>0) {
            sqlString +=
                    searchContactIdCol      + "= '" + search.getContactId()                     + "', " ;
        }else{
            sqlString +=
                    searchContactIdCol      + "=null, ";
        }

        if (search.getLocation() != null) {
            sqlString +=
                    searchLocationCol                + "= '" + search.getLocation()                     + "', " ;
        }else{
            sqlString +=
                    searchLocationCol                + "=null, ";
        }

        if (search.getOwnerId()>0) {
            sqlString +=
                    searchOwnerIdCol                + "= " + search.getOwnerId()                     + "\n" ;
        }else{
            sqlString +=
                    searchOwnerIdCol                + "=null\n ";
        }

        sqlString +=
                "WHERE " + searchIDCol + "= " + search.getId();

        System.out.println(sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

	/**
	 * Retrieves the active user role ID from the administrators table in the database.
	 *
	 * @param id The ID of the user for whom the active role ID is to be retrieved.
	 * @return The active user role ID, or -1 if no active role is found.
	 * @throws RuntimeException If a SQL error occurs during the execution of the query.
	 */
    public static int getActiveUserRoleId(int id) {
		// Initialize the role ID to -1 (indicating no active role found).
        int roleId=-1;

		// Construct the SQL query to select the role ID from the administrators table for the specified user ID.
        sqlString = "SELECT "+adminRoleIdCol + " FROM " + databaseName +"." + administratorsTable +"\n"+
                    "WHERE " + adminUserIdCol +" = " +id +";";


        try{
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result set.
            ResultSet resultSet = statement.executeQuery(sqlString);

			// If there are rows in the result set, retrieve the role ID.
            while(resultSet.next()){
                roleId = resultSet.getInt(adminRoleIdCol);
            }

        } catch (SQLException e) {
			// If an SQL error occurs, throw a runtime exception with the details.
            throw new RuntimeException(e);
        }

		// Return the retrieved role ID.
        return roleId;
    }

	/**
	 * Retrieves a user role from the database based on the provided role ID.
	 *
	 * @param roleId The ID of the role to retrieve.
	 * @return The UserRole object corresponding to the provided role ID, or null if no such role exists.
	 */
    public static UserRole getUserRoleByRoleID(int roleId){
		UserRole userRole = null;

		// Construct SQL query to select role information from the database.
        sqlString = "SELECT * FROM "+databaseName +"." +rolesTable +"\n"+
                    "WHERE " + roleIDCol +"= " +roleId +";";

        try{
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the query and retrieve the result set.
            ResultSet resultSet = statement.executeQuery(sqlString);

			// Iterate through the result set to retrieve role information.
            while(resultSet.next()){
                int     roleIdFromDB    = resultSet.getInt(roleIDCol);
                String  roleDesc        = resultSet.getString(roleDescCol);
                Boolean admin           = resultSet.getBoolean(roleAdminCol);

				// Create a new UserRole object based on the retrieved information.
                userRole = new UserRole(roleIdFromDB, roleDesc, admin);
            }
        } catch (SQLException e){
			// Handle any SQL exceptions by throwing a runtime exception.
            throw new RuntimeException(e);
        }
			// Return the retrieved UserRole object.
            return userRole;
    }

    /**
	 * Retrieves the availabilities for a user based on the provided user ID.
	 *
	 * @param userId the ID of the user to retrieve availabilities for.
	 * @return a list of availabilities for the specified user, or null if none are found.
	 */
	public static ObservableList<Availability> getAvailabilitiesForUser(int userId){
        ObservableList<Availability> availabilities = FXCollections.observableArrayList();

		// Construct SQL query to select availabilities for the specified user ordered by the start column.
        sqlString = "select *" 											+"\n"+
                    "from "+databaseName+"."+userAvailabilityTable		+"\n"+
                    "where "+userIDCol +"="+userId 						+"\n"+
					"ORDER BY "+availabilitiesStartCol;

        System.out.println(sqlString);

        try{
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the query and retrieve the result set.
            ResultSet result    = statement.executeQuery(sqlString);

			// Iterate through the result set to retrieve availability information.
            while(result.next()){
                int         availabilityId  = result.getInt(availabilitiesIdCol);
                int         userIdVar       = result.getInt(availabilitiesUserIdCol);
                Timestamp   start           = result.getTimestamp(availabilitiesStartCol);
                Timestamp   end             = result.getTimestamp(availabilitiesEndCol);
                String      status          = result.getString(availabilitiesStatusCol);
                String      repeatFreq      = result.getString(availabilitiesRepeatFreqCol);
                Timestamp   repeatEnd       = result.getTimestamp(availabilitiesRepeatEndCol);
                String      details         = result.getString(availabilitiesDetailsCol);

				// Create a new Availability object based on the retrieved information and add it to the list.
                availabilities.add(new Availability(availabilityId,userIdVar, status, details, start, end, repeatFreq, repeatEnd));
            }
        } catch (SQLException e){
			// Print the SQL exception stack trace.
            e.printStackTrace();
        }

		// Return the list of availabilities for the specified user.
        return availabilities;
    }

    /**
	 * Retrieves the availabilities for a user based on the provided user ID and availability status.
	 *
	 * @param userId the ID of the user to retrieve availabilities for.
	 * @param available a boolean variable representing the availability status:
	 *                  - true : retrieves available availabilities.
	 *                  - false: retrieves unavailable availabilities.
	 * @return a list of availabilities for the specified user and availability status, or null if none are found.
	 */
    public static ObservableList<Availability> getAvailableListForUser(int userId, Boolean available){
        ObservableList<Availability> availabilities = FXCollections.observableArrayList();

		// Initialize SQL string addendum based on the availability status.
        String sqlStringAddendum = "AND " +availabilitiesStatusCol+"= ";

        if(available){
            sqlStringAddendum += "\"Available\"";
        }else{
            sqlStringAddendum += "\"Not Available\"";
        }

		// Construct SQL query to select availabilities for the specified user and availability status.
        sqlString = "select *" 										+"\n"+
                "from "+databaseName+"."+userAvailabilityTable		+"\n"+
                "where "+userIDCol +"="+userId 						+"\n"+
                sqlStringAddendum                                   +"\n"+
                "ORDER BY "+availabilitiesStartCol;

        try{
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the query and retrieve the result set.
            ResultSet result    = statement.executeQuery(sqlString);

			// Iterate through the result set to retrieve availability information.
            while(result.next()){
                int         availabilityId  = result.getInt(availabilitiesIdCol);
                int         userIdVar       = result.getInt(availabilitiesUserIdCol);
                Timestamp   start           = result.getTimestamp(availabilitiesStartCol);
                Timestamp   end             = result.getTimestamp(availabilitiesEndCol);
                String      status          = result.getString(availabilitiesStatusCol);
                String      repeatFreq      = result.getString(availabilitiesRepeatFreqCol);
                Timestamp   repeatEnd       = result.getTimestamp(availabilitiesRepeatEndCol);
                String      details         = result.getString(availabilitiesDetailsCol);

				// Create a new Availability object based on the retrieved information and add it to the list.
                availabilities.add(new Availability(availabilityId,userIdVar, status, details, start, end, repeatFreq, repeatEnd));
            }
        } catch (SQLException e){
			// Print the SQL exception stack trace.
            e.printStackTrace();
        }

		// Return the list of availabilities for the specified user and availability status.
        return availabilities;
    }

    /**
	 * Inserts an availability into the database.
	 *
	 * @param avail the Availability object to be added to the database.
	 * @return  - true : if the insertion is successful,
	 *          - false: otherwise.
	 */
    public static Boolean addAvailability(Availability avail){

		// Construct SQL string for inserting availability information into the database.
        sqlString = "INSERT INTO " + databaseName	+"."+	userAvailabilityTable			+ "("  +
                availabilitiesUserIdCol             +","+   availabilitiesStartCol		    +","   +
                availabilitiesEndCol			    +","+   availabilitiesStatusCol		    +","   +
                availabilitiesRepeatFreqCol		    +","+   availabilitiesRepeatEndCol		+","   +
                availabilitiesDetailsCol		    + ")\n"+
                "VALUES ("+avail.printAvailabilityInformation()+");";

        System.out.println(sqlString);

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

			// Return true if the insertion was successful, false otherwise.
            return result > 0;

        }catch(SQLException e){
			// Print the SQL exception stack trace and return false.
            e.printStackTrace();
            return false;
        }
    }

	/**
	 * Updates an existing availability in the database.
	 *
	 * @param avail the Availability object representing the availability being updated.
	 * @return  - True : if the update is successful,
	 *          - False: otherwise.
	 */
    public static Boolean updateAvailability(Availability avail){
		// Convert date objects to strings in the required format for SQL queries.
        String startString      = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(avail.getStart());
        String endString        = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(avail.getEnd());
        String repeatEndString  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(avail.getRepeatEnd());

		// Construct SQL string for updating availability information in the database.
        sqlString = "UPDATE "   +databaseName				    + "." +userAvailabilityTable		+ "\n"+
                    "SET "		+availabilitiesStartCol		    +"= '"+startString				    + "', "
                                +availabilitiesEndCol			+"= '"+endString	 			    + "', "
                                +availabilitiesStatusCol		+"= '"+avail.getStatus()			+ "', "
                                +availabilitiesRepeatFreqCol    +"= '"+avail.getFrequency()	+ "', "
                                +availabilitiesRepeatEndCol  	+"= '"+repeatEndString		        + "', "
                                +availabilitiesDetailsCol  	    +"= '"+avail.getDetails()			+ "'\n" +
                    "WHERE "	+availabilitiesIdCol 			+"= " +avail.getId();

        System.out.println(sqlString);

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

            // Return true if the update was successful, false otherwise.
			return result > 0;

        }catch(SQLException e){
			// Print the SQL exception stack trace and return false.
            e.printStackTrace();
            return false;
        }
    }

	/**
	 * Deletes an availability from the database.
	 *
	 * @param avail the Availability object representing the availability being deleted.
	 * @return >0: if the deletion is successful,
	 *         -1: if the deletion fails.
	 */
    public static int deleteAvailability(Availability avail){

		// Construct SQL string for deleting the availability from the database.
        sqlString = "DELETE FROM " + databaseName+"."+userAvailabilityTable+
                    " WHERE " +availabilitiesIdCol+"='"+avail.getId()+"'";

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

			// Return the result of the deletion operation.
            if(result>0){
				// Deletion successful.
				return result;
			}
            else{
				// Deletion failed.
				return -1;
			}

        }catch(SQLException e){
			// Print the SQL exception stack trace and return -1 to indicate deletion failure.
            e.printStackTrace();
            return -1;
        }
    }

	/**
	 * Retrieves a list of all users with their IDs and names from the database.
	 * This method executes a SQL query to fetch user IDs and names from a specified
	 * table and organizes them in ascending order by user ID. It encapsulates each
	 * retrieved record into a user object and collects them into an observable list.
	 *
	 * @return An observable list containing User objects with ID and name properties.
	 * @throws SQLException If a database access error occurs or this method is called on a closed connection.
	 */
    public static ObservableList<User> getAllUserIdsAndNames() throws SQLException {
		// Initialize an observable list to store the retrieved users.
        ObservableList<User> users = FXCollections.observableArrayList();

		// Construct the SQL query to select user IDs and names from the specified table, ordered by user ID.
        sqlString = "select " +userIDCol   +", "+userNameCol +"\n"+
                    "from "   +databaseName+"."+usersTable   +"\n"+
                    "order by "+userIDCol;

		// Create a statement to execute the SQL query.
        Statement statement = ConnectDB.conn.createStatement();

		// Execute the SQL query and retrieve the result set.
        ResultSet result = statement.executeQuery(sqlString);

		// Initialize user object.
        User user;

		// Iterate through the result set to retrieve user IDs and names.
        while(result.next()) {

			// Extract user ID and name from the result set.
            int userId = result.getInt(userIDCol);
            String userName = result.getString(userNameCol);

			// Create a new User object with the retrieved ID and name.
            user = new User(userId, userName);

			// Add the user object to the observable list.
            users.add(user);
        }

		// Return the observable list containing the retrieved User objects.
        return users;
    }

	/**
	 * Attempts to delete a user from the database by their user ID. The method constructs and executes
	 * a DELETE SQL statement. If the deletion is successful, it returns the number of rows affected.
	 * If no rows are affected, or if an error occurs during the execution of the SQL statement,
	 * the method returns -1.
	 *
	 * @param userID The ID of the user to be deleted from the database.
	 * @return The number of rows affected by the delete operation if successful;
				-1 if unsuccessful or if an error occurs.
	 */
    public static int deleteUserById(int userID) {

        // Construct the DELETE SQL statement to delete the user by their ID.
        sqlString = "DELETE FROM " + databaseName + "." + usersTable +
                    " WHERE " + userIDCol + "='" + userID + "'";

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the number of rows affected.
            int result = statement.executeUpdate(sqlString);

			// Check if any rows are affected by the deletion.
            if (result > 0) {
				// Return the number of rows affected if the deletion is successful.
                return result;
            } else {
				// Return -1 if no rows are affected.
                return -1;
            }

        } catch (SQLException e) {

			// Print the stack trace if an SQL exception occurs.
            e.printStackTrace();

			// Return -1 if an error occurs during the execution of the SQL statement.
            return -1;
        }
    }

    /**
	 * Retrieves the role ID associated with a given user ID from the administrators table in the database.
	 * This method executes a SELECT SQL query to find the role ID for the specified user ID.
	 * If the user ID is found, it returns the corresponding role ID. If no matching user ID is found or
	 * an error occurs during database access, the method throws a RuntimeException.
	 *
	 * @param userID The ID of the user whose role ID is to be retrieved.
	 * @return The role ID of the user if found; otherwise, returns -1.
	 * @throws RuntimeException If a SQL error occurs during the execution of the query.
	 */
    public static int getUserRoleIDByUserID(int userID) {
		// Initialize the role ID variable.
        int roleId=-1;

		// Construct the SQL query to retrieve the role ID for the specified user ID.
        sqlString = "SELECT " + adminRoleIdCol      +"\n"+
                    "FROM "   + administratorsTable +"\n"+
                    "WHERE "  + adminUserIdCol      +"="+userID+";";

        try{
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result set.
            ResultSet resultSet = statement.executeQuery(sqlString);

			// Iterate over the result set to retrieve the role ID.
            while(resultSet.next()){

				// Retrieve the role id from the admin role id column.
                roleId  = resultSet.getInt(adminRoleIdCol);
            }
        } catch (SQLException e){
			// Throw a RuntimeException if a SQL error occurs during database access.
            throw new RuntimeException(e);
        }

		// Return the role ID of the user.
        return roleId;
    }

	/**
	 * Inserts a new user into the database.
	 * If the insertion is successful, it returns true.
	 * If the insertion fails due to a database error or other issues, it returns false.
	 *
	 * @param selectedUser The User object containing all necessary data for the new user record.
	 * @return True if the user was successfully added to the database, false otherwise.
     */
    public static Boolean addUser(User selectedUser) {
		// Convert the created and updated timestamps to formatted strings for SQL insertion.
        String createdString = DateHelper.stringDateToFormatForSQL(selectedUser.getCreated());
        String updatedString = DateHelper.stringDateToFormatForSQL(selectedUser.getUpdated());

		// Construct the SQL insertion query.
        sqlString = "INSERT INTO " + databaseName + "." + usersTable + "(" +
					userNameCol 			+ "," 	+
					userPassCol 			+ "," 	+
					userCreateDateCol 		+ "," 	+
					userCreatedByCol 		+ "," 	+
					userLastUpdateCol 		+ "," 	+
					userLastUpdatedByCol 	+ ")\n" +

					"VALUES(" 					+ "\"" 		+
					selectedUser.getUserName() 	+ "\",\"" 	+
					selectedUser.getPassword() 	+ "\",\"" 	+
					createdString 				+ "\",\"" 	+
					selectedUser.getCreatedBy() + "\",\"" 	+
					updatedString 				+ "\",\"" 	+
					selectedUser.getUpdatedBy() + "\")";

        try {
			// Create a statement to execute the SQL insertion query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL insertion query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

            // Return TRUE if the insertion operation is successful; otherwise, return FALSE.
			return result > 0;

        } catch (SQLException e) {
			// Print the SQL exception stack trace and throw the exception.
            e.printStackTrace();
            return false;
        }
    }

	/**
	 * Adds a user to a role or updates their current role in the database.
	 * This method first checks if the user is already assigned a role by retrieving the current role ID.
	 * If a role exists, it updates the role with the new role ID; otherwise, it inserts a new row into
	 * the administrators table with the user and role IDs.
	 *
	 * @param 	userId The ID of the user to be added or updated in the role.
	 * @param 	roleId The ID of the role to be assigned to the user.
	 * @return 	TRUE if the operation is successful (either insertion or update),
				FALSE otherwise.
     */
    public static Boolean addUserToRole(int userId, int roleId) {

		// Initial check if the user is already assigned a role.
        int currentUserRoleId = getUserRoleIDByUserID(userId);

	    // Initialize SQL string for execution.
        String sqlString;

		// Update the existing role if the user is already assigned one.
        if (currentUserRoleId!=-1) {
            sqlString = "UPDATE " + databaseName   + "." 	+ administratorsTable + "\n" +
                        "SET "    + adminRoleIdCol + "= " 	+ roleId 			  + "\n" +
                        "WHERE "  + adminUserIdCol + "= " 	+ userId;

            System.out.println(sqlString);

            try {
				// Create a statement to execute the SQL update query.
                Statement statement = ConnectDB.conn.createStatement();

				// Execute the SQL update query and retrieve the result.
                int result = statement.executeUpdate(sqlString);

                // Return TRUE if the update operation is successful; otherwise, return FALSE.
				return result > 0;

            }catch(SQLException e){
                e.printStackTrace();
                return false;
            }
        }

		// Insert a new row into the administrators table if the user is not assigned any role.
        else{
			// Construct SQL string for inserting a new row into the administrators table.
            sqlString = "INSERT INTO " + databaseName   + "." + administratorsTable + "("+adminUserIdCol
                        +", " +adminRoleIdCol+")"       +"\n" +
                        "VALUES(" +userId+", " +roleId +");";

            System.out.println(sqlString);

            try {
				// Create a statement to execute the SQL insert query.
                Statement statement = ConnectDB.conn.createStatement();

				// Execute the SQL insert query and retrieve the result.
                int result = statement.executeUpdate(sqlString);

                // Return TRUE if the insertion operation is successful; otherwise, return FALSE.
				return result > 0;

            }catch(SQLException e) {
				// Print the SQL exception stack trace and throw the exception.
                e.printStackTrace();
                return false;
            }
        }
    }

	/**
	 * Updates an existing user's details in the database.
	 * If the update is successful, it returns true. If no rows are affected or an error occurs during the execution
	 * of the SQL statement, the method returns false.
	 *
	 * @param selectedUser The user object containing all updated data for the existing user record.
	 * @return TRUE:  if the user was successfully updated in the database;
			   FALSE: otherwise.
     */
    public static Boolean editUser(User selectedUser) {
		// Format the timestamps to string representation compatible with SQL format.
        String updatedString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(selectedUser.getUpdated());
        String createdString = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(selectedUser.getCreated());

		// Construct SQL string for updating the user details in the database.
        sqlString = "UPDATE "   +databaseName			+ "." +usersTable			        + "\n"    +
                    "SET "		+userNameCol		    +"= '"+selectedUser.getUserName()   + "', "   +
                                 userPassCol            +"= '"+selectedUser.getPassword()	+ "', "   +
                                 userCreateDateCol	    +"= '"+createdString	            + "', "   +
                                 userCreatedByCol       +"= '"+selectedUser.getCreatedBy()	+ "', "   +
                                 userLastUpdateCol 	    +"= '"+updatedString	            + "', "   +
                                 userLastUpdatedByCol  	+"= '"+selectedUser.getUpdatedBy()	+ "'\n " +
                    "WHERE "	+userIDCol 			    +"= " +selectedUser.getUserID();

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

            // Return TRUE if the user was successfully updated in the database, otherwise return FALSE.
			return result > 0;

        }catch(SQLException e){
			// Print the SQL exception stack trace and rethrow the exception.
            e.printStackTrace();
            return false;
        }
    }

	/**
	 * Retrieves a user from the database by their user ID.
	 *
	 * @param userID The ID of the user to retrieve.
	 * @return A User object containing the user's details if found; otherwise, returns null.
	 * @throws RuntimeException If a SQL error occurs or the database connection is interrupted.
	 */
    public static User getUserByID(int userID) {

		// Initialize user object
        User user = null;

		// Construct SQL string to select user details based on the provided user ID.
        sqlString = "Select * FROM " + databaseName +"." +usersTable + " WHERE "+userIDCol+" = " +userID;

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result set.
            ResultSet result = statement.executeQuery(sqlString);

			// Iterate through the result set to retrieve user details.
            while (result.next()) {
                String userName = result.getString(userNameCol);
                String password = result.getString(userPassCol);
                Timestamp created = result.getTimestamp(userCreateDateCol);
                String createdBy = result.getString(userCreatedByCol);
                Timestamp updated = result.getTimestamp(userCreateDateCol);
                String updatedBy = result.getString(userCreatedByCol);

				// Create a new User object with the retrieved user details.
                user = new User(userID, userName, password, created, createdBy, updated, updatedBy);
            }
        } catch (SQLException e) {
			// Throw a RuntimeException if a SQL error occurs or the database connection is interrupted.
            throw new RuntimeException(e);
        }

		// Return user object
        return user;
    }

    /**
	 * Deletes an administrator record from the database based on the user ID.
	 * If the deletion is successful (one or more rows are affected), it returns the number of rows deleted.
	 * If no rows are affected or an error occurs, the method returns -1.
	 *
	 * @param userID The ID of the user whose administrator record is to be deleted.
	 * @return The number of rows affected by the delete operation, or
			   -1 if the deletion failed or an error occurred.
     */
    public static int deleteUserFromAdmin(int userID) {
		// Construct SQL string for deleting the administrator record from the database.
        sqlString = "DELETE FROM "+databaseName +"."+administratorsTable + "\nWHERE "+adminUserIdCol+" = " +userID;

        try {
			// Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

			// Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

			// Return the number of rows affected by the delete operation.
            if (result > 0) {
				// Deletion successful.
                return result;
            } else {
				// Deletion failed.
                return -1;
            }

        } catch (SQLException e) {
			// Print the SQL exception stack trace and rethrow the exception.
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * Deletes all appointments from the database.
     *
     * @return the number of appointments deleted, or -1 if an error occurs
     */
    public static int deleteAllAppointments(){
        sqlString = "DELETE FROM "+databaseName+"."+appointmentsTable;

        try{
            // Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

            // Execute the SQL query and retrieve the number of rows affected.
            int result = statement.executeUpdate(sqlString);

            // Check if any rows are affected by the deletion.
            if (result > 0) {
                // Return the number of rows affected if the deletion is successful.
                return result;
            } else {
                // Return -1 if no rows are affected.
                return -1;
            }

        } catch (SQLException e) {
            // Print the stack trace if an SQL exception occurs.
            e.printStackTrace();
            // Return -1 if an error occurs during the execution of the SQL statement.
            return -1;
        }
    }

    /**
     * Deletes all availabilities from the database.
     *
     * @return the number of availabilities deleted, or -1 if an error occurs
     */
    public static int deleteAllAvailabilities(){
        sqlString = "DELETE FROM "+databaseName+"."+userAvailabilityTable;

        try{
            Statement statement = ConnectDB.conn.createStatement();
            // Execute the SQL query and retrieve the number of rows affected.
            int result = statement.executeUpdate(sqlString);

            // Check if any rows are affected by the deletion.
            if (result > 0) {
                // Return the number of rows affected if the deletion is successful.
                return result;
            } else {
                // Return -1 if no rows are affected.
                return -1;
            }

        } catch (SQLException e) {
            // Print the stack trace if an SQL exception occurs.
            e.printStackTrace();
            // Return -1 if an error occurs during the execution of the SQL statement.
            return -1;
        }
    }

    /**
     * Checks if the active user is an administrator.
     *
     * @return true if the active user is an administrator, false otherwise
     */
    public static Boolean isUserAdmin(){
        //first get the active user role id

        // Initialize the role ID variable.
        int roleId=-1;

        if(activeUserRole==null)
            return false;

        int activeUserRoleId = activeUserRole.getId();

        System.out.println("Active User Role: " +activeUserRoleId);

        Boolean isAdmin = false;

        // Construct the SQL query to retrieve the role ID for the specified user ID.
        sqlString = "SELECT " + adminRoleIdCol      +"\n"+
                    "FROM "   + administratorsTable +"\n"+
                    "WHERE "  + adminUserIdCol      +"="+activeUserRoleId+";";

        try{
            // Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

            // Execute the SQL query and retrieve the result set.
            ResultSet resultSet = statement.executeQuery(sqlString);

            // Iterate over the result set to retrieve the role ID.
            while(resultSet.next()){

                // Retrieve the role id from the admin role id column.
                roleId  = resultSet.getInt(adminRoleIdCol);
            }
        } catch (SQLException e){
            // Throw a RuntimeException if a SQL error occurs during database access.
            throw new RuntimeException(e);
        }

        System.out.println("Role Id from query: " + roleId);

        // check if the role id is set as an administrator

        sqlString = "SELECT "   +roleAdminCol   +"\n"+
                    "FROM "     +rolesTable     +"\n"+
                    "WHERE "    +roleIDCol      +"=" + roleId;

        try{
            // Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

            // Execute the SQL query and retrieve the result set.
            ResultSet resultSet = statement.executeQuery(sqlString);

            // Iterate over the result set to retrieve the role ID.
            while(resultSet.next()){
                // Retrieve the role id from the admin role id column.
                isAdmin  = resultSet.getBoolean(roleAdminCol);
            }
        } catch (SQLException e){
            // Throw a RuntimeException if a SQL error occurs during database access.
            throw new RuntimeException(e);
        }

        // Return the role ID of the user.
        return isAdmin;
    }

    public static ObservableList<Appointment> searchAppointments(Search search) throws SQLException {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();


        //sql string for parsing to DB for appointment results
        String sqlString    =   "SELECT * \n" +
                                "FROM " + appointmentsTable +"\n";

        String          searchTitle     = search.getTitle();
        String          searchType      = search.getType();
        String          searchDesc      = search.getDescription();
        int             customerId      = search.getCustomerId();
        int             userId          = search.getUserId();
        int             contactId       = search.getContactId();
        java.util.Date  searchStart     = search.getStart();
        java.util.Date  searchEnd       = search.getEnd();
        String          searchLoc       = search.getLocation();
        Boolean         addedCondition  = false;

        //check for search criteria and build sql string
        if(search.hasCriteria()){
            sqlString += "WHERE ";

            if(search.getTitle()!=null){
                sqlString += appointmentTitleCol + "='" + searchTitle +"'\n";
                addedCondition = true;
            }

            if(search.getType()!=null){
                if(search.getType().trim()!="''"){
                    sqlString += (addedCondition ? " AND " : "") + appointmentTypeCol + "='" + searchType + "'\n";
                    addedCondition = true;
                }
            }

            if(search.getDescription()!=null){
                sqlString += (addedCondition ? " AND " : "") + appointmentDescriptionCol + "='" + searchDesc + "'\n";
                addedCondition = true;
            }

            if(customerId>0){
                sqlString += (addedCondition ? " AND " : "") + appointmentCustomerIDCol + "=" + customerId + "\n";
                addedCondition = true;
            }

            if(userId>0){
                sqlString += (addedCondition ? " AND " : "") + appointmentUserIDCol + "=" + userId + "\n";
                addedCondition = true;
            }

            if(contactId>0){
                sqlString += (addedCondition ? " AND " : "") + appointmentContactIDCol + "=" + contactId + "\n";
                addedCondition = true;
            }

            if (searchStart != null && searchEnd != null) {
                String startDateString = DateHelper.dateToString(searchStart);
                String endDateString = DateHelper.dateToString(searchEnd);

                // Check if the date is after or equal to searchStart
                String startCondition = "(" + appointmentStartCol + " >= '" + startDateString + "')";

                // Check if the date is before or equal to searchEnd
                String endCondition = "(" + appointmentEndCol + " <= '" + endDateString + "')";

                // Combine both conditions with OR
                String combinedCondition = "(" + startCondition + " AND " + endCondition + ")";

                // Add the combined condition to the SQL string
                sqlString += (addedCondition ? " AND " : "") + combinedCondition;
                addedCondition = true;
            } else if (searchStart != null) {
                // Handle case where searchEnd is null
                String startDateString = DateHelper.dateToString(searchStart);
                sqlString += (addedCondition ? " AND " : "") + "(" + appointmentStartCol + " >= '" + startDateString + "'\n)";
                addedCondition = true;
            } else if (searchEnd != null) {
                // Handle case where searchStart is null
                String endDateString = DateHelper.dateToString(searchEnd);
                sqlString += (addedCondition ? " AND " : "") + "(" + appointmentEndCol + " <= '" + endDateString + "'\n)";
                addedCondition = true;
            }

            if(search.getLocation()!=null && !search.getLocation().trim().isEmpty()){
                sqlString += (addedCondition ? " AND " : "") + appointmentLocationCol + "='" + searchLoc +"'\n";
                addedCondition = true;
            }
        }

        System.out.println("Searching: \n"+sqlString);

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        Appointment appointment;

        while (result.next()) {
            Integer appointmentID   = result.getInt(appointmentIDCol);
            String title            = result.getString(appointmentTitleCol);
            String description      = result.getString(appointmentDescriptionCol);
            String location         = result.getString(appointmentLocationCol);
            String type             = result.getString(appointmentTypeCol);
            Timestamp start         = result.getTimestamp(appointmentStartCol);
            Timestamp end           = result.getTimestamp(appointmentEndCol);
            Timestamp createdDate   = result.getTimestamp(appointmentCreateDateCol);
            String createdBy        = result.getString(appointmentCreatedByCol);
            Timestamp lastUpdate    = result.getTimestamp(appointmentLastUpdateCol);
            String lastUpdatedBy    = result.getString(appointmentLastUpdateByCol);
            Integer customerID      = result.getInt(appointmentCustomerIDCol);
            Integer userID          = result.getInt(appointmentUserIDCol);
            Integer contactID       = result.getInt(appointmentContactIDCol);

            appointment = new Appointment(appointmentID, title, description, location, type, start, end, createdDate, createdBy, lastUpdate, lastUpdatedBy, customerID, userID, contactID);
            appointments.add(appointment);
        }

        return appointments;
    }

    public static int getUserIdByName(String name) throws SQLException {

        int userId = 0;

        sqlString = "SELECT "   + userIDCol     + "\n"      +
                    "FROM "     + usersTable    + "\n"      +
                    "WHERE "    + userNameCol   + " LIKE '" +   name    +   "'";

        System.out.println(sqlString);

        Statement statement = ConnectDB.conn.createStatement();
        ResultSet result = statement.executeQuery(sqlString);

        while (result.next()) {
            userId = result.getInt(userIDCol);
        }

        return userId;
    }

    public static Boolean addRole(UserRole role) {
        sqlString = "INSERT INTO "  + rolesTable    +"("+roleDescCol+","+roleAdminCol+")\n"+
                    "VALUES ("+role.printInformation()+");";

        System.out.println(sqlString);

        try {
            // Create a statement to execute the SQL query.
            Statement statement = ConnectDB.conn.createStatement();

            // Execute the SQL query and retrieve the result.
            int result = statement.executeUpdate(sqlString);

            // Return true if the insertion was successful, false otherwise.
            return result > 0;

        }catch(SQLException e){
            // Print the SQL exception stack trace and return false.
            e.printStackTrace();
            return false;
        }
    }

    public static Boolean updateRole(UserRole role) {
        sqlString = "UPDATE "   +rolesTable     +"\n"   +
                    "SET "      +roleDescCol    +"='"   +role.getDescription()      +"',\n"  +
                                 roleAdminCol   +"="    +role.getAdministrator()    +"\n"    +
                    "WHERE "    +roleIDCol      +"="    +role.getId();

        System.out.println(sqlString);

        try {
            Statement statement = ConnectDB.conn.createStatement();
            int result = statement.executeUpdate(sqlString);

            if (result > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}