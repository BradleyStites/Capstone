package main.stitesc195.Controller;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.time.ZoneId;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeSet;

public class TimeZone implements Initializable {

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * The time zone combo box for the login screen.
     * This combo box allows the user to choose from a list of time zones to adjust the current time zone of the
     * application. The selected time zone determines how all dates and times in the application are displayed.
     */
    @FXML
    private ComboBox timeZoneComboBox;

    @FXML
    private Label timeZoneLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    /**
     * The view loader for the application
     * used to change views/stages or display alerts
     */
    ViewLoader viewLoader;

    /**
     * The current stage of the application
     * used to denote the current stage to be hidden by the ViewLoader
     */
    Stage currentStage;

    /**
     * this function takes the information from the form and saves it to the various classes parameters
     */
    @FXML
    private void save() {
        //get the time zone from the combo box
        int index = timeZoneComboBox.getSelectionModel().getSelectedIndex();

        //set time zone in the DateHelper
        DateHelper.userTimeZoneId = ZoneId.of((String) timeZoneComboBox.getItems().get(index));

        System.out.println("Changing time zone to: " + DateHelper.userTimeZoneId);

        //set time zone in connect db
        ConnectDB.userTimeZoneId = DateHelper.userTimeZoneId;

        returnToDashboard();
    }

    /**
     * this function returns the user to the dashboard when called
     */
    private void returnToDashboard() {
        currentStage = (Stage) cancelButton.getScene().getWindow();
        //Load the MainScreen after a successful login
        viewLoader.loadFXML("Dashboard", currentStage);
    }

    /**
     * this function simply calls the return to dashboard function if the cancel button is hit
     */
    @FXML
    private void cancel() {
        returnToDashboard();
    }

    /**
     * this function initializes all the gui elements and sets the language based on user selection
     */
    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        timeZoneLabel = new Label();
        saveButton = new Button();
        viewLoader = new ViewLoader();

        Set<String> zoneIds = ZoneId.getAvailableZoneIds();
        Set<String> sortedZoneIds = new TreeSet<>(zoneIds);

        //get zone id
        ZoneId zone = DateHelper.userTimeZoneId;
        String zoneID = zone.getId();

        setFieldsToLanguage();

        //add zone options to combo box
        timeZoneComboBox.getItems().addAll(sortedZoneIds);

        //set zone to current user's value
        timeZoneComboBox.setValue(zoneID);

    }

    /**
     * Sets the text of various GUI elements to the match the language selected by the user in the combo box.
     */
    private void setFieldsToLanguage(){

        //get languages resource bundle and set labels
        languages = ResourceBundle.getBundle("language");

        String timeZoneLabelString, saveButtonString, cancelButtonString;

        timeZoneLabelString          = languages.getString("TimeZone");
        saveButtonString        = languages.getString("save");
        cancelButtonString      = languages.getString("cancel");

        timeZoneLabel.setText(timeZoneLabelString);
        saveButton.setText(saveButtonString);
        cancelButton.setText(cancelButtonString);
    }
}