package main.stitesc195.Controller;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import main.stitesc195.Model.User;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Users implements Initializable {

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * DateHelper used to convert dates to and from various time zones
     */
    DateHelper dateHelper;

    /**
     * Search object to hold the values for the selected search used to filter the results of the appointments screen.
     */
    User selectedUser;

    /**
     * ObservableList to store all users.
     */
    ObservableList<User> users = FXCollections.observableArrayList();

    /**
     * Represents the "User ID" Column on the Users Table.
     */
    @FXML
    TableColumn<User, Integer> userIDColumn;

    /**
     * Represents the "Username" Column on the Users Table.
     */
    @FXML
    TableColumn<User, String> userNameColumn;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * Represents the Users TableView on the Users screen.
     */
    @FXML
    private TableView usersTable;

    /**
     * Represents the "Add" button on the Appointments screen.
     * When clicked, this button navigates the user to the CustomerDetails.fxml screen, which allows a user to
     * add a new customer.
     */
    @FXML
    private Button addButton;

    /**
     * Represents the "View/Modify" button on the Appointments screen.
     * When clicked, this button navigates the user to the CustomerDetails.fxml screen, which allows a user to
     * modify an existing customer.
     */
    @FXML
    private Button modifyButton;

    /**
     * Represents the "Delete" button on the Appointments screen.
     * When clicked, various checks are performed to ensure deletion is possible, then deletes any selected
     * appointment upon confirmation.
     */
    @FXML
    private Button deleteButton;

    /**
     * Represents the "Back" button on the Appointments screen.
     * When clicked, this button navigates the user back to the Appointments.fxml screen, displaying all appointments
     */
    @FXML
    private Button backButton;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * Initializes the controller.
     *
     * @param url the location
     * @param resourceBundle the resources bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //initialize ViewLoader and DateHelper
        viewLoader = new ViewLoader();
        dateHelper = new DateHelper();

        //get all appointments and contacts
        try {
            users = ConnectDB.getAllUserIdsAndNames();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //populate the users table - only names and ids
        updateUsersTable(users);

        //set the language
        setLanguage();
    }

    /**
     * Updates the users table with new user data.
     *
     * @param users the list of users to display in the table
     */
    public void updateUsersTable(ObservableList<User> users) {
        userIDColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getUserID()).asObject());
        userNameColumn.setCellValueFactory(cellData ->  Bindings.createStringBinding(() -> cellData.getValue().getUserName()));

        //clear the table and set the table to the incoming appointments object
        usersTable.getItems().clear();
        usersTable.getItems().setAll(users);
        usersTable.refresh();
    }

    /**
     * Sets the language for the user interface elements.
     * Retrieves values from a properties file and sets them to corresponding UI components.
     */
    private void setLanguage() {
        String userId, userName, add,viewModify, delete, back;

        // Get values from properties file
        userName = languages.getString("name");
        userId = languages.getString("userId");
        add = languages.getString("add");
        viewModify = languages.getString("view");
        delete = languages.getString("delete");
        back = languages.getString("back");

        userIDColumn.setText(userId);
        userNameColumn.setText(userName);
        addButton.setText(add);
        modifyButton.setText(viewModify);
        deleteButton.setText(delete);
        backButton.setText(back);
    }

    /**
     * Adds a new user.
     * Sets the selected user to null and loads the "UserDetails" FXML file.
     */
    public void addUser() {
        ConnectDB.selectedUser = null;
        currentStage = (Stage) addButton.getScene().getWindow();
        viewLoader.loadFXML("UserDetails", currentStage);
    }

    /**
     * Edits the selected user.
     * Retrieves the selected user from the table, loads the user details into the form, and loads the "UserDetails" FXML file.
     * Displays an alert if no user is selected.
     */
    public void editUser() {
        String noSelectedUser  = languages.getString("noSelectedUser");

        //get user selection from table
        selectedUser = (User) usersTable.getSelectionModel().getSelectedItem();
        selectedUser = ConnectDB.getUserByID(selectedUser.getUserID());

        ConnectDB.selectedUser = selectedUser;


        //ensure not null
        if (selectedUser == null) {
            viewLoader.showAlert(noSelectedUser);
            return;
        }
        else{
            //load selected user into form
            UserDetails userDetails = new UserDetails();
            userDetails.setUser(selectedUser);
            userDetails.initialize();

            currentStage = (Stage) modifyButton.getScene().getWindow();
            viewLoader.loadFXML("UserDetails", currentStage);
        }
    }

    /**
     * Deletes the selected user from the database.
     * Displays alerts for confirming deletion and success/failure messages.
     */
    public void deleteUser() {
        //get appointment selection from table
        selectedUser = (User) usersTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedUser = selectedUser;

        String noSelectedUser  = languages.getString("noSelectedUser");

        //ensure not null
        if (selectedUser == null) {
            viewLoader.showAlert(noSelectedUser);
            return;
        }

        // Confirm Deletion
        String confirmDeletion = languages.getString("confirmDeleteUser");
        boolean confirmed      = viewLoader.confirmPrompt(confirmDeletion);

        if(confirmed){
            //delete user from administrators table first
            int adminDeleteSuccess = ConnectDB.deleteUserFromAdmin(selectedUser.getUserID());
            System.out.println("adminDeleteSuccess: "+adminDeleteSuccess);

            //proceed with deletion
            int success = ConnectDB.deleteUserById(selectedUser.getUserID());

            if(success>0){
                String userDeleted          = languages.getString("userDeleted");
                String userId               = languages.getString("userId");
                String name                 = languages.getString("name");
                String userDetails   = userId+": "+selectedUser.getUserID()+"\n"+
                                        name +": "+selectedUser.getUserName();
                viewLoader.showAlert(userDeleted+"\n\n"+userDetails);
                users.remove(selectedUser);

                //refresh appointments
                updateUsersTable(users);

            }else{
                String userNotDeleted = languages.getString("userNotDeleted");
                viewLoader.showAlert(userNotDeleted);
            }
        }
    }

    /**
     * Handles the action when the back button is clicked.
     * This method retrieves the current stage from the back button's scene and loads the "Dashboard" FXML file.
     */
    public void BackButton() {
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("Dashboard", currentStage);
    }
}
