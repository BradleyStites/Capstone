package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Contact;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "ContactReports" screen.
 * Launches different screens, sets texts on GUI elements based on user selection, and displays report in TableView.
 *
 * @author Bradley Stites
 */
public class ContactReports implements Initializable {

    /**
     * ObservableList used to store the ContactReports.
     */
    ObservableList<Appointment> contactReports  = FXCollections.observableArrayList();

    /**
     * ObservableList used to contain a filteredList of the contactReports.
     */
    ObservableList<Appointment> filteredList    = FXCollections.observableArrayList();

    /**
     * ObservableList used to contain all contacts.
     */
    ObservableList<Contact>     contacts        = FXCollections.observableArrayList();

    /**
     * A label used to store "Contact".
     */
    @FXML
    private Label contactLabel;

    /**
     * A TableView used to store the contact report.
     */
    @FXML
    private TableView contactReportTableView;

    /**
     * A ComboBox used to store all contacts for filtering through the reports.
     */
    @FXML
    private ComboBox contactComboBox;

    /**
     * A TableColumn used to store Appointment Ids.
     */
    @FXML
    private TableColumn<Appointment, Integer> appointmentIDColumn;

    /**
     * A TableColumn used to store appointment titles.
     */
    @FXML
    private TableColumn<Appointment, String> titleColumn;

    /**
     * A TableColumn used to store appointment types.
     */
    @FXML
    private TableColumn<Appointment, String> typeColumn;

    /**
     * A TableColumn used to store appointment descriptions.
     */
    @FXML
    private TableColumn<Appointment, String> descriptionColumn;

    /**
     * A TableColumn used to store appointment start
     */
    @FXML
    private TableColumn<Appointment, String> startColumn;

    /**
     * A TableColumn used to store appointment end
     */
    @FXML
    private TableColumn<Appointment, String> endColumn;

    /**
     * A TableColumn used to store customer ids
     */
    @FXML
    private TableColumn<Appointment, String> customerIdColumn;

    /**
     * Button used to return to previous screen, ReportSelection.
     */
    @FXML
    private Button backButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Contact for storing the current selected contact, used to filter between reports.
     */
    Contact currentContact;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * Initializes the ContactReports class.
     *
     *  Sets the cell value factories for the columns, gets all contacts from db and stores in combo box, sets the default
     *  selected contact to the first contact in the contacts list, and sets the text on the GUI elements to match language
     *  selection.
     *
     * @param url               The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle    The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewLoader = new ViewLoader();

        appointmentIDColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        startColumn.setCellValueFactory(new PropertyValueFactory<>("start"));
        endColumn.setCellValueFactory(new PropertyValueFactory<>("end"));
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerID"));

        // Get contacts
        contacts  = ConnectDB.getAllContacts();

        // Get Appointment Report
        contactReports = ConnectDB.getContactAppointmentReportForContact(contacts.get(0));

        // Ensure Contact Reports is not empty
        if(contactReports.isEmpty()){
            // No Appointments - Notify User
            String noAppointments = languages.getString("noAppointmentsForContact");
            viewLoader.showAlert(noAppointments);
        }

        //set contacts list as combo box options
        contactComboBox.setItems(contacts);

        //set value to first object
        contactComboBox.setValue(contacts.get(0));

        /**
         * Lambda Expression Explanation: The expression allowed me to get the contact name from the contact combo box
         * in a concise way while leaving the objects in the combo box. This could be beneficial in case any other data
         * was needed in a later update.
         */

        //convert contacts objects to/from strings for display
        contactComboBox.setConverter(new StringConverter<Contact>() {
            //return null if empty, otherwise return contact name
            @Override
            public String toString(Contact contact) {
                return contact == null ? null : contact.getContactName();
            }

            //return the object from the name
            @Override
            public Contact fromString(String string) {
                return contacts.stream()
                        .filter(contact -> contact.getContactName().equals(string))
                        .findFirst()
                        .orElse(null);
            }
        });

        //add each instance of first contact to a filtered list to display on table view
        for(Appointment a : contactReports){
            if(a.getContactID() == contacts.get(0).getContactID()){
                filteredList.add(a);
            }
        }

        //potential lambda code for the above
//        ContactReports.stream()
//                .filter(a -> a.getContactID() == contacts.get(0).getContactID())
//                .forEach(filteredList::add);

        //display on table
        contactReportTableView.setItems(filteredList);
        contactReportTableView.refresh();

        setLanguage();
    }

    /**
     * Sets the language of the various GUI elements
     */
    private void setLanguage() {
        String appointmentId, title, type, description, start, end, customerId, back, contact;

        appointmentId = languages.getString("appointmentId");
        title = languages.getString("title");
        type = languages.getString("type");
        description = languages.getString("description");
        start = languages.getString("start");
        end = languages.getString("end");
        customerId = languages.getString("customerId");
        back = languages.getString("back");
        contact = languages.getString("contact");

        appointmentIDColumn.setText(appointmentId);
        titleColumn.setText(title);
        typeColumn.setText(type);
        descriptionColumn.setText(description);
        startColumn.setText(start);
        endColumn.setText(end);
        customerIdColumn.setText(customerId);
        backButton.setText(back);
        contactLabel.setText(contact);
    }

    /**
     * Gets the selected contact and pulls the report from the db based on the selection.
     */
    public void getReport(){
        // Set current Contact to the selected contact
        int selectedIndex = contactComboBox.getSelectionModel().getSelectedIndex();

        currentContact = contacts.get(selectedIndex);

        filteredList = ConnectDB.getContactAppointmentReportForContact(currentContact);

        contactReportTableView.getItems().clear();
        contactReportTableView.getItems().setAll(filteredList);
        contactReportTableView.refresh();
    }

    /**
     * Button for returing to previous screen, ReportSelection.
     */
    public void backButton() {
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("ReportSelection", currentStage);
    }
}
