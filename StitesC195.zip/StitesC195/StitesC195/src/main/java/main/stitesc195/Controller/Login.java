package main.stitesc195.Controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.io.PrintWriter;
import java.net.URL;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.time.ZoneId;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeSet;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import javafx.stage.Stage;
import main.stitesc195.Model.User;

/**
 * Contains the logic and variables for the login screen, handles errors and prompts for various conditions,
 * launches different screens, and sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class Login implements Initializable {

    /**
     * Used to store the input value for the username.
     */
    @FXML
    private TextField userNameTextField;

    /**
     * Used to store the input value for the password.
     */
    @FXML
    private TextField passwordTextField;

    /**
     * The login button for the login screen.
     */
    @FXML
    private Button loginButton;

    /**
     * The exit button for the login screen.
     */
    @FXML
    private Button exitButton;

    /**
     * The language combo box for the login screen, used to store the selectable languages.
     * Current version only allows for options: English & French.
     */
    @FXML
    private ComboBox languageComboBox;

    /**
     * The time zone combo box for the login screen.
     * This combo box allows the user to choose from a list of time zones to adjust the current time zone of the
     * application. The selected time zone determines how all dates and times in the application are displayed.
     */
    @FXML
    private ComboBox zoneComboBox;

    /**
     * The label for language selection
     */
    @FXML
    private Label languageLabel;

    /**
     * The label for Zone ID selection
     */
    @FXML
    private Label zoneIdLabel;

    /**
     * The current stage of the application
     * used to denote the current stage to be hidden by the ViewLoader
     */
    Stage currentStage;

    /**
     * The view loader for the application
     * used to change views/stages or display alerts
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * Initializes the login screen with default values for language and time zone.
     * -----------------------------------------------------------------------------------------------------------------
     * The language combo box displays options for English and French, and the default is determined
     * based on the user's system language setting. If the system language is French, then the language combo box and
     * all UI labels are set to French. If the system language is not French, then the language combo box and all UI
     * labels are set to English.
     * -----------------------------------------------------------------------------------------------------------------
     * The zone combo box displays all available time zones in alphabetical order and sets the default value to the
     * system default time zone.
     * -----------------------------------------------------------------------------------------------------------------
     * This method sets the initial values for both combo boxes and does an initial update on all relevant UI elements
     * accordingly.
     *
     * @param url the location used to resolve relative paths for the root object or null if the location is not known
     * @param resourceBundle the resources used to localize the root object or null if the root object was not localized
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        viewLoader = new ViewLoader();

        //set string arrays for combo box options
        ResourceBundle languages = ResourceBundle.getBundle("language");
        String englishOption = languages.getString("englishOption");
        String frenchOption  = languages.getString("frenchOption");

        String[] languageOptions = {englishOption, frenchOption};
        Set<String> zoneIds = ZoneId.getAvailableZoneIds();
        Set<String> sortedZoneIds = new TreeSet<>(zoneIds);

        //get zone id
        ZoneId zone = ZoneId.systemDefault();
        String zoneID = zone.getId();

        Locale currentLoc = Locale.getDefault();

        if (currentLoc.getLanguage().equals("fr")) {
            languageComboBox.setValue(frenchOption);

            //set Locale to french
            Locale.setDefault(new Locale("fr", "FR"));

            //set field values
            setFieldsToLanguage();

        } else{
            //default to english
            languageComboBox.setValue(englishOption);

            //set locale
            Locale.setDefault(new Locale("en", "US"));

            setFieldsToLanguage();
        }

        //add language options to language box
        languageComboBox.getItems().addAll(languageOptions);

        //add zone options to combo box
        zoneComboBox.getItems().addAll(sortedZoneIds);

        //set zone to current user's value
        zoneComboBox.setValue(zoneID);
    }

    /**
     * Exits the application and closes the database connection.
     */
    @FXML
    private void Exit(){
            try {
                ConnectDB.closeConnection();
            }catch(Exception e){
                System.out.println("Error Closing Connection: \n"+e.toString());
            }
             System.exit(0);
    }

    /**
     * Authenticates user login information and loads the main screen if successful.
     * Logs all attempts in log file. Sets the selected time zone id in the system.
     *
     * @throws SQLException if there is an error with the SQL query
     */
    @FXML
    private void Login() throws SQLException{

        String userName, password;

        //set current stage
        currentStage = (Stage) loginButton.getScene().getWindow();

        User user = new User();
        userName = userNameTextField.getText();
        password = passwordTextField.getText();

        int userID = getUserIDByUserName(userName);

        String loginAttempt = "User:\t\t"+userName +"\nPass:\t\t"+password;

        if(validPassword(userID, password)){
            logAttempt(loginAttempt, true);

            user.setUserID(userID);
            user.setUserName(userName);

            //set variables in ConnectDB
            ConnectDB.userID=userID;
//            System.out.println("login userID: "+ConnectDB.userID);

            ConnectDB.activeUserName = userName;

            //set the active user role
            int activeUserRoleId = ConnectDB.getActiveUserRoleId(ConnectDB.userID);
            ConnectDB.activeUserRole = ConnectDB.getUserRoleByRoleID(activeUserRoleId);

            // Alert user about dates and times displaying in current user's local time
            String dateAndTimesDisplayedInUserTimeZone = languages.getString("dateAndTimesDisplayedInUserTimeZone");
            viewLoader.showAlert(dateAndTimesDisplayedInUserTimeZone);

            // Set selected time zone
            int index = zoneComboBox.getSelectionModel().getSelectedIndex();
            DateHelper.userTimeZoneId = ZoneId.of((String) zoneComboBox.getItems().get(index));

            //Load the MainScreen after a successful login
            viewLoader.loadFXML("MainScreen", currentStage);

        }else{
            //log attempt in log file
            logAttempt(loginAttempt, false);

            displayLoginFailed();
        }
    }

    /**
     * Displays an alert to the user indicating that the login attempt has failed.
     * Retrieves the appropriate message and button text from the language resource bundle.
     */
    private void displayLoginFailed() {
        //get values for message
        ResourceBundle languages = ResourceBundle.getBundle("language");
        String loginErrorMessage = languages.getString("loginFailed");

        //display error message
        viewLoader.showAlert(loginErrorMessage);
        return;
    }

    /**
     * Logs a login attempt to the system log file.
     *
     * @param loginAttempt a string representing the login attempt to be logged
     * @param success a boolean indicating whether the login attempt was successful
     * @throws SQLException if there is an error accessing the database
     */
    private void logAttempt(String loginAttempt, Boolean success) throws SQLException {
        String failStatus = "Login:\t\tFail\n";
        String successStatus= "Login:\t\tSuccess\n";

        String dateTime = DateHelper.dateToString(ConnectDB.getDateFromServer());

        //add date and time
        loginAttempt = "Date/Time:\t"+dateTime +" UTC\n"+loginAttempt+"\n";

        //add success or fail markers
        if(success){
            loginAttempt = successStatus + loginAttempt;
        }else{
            loginAttempt = failStatus + loginAttempt;
        }

        try(FileWriter fw = new FileWriter(ConnectDB.logFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println(loginAttempt);
        } catch (IOException e) {
            System.out.println("error writing to file.");
        }
    }

    /**
     * Checks input values for user id and password and compares to values stored in database
     *
     * @param userID        an integer representing the user id attempting to be logged in
     * @param password      a string representing the password the user has input
     * @return              TRUE if values match, FALSE if the values do not match
     * @throws SQLException if there is an error accessing the database
     */
    private boolean validPassword(int userID, String password) throws SQLException{

        String query = "SELECT Password FROM users WHERE User_ID = '" +userID +"'";

        try (Statement stmt = ConnectDB.conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

                if (rs.next() && rs.getString("password").equals(password)) {
                    return true;
                }
        }
        return false;
    }

    /**
     * Takes the input username and compares against the database to get a user id
     *
     * @param userName       a string representing the users input
     * @return               an integer representing the user id for the input username
     * @throws SQLException  if there was an error accessing the database
     */
    private int getUserIDByUserName(String userName) throws SQLException{
        int userID = -1;

        Statement statement = ConnectDB.conn.createStatement();
        String sqlStatement = "SELECT User_ID FROM users WHERE User_Name ='" +userName +"'";
        ResultSet result = statement.executeQuery(sqlStatement);

        while(result.next()){
            userID = result.getInt("User_ID");
        }

        return userID;
    }

    /**
     * Sets the text of various GUI elements to the match the language selected by the user in the combo box.
     */
    private void setFieldsToLanguage(){

        //get languages resource bundle and set labels
        languages = ResourceBundle.getBundle("language");

        String englishOption = languages.getString("englishOption");
        String frenchOption  = languages.getString("frenchOption");

        String selection = languageComboBox.getValue().toString();

        if(selection.equals(englishOption)){
            Locale locale = new Locale("en", "US");
            Locale.setDefault(locale);
        }
        else if(selection.equals(frenchOption)){
            Locale locale = new Locale("fr", "FR");
            Locale.setDefault(locale);
        }

        languages = ResourceBundle.getBundle("language");

        String userNameField,passwordField,loginButtonStr,exitButtonStr,language,zoneId;

        userNameField  = languages.getString("userName");
        passwordField  = languages.getString("password");
        loginButtonStr = languages.getString("Login");
        exitButtonStr  = languages.getString("Exit");
        language       = languages.getString("language");
        zoneId         = languages.getString("zoneId");

        userNameTextField.setPromptText(userNameField);
        passwordTextField.setPromptText(passwordField);
        loginButton.setText(loginButtonStr);
        exitButton.setText(exitButtonStr);
        languageLabel.setText(language);
        zoneIdLabel.setText(zoneId);
    }

    /**
     * Triggered when user changes options in the language combo box
     */
    public void languageChanged() {
        setFieldsToLanguage();
    }
}