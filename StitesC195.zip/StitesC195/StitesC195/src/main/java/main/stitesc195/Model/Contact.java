package main.stitesc195.Model;

/**
 * The Contact class represents a contact object from the database.
 */
public class Contact {

    /**
     * an int to store the unique contact ids
     */
    private int contactID;

    /**
     * a string to store the name of the contact
     */
    private String contactName;

    /**
     * a string to store the email for the contact.
     */
    private String contactEmail;

    /**
     * Constructs an empty Contact object.
     */
    public Contact() {
    }

    /**
     * Constructs a Contact object with the following parameters:
     *
     * @param id        the unique id for the contact
     * @param name      the name of the contact
     * @param email     the email associated with the contact.
     */
    public Contact(int id, String name, String email){
        setContactID(id);
        setContactName(name);
        setContactEmail(email);
    }

    /**
     * returns the contact id.
     *
     * @return int of the contact id
     */
    public int getContactID(){
        return this.contactID;
    }

    /**
     * returns the value for the contact name
     * @return  the contact name
     */
    public String getContactName(){
        return this.contactName;
    }

    /**
     * returns the contact email address.
     * @return the contact's email.
     */
    public String getContactEmail(){
        return this.contactEmail;
    }

    /**
     * sets the value for contact id.
     * @param id    the contact id to be set.
     */
    public void setContactID(int id){
        this.contactID = id;
    }

    /**
     * sets the value for the contact name.
     * @param name the contact's name.
     */
    public void setContactName(String name){
        this.contactName = name;
    }

    /**
     * set the value for the contact's email address.
     * @param email the contact's email.
     */
    public void setContactEmail(String email){
        this.contactEmail = email;
    }

    /**
     * Stores contact details as a string and returns as output.
     * @return output for contact details as a string
     */
    public String outputContactDetails(){
        String output = "id: " + this.contactID +", name: "+this.contactName+", email: "+this.contactEmail;
        return output;
    }
}
