package main.stitesc195.Model;

/**
 * The Contact class represents a contact object from the database.
 */
public class Contact {

    /**
     * an int to store the unique contact ids
     */
    private int id;

    /**
     * a string to store the name of the contact
     */
    private String name;

    /**
     * a string to store the email for the contact.
     */
    private String email;

    /**
     * Constructs an empty Contact object.
     */
    public Contact() {
    }

    /**
     * Constructs a Contact object with the following parameters:
     *
     * @param id        the unique id for the contact
     * @param name      the name of the contact
     * @param email     the email associated with the contact.
     */
    public Contact(int id, String name, String email){
        setId(id);
        setName(name);
        setEmail(email);
    }

    /**
     * returns the contact id.
     *
     * @return int of the contact id
     */
    public int getId(){
        return this.id;
    }

    /**
     * returns the value for the contact name
     * @return  the contact name
     */
    public String getName(){
        return this.name;
    }

    /**
     * returns the contact email address.
     * @return the contact's email.
     */
    public String getEmail(){
        return this.email;
    }

    /**
     * sets the value for contact id.
     * @param id    the contact id to be set.
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the value for the contact name.
     * @param name the contact's name.
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * set the value for the contact's email address.
     * @param email the contact's email.
     */
    public void setEmail(String email){
        this.email = email;
    }

    /**
     * Stores contact details as a string and returns as output.
     * @return output for contact details as a string
     */
    public String outputContactDetails(){
        String output = ""+
						this.name +", "+
						this.email;
        return output;
    }
}
