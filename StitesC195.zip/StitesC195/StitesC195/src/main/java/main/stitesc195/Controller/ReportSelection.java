package main.stitesc195.Controller;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "ReportSelection" screen.
 * Launches different screens and sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class ReportSelection implements Initializable {

    /**
     * Button for loading CustomerReports screen.
     */
    @FXML
    private Button customerReportsButton;

    /**
     * Button for loading ContactReports screen.
     */
    @FXML
    private Button contactReportsButton;

    /**
     * Button for loading DivisionReports screen.
     */
    @FXML
    private Button divisionReportsButton;

    /**
     * Label for CustomerReports header/description.
     */
    @FXML
    private Label customerAppointmentsHeaderLabel;

    /**
     * Label for ContactReports header/description.
     */
    @FXML
    private Label contactAppointmentsHeaderLabel;

    /**
     * Label for DivisionReports header/description.
     */
    @FXML
    private Label divisionCustomersHeaderLabel;

    /**
     * Button for returning to previous screen, MainScreen.fxml.
     */
    @FXML
    private Button backButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * Initializes the ReportSelection class by setting the text/language of the various GUI elements.
     *
     *
      * @param url            The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle  The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewLoader = new ViewLoader();
        setLanguage();
    }

    /**
     * Loads the CustomerReports screen.
     */
    public void customerReportsButton(){
        currentStage = (Stage) customerReportsButton.getScene().getWindow();
        viewLoader.loadFXML("CustomerReports", currentStage);
    }

    /**
     * Loads the ContactReports screen.
     */
    public void contactReportsButton(){
        currentStage = (Stage) contactReportsButton.getScene().getWindow();
        viewLoader.loadFXML("ContactReports", currentStage);
    }

    /**
     * Loads the DivisionReports screen.
     */
    public void divisionReportsButton(){
        currentStage = (Stage) divisionReportsButton.getScene().getWindow();
        viewLoader.loadFXML("DivisionReports", currentStage);
    }

    /**
     * Returns the user to the previous screen, MainScreen.fxml
     */
    public void back(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("MainScreen", currentStage);
    }

    /**
     * Sets the text of the various gui elements to match selected language.
     */
    public void setLanguage(){
        String customerReportsHeader,
                contactReportsHeader,
                divisionReportsHeader,
                customerReports,
                contactReports,
                divisionReports;

        customerReportsHeader = languages.getString("CustomerReportsHeader");
        contactReportsHeader = languages.getString("ContactReportsHeader");
        divisionReportsHeader = languages.getString("DivisionReportsHeader");
        customerReports = languages.getString("CustomerReports");
        contactReports = languages.getString("ContactReports");
        divisionReports = languages.getString("DivisionReports");

        customerReportsButton.setText(customerReports);
        contactReportsButton.setText(contactReports);
        divisionReportsButton.setText(divisionReports);

        customerAppointmentsHeaderLabel.setText(customerReportsHeader);
        contactAppointmentsHeaderLabel.setText(contactReportsHeader);
        divisionCustomersHeaderLabel.setText(divisionReportsHeader);
    }
}
