package main.stitesc195.Model;

/**
 * The DivisionReport class represents a DivisionReport object.
 */
public class DivisionReport {

    /**
     * a unique division id
     */
    private int id;

    /**
     * a name for the division
     */
    private String name;

    /**
     * the total appointments
     */
    private int total;

    /**
     * Empty Constructor
     */
    public DivisionReport() {
    }

    /**
     * Constructor for Division Report with the following parameters:
     * @param id        the id for the division report
     * @param name      the name of the division
     * @param total     the total appointments
     */
    public DivisionReport(int id, String name, int total){
        setId(id);
        setName(name);
        setTotal(total);
    }

    /**
     * returns the unique division id
     * @return division id
     */
    public int getId() {
        return id;
    }

    /**
     * returns the name of the division
     * @return the division name
     */
    public String getName() {
        return name;
    }

    /**
     * returns the total number of appointments
     * @return total appointments
     */
    public int getTotal() {
        return total;
    }

    /**
     * sets the division id for the division report
     * @param id the division id
     */
    public void setId(int id){this.id =id;}

    /**
     * sets the division name for the division report
     * @param name the name of the division
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * sets the total appointments for the division report
     * @param total the total appointments
     */
    public void setTotal(int total) {
        this.total = total;
    }
}
