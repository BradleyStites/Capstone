package main.stitesc195.Model;

/**
 * The Role class represents a role object for users to limit or expand user functionality.
 */
public class UserRole {

    /**
     * int representing the unique id value for the user role
     */
    private int id;


    /**
     * String representing the description for the user role.
     */
    private String description;

    /**
     * Boolean value representing the ability of the user role to reset passwords for other users.
     */
    private Boolean administrator;

    /**
     * Constructs an empty 'User Role' object.
     */
    public UserRole() {
    }

    /**
     * Constructs a 'User Role' object with the given parameters.
     *
     * @param id            The unique identifier for the role.
     * @param desc    	        The description of the role.
     * @param administrator     The Administrator value for the role.
     */
    public UserRole(int id, String desc, Boolean administrator) {
        setId(id);
        setDescription(desc);
        setAdministrator(administrator);
    }

    /**
     * returns the id of the role.
     * @return the id of the role.
     */
    public int getId(){
        return id;
    }

    /**
     * returns the description of the role.
     * @return the roles' description
     */
    public String getDescription(){
        return description;
    }

    /**
     * returns the roles' 'CanResetPassword' value.
     * @return the roles ability to 'Reset Passwords'.
     */
    public Boolean getAdministrator(){
        return administrator;
    }

    /**
     * sets the role id
     * @param id the role id to be set
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the description for the role.
     * @param desc The description to be set.
     */
    public void setDescription(String desc){
        this.description = desc;
    }

    /**
     * set the Administrator value for the role.
     *
     * @param administrator the value to set the administrator to for the role.
     */
    public void setAdministrator(Boolean administrator) {
        this.administrator = administrator;
    }

    /**
     * prints out role information. Used to debug problems in the code.
     * @return String containing information regarding an availability.
     */
    public String printInformation() {

        String output =     "'"   + description      + "', " +  administrator;

        return output;
    }
}