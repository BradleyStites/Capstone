package main.stitesc195.Model;

/**
 * The Role class represents a role object for users to limit or expand user functionality.
 */
public class UserRole {

    /**
     * int representing the unique id value for the user role
     */
    private int roleID;


    /**
     * String representing the description for the user role.
     */
    private String description;

    /**
     * Boolean value representing the ability of the user role to reset passwords for other users.
     */
    private Boolean canResetPasswords;

    /**
     * Boolean value representing super user ability of the user role.
     */
    private Boolean superUser;

    /**
     * Constructs an empty 'User Role' object.
     */
    public UserRole() {
    }

    /**
     * Constructs a 'User Role' object with the given parameters.
     *
     * @param roleID  	 The unique identifier for the role.
     * @param desc    	 The description of the role.
     * @param resetPW    The 'CanResetPassword' value for the role.
     * @param superUser  The 'SuperUser' value for the role.
     */
    public UserRole(int roleID, String desc, Boolean resetPW,Boolean superUser) {
        setRoleID(roleID);
        setDescription(desc);
        setCanResetPasswords(resetPW);
        setSuperUser(superUser);
    }

    /**
     * returns the id of the role.
     * @return the id of the role.
     */
    public int getRoleID(){
        return roleID;
    }

    /**
     * returns the description of the role.
     * @return the roles' description
     */
    public String getDescription(){
        return description;
    }

    /**
     * returns the roles' 'CanResetPassword' value.
     * @return the roles ability to 'Reset Passwords'.
     */
    public Boolean getCanResetPasswords(){
        return canResetPasswords;
    }

    /**
     * returns the roles' SuperUser value.
     * @return the roles' SuperUser value
     */
    public Boolean getSuperUser(){
        return superUser;
    }

    /**
     * sets the role id
     * @param id the role id to be set
     */
    public void setRoleID(int id){
        this.roleID = id;
    }

    /**
     * sets the description for the role.
     * @param desc The description to be set.
     */
    public void setDescription(String desc){
        this.description = desc;
    }

    /**
     * set the CanResetPassword value for the role.
     *
     * @param resetPW the value to set the canResetPasswords to for the role.
     */
    public void setCanResetPasswords(Boolean resetPW) {
        this.canResetPasswords = resetPW;
    }

    /**
     * set the SuperUser value for the role.
     *
     * @param superUser the value to set the superUser to for the role.
     */
    public void setSuperUser(Boolean superUser) {
        this.superUser = superUser;
    }

    /**
     * prints out role information. Used to debug problems in the code.
     * @return String containing information regarding an availability.
     */
    public String printInformation() {

        String output =     roleID      +", '"   + description      + "', '" +  canResetPasswords    + "', '" +  superUser;

        System.out.println(output);

        return output;
    }
}