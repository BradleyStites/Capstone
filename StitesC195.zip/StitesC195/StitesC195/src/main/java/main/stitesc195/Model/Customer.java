package main.stitesc195.Model;

import java.sql.Timestamp;
import java.util.Date;

/**
 * The Customer class represents a customer object from the database.
 */
public class Customer {

    /**
     * int representing a unique id for a customer object
     */
    private int     customerID;

    /**
     * string representing the name of a customer object
     */
    private String  customerName;

    /**
     * string representing the address of a customer
     */
    private String  address;

    /**
     * string representing the postal code for the customer object
     */
    private String  postalCode;

    /**
     * string representing the phone number for the customer object
     */
    private String  phone;

    /**
     * date representing the creation date of the customer
     */
    private Date    createdDate;

    /**
     * string representing the username that created the customer
     */
    private String  createdBy;

    /**
     * date representing the last update for the customer
     */
    private Date    lastUpdate;

    /**
     * string representing the username that last update the customer
     */
    private String  lastUpdateBy;

    /**
     * int representing the division id for the customer object
     */
    private int     divisionID;

    /**
     * Constructs an empty Customer object.
     */
    public Customer() {
    }

    /**
     * Constructs a customer object with the following parameters
     * @param customerID        the unique customer id
     * @param customerName      the customer name
     * @param address           the address for the customer
     * @param postalCode        the postal code for the customer
     * @param phone             the phone number for the customer
     * @param lastUpdate        the date the customer was last updated
     * @param lastUpdateBy      the username that last updated the customer
     * @param divisionID        the division id for the customer
     */
    public Customer(int customerID, String customerName, String address, String postalCode, String phone,
                    Date lastUpdate, String lastUpdateBy, int divisionID) {
        setCustomerID(customerID);
        setCustomerName(customerName);
        setCustomerAddress(address);
        setCustomerPostalCode(postalCode);
        setCustomerPhone(phone);
        setCustomerLastUpdate(lastUpdate);
        setCustomerLastUpdateBy(lastUpdateBy);
        setCustomerDivisionID(divisionID);
    }

    /**
     * Constructs a customer object with the following parameters.
     *
     * @param customerID        a unique id for the customer
     * @param customerName      the name of the customer
     * @param address           the address for the customer
     * @param postalCode        the customer's post code
     * @param phone             the customer's phone number
     * @param createdDate       the customer's creation date
     * @param createdBy         the username that created the customer
     * @param lastUpdate        the last update for the customer
     * @param lastUpdateBy      the username that last updated the customer
     * @param divisionID        the division id for the customer
     */
    public Customer(int customerID, String customerName, String address, String postalCode, String phone,
                    Timestamp createdDate, String createdBy, Timestamp lastUpdate, String lastUpdateBy, int divisionID){
        setCustomerID(customerID);
        setCustomerName(customerName);
        setCustomerAddress(address);
        setCustomerPostalCode(postalCode);
        setCustomerPhone(phone);
        setCustomerCreatedDate(createdDate);
        setCustomerCreatedBy(createdBy);
        setCustomerLastUpdate(lastUpdate);
        setCustomerLastUpdateBy(lastUpdateBy);
        setCustomerDivisionID(divisionID);
    }

    /**
     * Constructs a customer object with the following parameters.
     * @param customerID    the unique id for the customer
     * @param customerName  the customer's name
     */
    public Customer(int customerID, String customerName) {
        setCustomerID(customerID);
        setCustomerName(customerName);
    }

    /**
     * returns the unique id for the customer
     * @return the customer's id
     */
    public int getCustomerID(){
        return customerID;
    }

    /**
     * returns the customer's name
     * @return The customer's name
     */
    public String getCustomerName(){
        return customerName;
    }

    /**
     * returns the address for the customer
     * @return customer's address
     */
    public String getAddress(){
        return address;
    }

    /**
     * returns the post code for the customer
     * @return customer's post code
     */
    public String getPostalCode(){
        return postalCode;
    }

    /**
     * returns the phone number of the customer
     * @return customer's phone number
     */
    public String getPhone(){
        return phone;
    }

    /**
     * returns the date of creation for the customer
     * @return customer's creation date
     */
    public Date getCreatedDate(){
        return createdDate;
    }

    /**
     * returns the username that created the customer
     * @return username that created the customer
     */
    public String getCreatedBy(){
        return createdBy;
    }

    /**
     * returns the date of last update for the customer
     * @return the last update
     */
    public Date getLastUpdate(){
        return lastUpdate;
    }

    /**
     * returns the username that last updated the customer
     * @return username of last update
     */
    public String getLastUpdateBy(){
        return lastUpdateBy;
    }

    /**
     * returns the division id associated with the customer
     * @return the customer's division id
     */
    public int getDivisionID(){
        return divisionID;
    }

    /**
     * Used to print information about the customer to the console. Used for debugging purposes.
     * @param cust a customer object
     * @return A string value representing the information to be output.
     */
    public String printCustomerInfo(Customer cust){
        String output = cust.getCustomerID() + "\t";
        output += cust.getCustomerName() + "\t";
        output += cust.getAddress() + "\t";
        output += cust.getPostalCode() + "\t";
        output += cust.getPhone() + "\t";
        output += cust.getCreatedDate() + "\t";
        output += cust.getCreatedBy() + "\t";
        output += cust.getLastUpdate() + "\t";
        output += cust.getLastUpdateBy() + "\t";
        output += cust.getDivisionID() +"\n";

        return output;
    }

    /**
     * sets the unique customer id
     * @param customerID customer id to be set
     */
    public void setCustomerID(int customerID){
        this.customerID = customerID;
    }

    /**
     * sets the customer name
     * @param customerName name to be set
     */
    public void setCustomerName(String customerName){
        this.customerName = customerName;
    }

    /**
     * sets the customer address
     * @param address address to be set
     */
    public void setCustomerAddress(String address){
        this.address = address;
    }

    /**
     * sets the customer postal code
     * @param postalCode post code to be set
     */
    public void setCustomerPostalCode(String postalCode){
        this.postalCode = postalCode;
    }

    /**
     * sets the customer phone number
     * @param phone phone number to be set
     */
    public void setCustomerPhone(String phone){
        this.phone = phone;
    }

    /**
     * sets the customer creation date
     * @param createdDate date of creation to be set
     */
    public void setCustomerCreatedDate(Date createdDate){
        this.createdDate = createdDate;
    }

    /**
     * sets the username that created the customer
     * @param createdBy username that created customer
     */
    public void setCustomerCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }

    /**
     * sets the last update for the customer
     * @param update last update to be set
     */
    public void setCustomerLastUpdate(Date update){
        this.lastUpdate = update;
    }

    /**
     * sets the username of the last update for customer
     * @param person username that last updated the customer
     */
    public void setCustomerLastUpdateBy(String person){
        this.lastUpdateBy = person;
    }

    /**
     * sets the division id for the customer
     * @param id division id to be set
     */
    public void setCustomerDivisionID(int id){
        this.divisionID = id;
    }
}
