package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;

import java.util.Date;

/**
 * The Customer class represents a customer object from the database.
 */
public class Customer {

    /**
     * int representing a unique id for a customer object
     */
    private int id;

    /**
     * string representing the name of a customer object
     */
    private String name;

    /**
     * string representing the address of a customer
     */
    private String  address;

    /**
     * string representing the postal code for the customer object
     */
    private String  postalCode;

    /**
     * string representing the phone number for the customer object
     */
    private String  phone;

    /**
     * date representing the creation date of the customer
     */
    private Date created;

    /**
     * string representing the username that created the customer
     */
    private String  createdBy;

    /**
     * date representing the last update for the customer
     */
    private Date update;

    /**
     * string representing the username that last update the customer
     */
    private String updatedBy;

    /**
     * int representing the division id for the customer object
     */
    private int     divisionID;

    /**
     * Constructs an empty Customer object.
     */
    public Customer() {
    }

    /**
     * Constructs a customer object with the following parameters
     * @param id        the unique customer id
     * @param name      the customer name
     * @param address           the address for the customer
     * @param postalCode        the postal code for the customer
     * @param phone             the phone number for the customer
     * @param update        the date the customer was last updated
     * @param updatedBy      the username that last updated the customer
     * @param divisionID        the division id for the customer
     */
    public Customer(int id, String name, String address, String postalCode, String phone,
                    Date update, String updatedBy, int divisionID) {
        setId(id);
        setName(name);
        setCustomerAddress(address);
        setCustomerPostalCode(postalCode);
        setCustomerPhone(phone);
        setCustomerLastUpdate(update);
        setCustomerLastUpdateBy(updatedBy);
        setCustomerDivisionID(divisionID);
    }

    /**
     * Constructs a customer object with the following parameters.
     *
     * @param id        a unique id for the customer
     * @param name      the name of the customer
     * @param address           the address for the customer
     * @param postalCode        the customer's post code
     * @param phone             the customer's phone number
     * @param created       the customer's creation date
     * @param createdBy         the username that created the customer
     * @param update        the last update for the customer
     * @param updatedBy      the username that last updated the customer
     * @param divisionID        the division id for the customer
     */
    public Customer(int id, String name, String address, String postalCode, String phone,
                    Date created, String createdBy, Date update, String updatedBy, int divisionID){
        setId(id);
        setName(name);
        setCustomerAddress(address);
        setCustomerPostalCode(postalCode);
        setCustomerPhone(phone);
        setCustomerCreatedDate(created);
        setCustomerCreatedBy(createdBy);
        setCustomerLastUpdate(update);
        setCustomerLastUpdateBy(updatedBy);
        setCustomerDivisionID(divisionID);
    }

    /**
     * Constructs a customer object with the following parameters.
     * @param id    the unique id for the customer
     * @param name  the customer's name
     */
    public Customer(int id, String name) {
        setId(id);
        setName(name);
    }

    /**
     * returns the unique id for the customer
     * @return the customer's id
     */
    public int getId(){
        return id;
    }

    /**
     * returns the customer's name
     * @return The customer's name
     */
    public String getName(){
        return name;
    }

    /**
     * returns the address for the customer
     * @return customer's address
     */
    public String getAddress(){
        return address;
    }

    /**
     * returns the post code for the customer
     * @return customer's post code
     */
    public String getPostalCode(){
        return postalCode;
    }

    /**
     * returns the phone number of the customer
     * @return customer's phone number
     */
    public String getPhone(){
        return phone;
    }

    /**
     * returns the date of creation for the customer
     * @return customer's creation date
     */
    public Date getCreated(){
        return created;
    }

    /**
     * returns the username that created the customer
     * @return username that created the customer
     */
    public String getCreatedBy(){
        return createdBy;
    }

    /**
     * returns the date of last update for the customer
     * @return the last update
     */
    public Date getUpdate(){
        return update;
    }

    /**
     * returns the username that last updated the customer
     * @return username of last update
     */
    public String getUpdatedBy(){
        return updatedBy;
    }

    /**
     * returns the division id associated with the customer
     * @return the customer's division id
     */
    public int getDivisionID(){
        return divisionID;
    }

    /**
     * Used to print information about the customer to the console. Used for debugging purposes.
     * @param customer a customer object
     * @return A string value representing the information to be output.
     */
    public String printCustomerInfo(){
        String output = "\'";

        String created = DateHelper.stringDateToFormatForSQL(getCreated());
        String update  = DateHelper.stringDateToFormatForSQL(getUpdate());

        output += getName() 	 	+ "\', \'";
        output += getAddress() 	    + "\', \'";
        output += getPostalCode() 	+ "\', \'";
        output += getPhone() 		+ "\', \'";
        output += created           + "\', \'";
        output += getCreatedBy() 	+ "\', \'";
        output += update 		    + "\', \'";
        output += getUpdatedBy() 	+ "\', ";
        output += getDivisionID();

        return output;
    }

    /**
     * sets the unique customer id
     * @param id customer id to be set
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the customer name
     * @param name name to be set
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * sets the customer address
     * @param address address to be set
     */
    public void setCustomerAddress(String address){
        this.address = address;
    }

    /**
     * sets the customer postal code
     * @param postalCode post code to be set
     */
    public void setCustomerPostalCode(String postalCode){
        this.postalCode = postalCode;
    }

    /**
     * sets the customer phone number
     * @param phone phone number to be set
     */
    public void setCustomerPhone(String phone){
        this.phone = phone;
    }

    /**
     * sets the customer creation date
     * @param createdDate date of creation to be set
     */
    public void setCustomerCreatedDate(Date createdDate){
        this.created = createdDate;
    }

    /**
     * sets the username that created the customer
     * @param createdBy username that created customer
     */
    public void setCustomerCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }

    /**
     * sets the last update for the customer
     * @param update last update to be set
     */
    public void setCustomerLastUpdate(Date update){
        this.update = update;
    }

    /**
     * sets the username of the last update for customer
     * @param person username that last updated the customer
     */
    public void setCustomerLastUpdateBy(String person){
        this.updatedBy = person;
    }

    /**
     * sets the division id for the customer
     * @param id division id to be set
     */
    public void setCustomerDivisionID(int id){
        this.divisionID = id;
    }
}
