package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;

import java.net.URL;
import java.sql.SQLException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import javafx.stage.Stage;
import main.stitesc195.Model.Availability;


/**
 * Contains the logic and variables for the "AvailabilityDetails" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on Availability selection.
 *
 * @author Bradley Stites
 */
public class AvailabilityDetails implements Initializable {

    /**
     * Label used to store text for "Availability ID".
     */
    @FXML
    public Label availabilityIdLabel;

    /**
     * Label used to store text for "Details".
     */
    @FXML
    public TextField availabilityIDField;

    /**
     * Label used to store text for "Status".
     */
    @FXML
    public Label statusLabel;

    /**
     * Label for storing text representing "Start Date".
     */
    @FXML
    public Label startDateLabel;

    /**
     * Label for storing text representing "End Date".
     */
    @FXML
    public Label endDateLabel;

    /**
     * Label for storing text representing "Start Time".
     */
    @FXML
    public Label startTimeLabel;

    /**
     * Label for storing text representing "End Time".
     */
    @FXML
    public Label endTimeLabel;

    /**
     * Label used to store text for "Repeat End Date".
     */
    @FXML
    public Label repeatEndDateLabel;

    /**
     * Label used to store text for "Repeat Frequency".
     */
    @FXML
    public Label repeatFrequencyLabel;

    /**
     * Label used to store text "Details".
     */
    @FXML
    public Label detailsLabel;

    /**
     * Label used to store text for "Details".
     */
    @FXML
    public TextField detailsField;

    /**
     * Button to save the form details into new or existing availability depending on context.
     */
    @FXML
    public Button saveButton;

    /**
     * Button to cancel input and return to previous screen, MainScreen.fxml
     */
    @FXML
    public Button cancelButton;

    /**
     * A DatePicker used to pick the start date for the availability.
     */
    @FXML
    public DatePicker startDatePicker;

    /**
     * A DatePicker used to pick the end date for the availability.
     */
    @FXML
    public DatePicker endDatePicker;

    /**
     * A DatePicker used to pick the end date for the repeat frequency for the availability.
     */
    @FXML
    public DatePicker repeatEndDatePicker;

    /**
     * ComboBox used to store the Start Hours of the availability represented by 24-Hour format
     */
    @FXML
    public ComboBox startTimeHHComboBox;

    /**
     * ComboBox used to store the Start Minutes of the availability represented by 0-59
     */
    @FXML
    public ComboBox startTimeMMComboBox;

    /**
     * ComboBox used to store the End Hours of the availability represented by 24hr format
     */
    @FXML
    public ComboBox endTimeHHComboBox;

    /**
     * ComboBox used to store the End Minutes of the availability represented by 0-59
     */
    @FXML
    public ComboBox endTimeMMComboBox;

    /**
     * A ComboBox used to store the potential values of status. Either: "Available" or "Unavailable" for this version.
     */
    @FXML
    public ComboBox<String> statusComboBox;

    /**
     * A ComboBox used to store the potential values of repeat frequency. Either: "None", "Daily", "Weekly", "Monthly", or "Yearly" for this version.
     */
    @FXML
    public ComboBox<String> repeatFrequencyComboBox;

    /**
     * ObservableList used to store the various hour selections. Represented by 0-23, or a 24-Hour format.
     */
    ObservableList<Integer> hh;

    /**
     * ObservableList used to store the various minute selections. Represented by 0-59.
     */
    ObservableList<Integer> mm;

    /**
     * Availability object used to store a selected availability or new availability
     */
    Availability selectedAvailability;

    /**
     * ObservableList containing the list of all availabilities for the user.
     * Each individual availability will be compared to the new availability for any potential overlaps.
     */
    ObservableList<Availability> userAvailabilities;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert dates and times easily
     */
    DateHelper dateHelper;

    /**
     * String used to hold value for dateFormatter to display dates and times in desired format
     */
    String dateFormat = "yyyy-MM-dd HH:mm:ss";

    /**
     * DateTimeFormatter used to format a date in the pattern of the 'dateFormat' String
     */
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);

    /**
     * Date representing the start date
     */
    Date startDate;

    /**
     * Date representing the end date
     */
    Date endDate;

    /**
     * The end date of the repeat frequency for this availability.
     * This date specifies when the recurring availability period ends.
     */
    Date repeatEnd;

    /**
     * Int representing the active user id
     */
    int activeUserId;
	
	/** 
	 * The start date of the new period for comparison. 
	 */
	Date newStart;

	/** 
	 * The end date of the new period for comparison. 
	 */
	Date newEnd;

	/** 
	 * The repeat end date of the new period for comparison. 
	 */
	Date newRepeatEnd;

	/** 
	 * The start date of the existing (old) period for comparison. 
	 */
	Date oldStart;

	/** 
	 * The end date of the existing (old) period for comparison. 
	 */
	Date oldEnd;

	/** 
	 * The repeat end date of the existing (old) period for comparison. 
	 */
	Date oldRepeatEnd;

    /**
     * SimpleDateFormat used to format a date in the pattern of the 'dateFormat' String
     */
    SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);

    /**
     * Calendar object to hold the value for the new availability start - will loop back to the original value for the
     * new availability starting point on each availability check
     */
    Calendar newCalendarStart   	= Calendar.getInstance();

    /**
     * Calendar object to hold the value for the new availability end - will loop back to the original value for the
     * new availability end point on each new availability check
     */
    Calendar newCalendarEnd     	= Calendar.getInstance();

    /**
     * Calendar object to hold the value for the availability repeat end date - will not be altered.
     */
    Calendar newCalendarRepeatEnd 	= Calendar.getInstance();

    /**
     * Calendar object to hold the value for the old availability start - will change throughout processing. Upon
     * end date reached from either object in the availability check loop will set to the next availability if there
     * are any
     */
    Calendar oldCalendarStart   	= Calendar.getInstance();

    /**
     * Calendar object to hold the value for the old availability end - will change throughout processing. Upon
     * end date reached from either object in the availability check loop will set to the next availability if there
     */
    Calendar oldCalendarEnd     	= Calendar.getInstance();

    /**
     * Calendar object to hold the value for the availability repeat end date - will not be altered.
     */
    Calendar oldCalendarRepeatEnd 	= Calendar.getInstance();

    /**
     * String value to hold the repeat frequency for the new/incoming availability.
     */
    String newRepeatFrequency;

    /**
     * String value to hold the repeat frequency for each availability in the list.
     */
    String oldRepeatFrequency;

    /**
     * ObservableList<String> used to contain the values for the availabilities, used when creating combo box to store the values.
     */
    private static final ObservableList<String> AVAILABILITIES_LIST = FXCollections.observableArrayList("Available", "Not Available");

    /**
     * ObservableList<String> used to contain the values for the repeat frequencies, used when creating combo box to store the values.
     */
    private static final ObservableList<String> REPEAT_FREQUENCY_LIST = FXCollections.observableArrayList("None", "Daily", "Weekly", "Monthly", "Yearly");

	/**
	 * Initializes the controller, setting up form fields, date pickers, and combo boxes for availability data entry.
	 * If a selected availability is present in the ConnectDB class, it populates the form fields with its data.
	 */
    public void initialize(){

		// Check if there's a selected availability from the database and use it
        if(ConnectDB.selectedAvailability!=null){
            selectedAvailability = ConnectDB.selectedAvailability;
        }


		// Initialize form fields for availability data entry
        availabilityIDField 	 = new TextField();		// Field to enter the ID of the availability
        detailsField 			 = new TextField();		// Field to enter details about the availability

		// Setup date pickers for selecting dates
        startDatePicker 		 = new DatePicker();	// Picker for the start date of the availability
        endDatePicker 			 = new DatePicker();	// Picker for the end date of the availability
        repeatEndDatePicker		 = new DatePicker();	// Picker for the repeat end date, if applicable

		// Initialize combo boxes for time selection
        startTimeHHComboBox 	 = new ComboBox();		// Combo box for hour selection at start time
        startTimeMMComboBox 	 = new ComboBox();		// Combo box for minute selection at start time
        endTimeHHComboBox 		 = new ComboBox();		// Combo box for hour selection at end time
        endTimeMMComboBox 		 = new ComboBox();		// Combo box for minute selection at end time

        //-------Status-------//
        ComboBox<String> statusComboBox 	     = new ComboBox<>(AVAILABILITIES_LIST);

        //-------Repeat Frequency-------//
        ComboBox<String> repeatFrequencyComboBox = new ComboBox<>(REPEAT_FREQUENCY_LIST);

        // if updating an availability
        if(ConnectDB.selectedAvailability!=null){
            selectedAvailability = ConnectDB.selectedAvailability;

            // set text fields to availability values
            availabilityIDField.setText(""+ selectedAvailability.getAvailabilityID());
            detailsField.setText(selectedAvailability.getDetails());

			// get dates from availability object
            Date start  = selectedAvailability.getStart(),
                 end    = selectedAvailability.getEnd();
				 
			// convert start values from availability object to a string for manipulation
            String startString = DateHelper.convertServerToUser(start);
            String endString   = DateHelper.convertServerToUser(end);

			// convert the strings back to date objects using ConnectDB
            start = ConnectDB.stringToDate(startString);
            end   = ConnectDB.stringToDate(endString);

            // format strings using ConnectDB
            String startFormatted = ConnectDB.formatAppointmentDateForEdit(start);
            String endFormatted   = ConnectDB.formatAppointmentDateForEdit(end);

			// convert the strings back to date objects using ConnectDB
            start = ConnectDB.stringToDate(startString);
            end   = ConnectDB.stringToDate(endString);

            // set date formatter pattern
            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            
			// create local date from start value using the formatter pattern
			LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
			
			// set start date picker based on the local date variable
            startDatePicker.setValue(ld);

			// create local date from end value using the formatter pattern
            ld = LocalDate.parse(endFormatted, currentDateFormat);
			
			// set end date picker based on the local date variable
            endDatePicker.setValue(ld);

            // create Hours and Minutes string variables ffor Start and End
			// !!! - Does this need to be based on the start and end variables created from doing conversions?
            String startHH = Integer.toString(selectedAvailability.getStart().getHours());
            String startMM = Integer.toString(selectedAvailability.getStart().getMinutes());
            String endHH = Integer.toString(selectedAvailability.getEnd().getHours());
            String endMM = Integer.toString(selectedAvailability.getEnd().getMinutes());

			// set start time and end time combo boxes based on string variables
            startTimeHHComboBox.setValue(startHH);
            startTimeMMComboBox.setValue(startMM);
            endTimeHHComboBox.setValue(endHH);
            endTimeMMComboBox.setValue(endMM);

            // set status and repeat frequency combo box based on availability variables
            statusComboBox.setValue(selectedAvailability.getStatus());
            repeatFrequencyComboBox.setValue(selectedAvailability.getRepeatFrequency());
        }
    }

    /**
     * Sets the selected Availability.
     *
     * @param availability  The Availability selected.
     */
    public void setAvailability(Availability availability){
        selectedAvailability = availability;
    }

    /**
     * Sets the Availability id field to the input id.
     * @param id    the id of the selected Availability.
     */
    public void setAvailabilityIDField(String id){
        this.availabilityIDField.setText(id);
    }

    /**
     * Initializes the AvailabilityDetails class.
     *
     * Sets the text of various gui elements to match language selection and loads details of availability if possible.
     *
     * @param url             The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle  The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        if(ConnectDB.selectedAvailability!=null){
            selectedAvailability = ConnectDB.selectedAvailability;
        }

        //variable for seconds, set to 0 by default. GUI will not allow users to set specific seconds.
        int ss = 0;

        hh = FXCollections.observableArrayList();
        for (int i = 0; i < 24; i++) {
            hh.add(i);
        }

        mm = FXCollections.observableArrayList();
        for (int i = 0; i < 60; i++) {
            if(i%15==0){
                mm.add(i);
            }
        }

        //-------Time Zone Box-------//
        //get current date, time, & zone
        DateTimeFormatter dateTimeFormat = ConnectDB.getCurrentDateTimeZone();

        //-------Status-------//
        for(String statusString : AVAILABILITIES_LIST) {
            statusComboBox.getItems().add(statusString);
        }

        //-------Repeat Frequency-------//
        for(String repeatFrequencyString : REPEAT_FREQUENCY_LIST){
            repeatFrequencyComboBox.getItems().add(repeatFrequencyString);
        }

        //DATES
        //set hh and mm boxes for start and end
        startTimeHHComboBox.setItems(hh);
        startTimeMMComboBox.setItems(mm);

        endTimeHHComboBox.setItems(hh);
        endTimeMMComboBox.setItems(mm);


        //if updating Availability --- this one actually loads the info.
        if(ConnectDB.selectedAvailability!=null) {
            //FIELDS
            //set fields labels for active availability
            availabilityIDField.setText("" + selectedAvailability.getAvailabilityID());
            detailsField.setText(selectedAvailability.getDetails());

            //DATES
            //get dates from the availability object
            Date startDate = ConnectDB.stringToDate(ConnectDB.dateToString(selectedAvailability.getStart()));
            Date endDate   = ConnectDB.stringToDate(ConnectDB.dateToString(selectedAvailability.getEnd()));
            Date repeatEnd = ConnectDB.stringToDate(ConnectDB.dateToString(selectedAvailability.getRepeatEndDate()));

            //convert date from server to user's local time
            String startDateString 		 = ConnectDB.adjustToTimeZone(startDate, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String endDateString   		 = ConnectDB.adjustToTimeZone(endDate  , ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);
            String repeatEndDateString   = ConnectDB.adjustToTimeZone(repeatEnd, ConnectDB.serverTimeZoneId, ConnectDB.userTimeZoneId);

            //set dates to newly converted values
            startDate 	= ConnectDB.stringToDate(startDateString);
            endDate 	= ConnectDB.stringToDate(endDateString);
            repeatEnd 	= ConnectDB.stringToDate(repeatEndDateString);

            //format values for fields & pickers
            String startFormatted 		= ConnectDB.formatAppointmentDateForEdit(startDate);
            String endFormatted 		= ConnectDB.formatAppointmentDateForEdit(endDate);
            String repeatEndFormatted 	= ConnectDB.formatAppointmentDateForEdit(repeatEnd);

            DateTimeFormatter currentDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            //set date pickers
            //start
            LocalDate ld = LocalDate.parse(startFormatted, currentDateFormat);
            startDatePicker.setValue(ld);

            //end
            ld = LocalDate.parse(endFormatted, currentDateFormat);
            endDatePicker.setValue(ld);

            //repeat end
            ld = LocalDate.parse(repeatEndFormatted, currentDateFormat);
            repeatEndDatePicker.setValue(ld);

            //set start and end HH & MM combo pickers
            startTimeHHComboBox.setValue(startDate.getHours());
            startTimeMMComboBox.setValue(startDate.getMinutes());
            endTimeHHComboBox.setValue(endDate.getHours());
            endTimeMMComboBox.setValue(endDate.getMinutes());

            //COMBO BOXES
            statusComboBox.setValue(selectedAvailability.getStatus());
            repeatFrequencyComboBox.setValue(selectedAvailability.getRepeatFrequency());
        }else{
			startTimeHHComboBox.setValue(startTimeHHComboBox.getItems().get(0));
			startTimeMMComboBox.setValue(startTimeMMComboBox.getItems().get(0));

			endTimeHHComboBox.setValue(endTimeHHComboBox.getItems().get(0));
			endTimeMMComboBox.setValue(endTimeMMComboBox.getItems().get(0));
		}

        setLanguage();
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
		// create string variables to hold the specific language values for the GUI elements
        String availabilityId, startDateString, endDateString, status, repeatFrequency, repeatEndDate, details,
               cancel, save, startTimeString, endTimeString;

		// set values on strings based on the lanaguage properties
        availabilityId 		= languages.getString("availabilityId");
        details 			= languages.getString("details");
        status  			= languages.getString("status");
        repeatFrequency 	= languages.getString("repeatFrequency");
        startDateString     = languages.getString("startDate");
        endDateString		= languages.getString("endDate");
        repeatEndDate 		= languages.getString("repeatEndDate");
        startTimeString     = languages.getString("startTime");
        endTimeString       = languages.getString("endTime");
        cancel  			= languages.getString("cancel");
        save    			= languages.getString("save");

        // set the text of GUI labels to reflect the current availability
        availabilityIdLabel.setText(availabilityId);
        detailsLabel.setText(details);
        statusLabel.setText(status);
        repeatFrequencyLabel.setText(repeatFrequency);

        // Set text on date and time labels to display relevant scheduling information
        startDateLabel.setText(startDateString);
        endDateLabel.setText(endDateString);
        startTimeLabel.setText(startTimeString);
        endTimeLabel.setText(endTimeString);
        repeatEndDateLabel.setText(repeatEndDate);

        // Set text on the buttons to match anticipated values
        cancelButton.setText(cancel);
        saveButton.setText(save);
    }

	/**
	 * Handles the saving of availability details when the save button is clicked. This method checks whether
	 * the availability is a new entry or an update to an existing one and saves the details accordingly.
	 * It also validates the date values by passing them to other functions that check for conflicts
	 * with existing availability entries associated with the specific user.
	 *
	 * The method ensures that all data is consistent and valid before committing any changes to the database.
	 * If there are issues with the form data or conflicts detected, appropriate actions or messages are triggered.
	 *
	 * @throws SQLException if there is a failure in executing the SQL command, such as a syntax error in the SQL statement,
	 *         a connection issue, or other database access errors.
	 */
    public void save() throws SQLException, ParseException {

		// Flag to indicate whether the specified availability is acceptable which is determined by other functions
        boolean acceptableAvailability;

        // get the active user id from ConnectDB
        activeUserId = ConnectDB.userID;

        // get the list of availabilities for the user
        userAvailabilities = ConnectDB.getAvailabilitiesForUser(activeUserId);

        // get values from fields
        String  availIdString   = availabilityIDField.getText();
        String  status          = statusComboBox.getValue().toString();
        String  details         = detailsField.getText();
        String  frequency       = repeatFrequencyComboBox.getValue();
		
		// if user hasn't selected a repeat frequency automatically default to "None"
        if(repeatFrequencyComboBox.getValue()==null || repeatFrequencyComboBox.getValue().equals("null")){
            frequency = "None";
        }

        // generate a proper start, end, and repeatEnd based on variables in the form
        convertStartAndEndValuesToDate();

		// Check the availability ID to determine if this is a new or existing availability
        if(availIdString==null || availIdString.equals("")){
            // This indicates a new availability for a user.

            // Generate a new availability ID
            int availId = ConnectDB.generateNewAvailabilityID();

            // Create a new Availability object using the parameters from the form
            selectedAvailability = new Availability(availId, activeUserId, status, details, startDate, endDate, frequency, repeatEnd);

            // Check for overlapping dates to ensure availability validity
            acceptableAvailability = checkAvailability(selectedAvailability);

            if(acceptableAvailability){
				// Attempt to add the availability to the database
                Boolean success = ConnectDB.addAvailability(selectedAvailability);

                if(success){
					// If the addition was successful, show an alert and return to the availabilities view
                    String availabilityAdded = languages.getString("availabilityAdded");
                    viewLoader.showAlert(availabilityAdded);
                    returnToAvailabilitiesView();
                }else{
					// If the addition failed, show an alert indicating the failure
                    String availabilityNotAdded = languages.getString("availabilityNotAdded");
                    viewLoader.showAlert(availabilityNotAdded);
                }
            }else{
				// If the availability is not acceptable, prompt the user with an alert
                String availabilityConflict = languages.getString("availabilityConflict");
                viewLoader.showAlert(availabilityConflict);
            }
        }else{
            // If updating an existing availability, parse the availability ID from the string value in the form.
            int availId = Integer.parseInt(availIdString);

			 // Create a new Availability object using the parameters from the form.
            selectedAvailability = new Availability(availId, activeUserId, status, details, startDate, endDate, frequency, repeatEnd);

            // Check for overlapping dates to ensure availability validity.
            acceptableAvailability = checkAvailability(selectedAvailability);

			
            if(acceptableAvailability){
                // Attempt to update availability in the database
                Boolean success = ConnectDB.updateAvailability(selectedAvailability);

                if(success){
					// If the update was successful, show an alert and return to the availabilities view
                    String availabilityUpdated = languages.getString("availabilityUpdated");
                    viewLoader.showAlert(availabilityUpdated);
                    returnToAvailabilitiesView();
                }else{
					// If the update failed, show an alert indicating the failure
                    String availabilityNotUpdated = languages.getString("availabilityNotUpdated");
                    viewLoader.showAlert(availabilityNotUpdated);
                }
            }
        }
    }

    /**
	 * Converts the values from the various Start and End combo boxes into date objects.
	 *
	 * @throws ParseException if there is an error parsing the date values.
	 */
    private void convertStartAndEndValuesToDate() throws ParseException {
        String repeatEndString;

        // Extract start date as a string from the start date picker.
		String start = startDatePicker.getValue().toString();

		// Extract end date as a string from the end date picker.
		String end = endDatePicker.getValue().toString();

		// Extract start hour as a string from the start time hour combo box.
		String startHH = startTimeHHComboBox.getValue().toString();

		// Extract start minute as a string from the start time minute combo box.
		String startMM = startTimeMMComboBox.getValue().toString();

		// Extract end hour as a string from the end time hour combo box.
		String endHH = endTimeHHComboBox.getValue().toString();

		// Extract end minute as a string from the end time minute combo box.
		String endMM = endTimeMMComboBox.getValue().toString();

		// Check for missing start date, start time, end date, or end time.
		if (start == null || end == null || startHH == null || startMM == null || endHH == null || endMM == null ||
			start.isEmpty() || end.isEmpty() || startHH.isEmpty() || startMM.isEmpty() || endHH.isEmpty() || endMM.isEmpty()) {
			// Notify the user about the missing information.
			String missingInfo = languages.getString("missingDateTimeInfo");
			viewLoader.showAlert(missingInfo);
			return;
		}

		// set default seconds to "00"
        String seconds = "00";

        // generate string for start & end
        String startString  = start + " " + startHH + ":" + startMM +":"+ seconds;
        String endString    = end   + " " + endHH   + ":" + endMM   +":"+ seconds;

        // format start and end date strings
        startDate = dateFormatter.parse(startString);
        endDate   = dateFormatter.parse(endString);

        // set repeat end hh, mm, and ss to end of day
        String repeatEndHH = "23";
        String repeatEndMM = "59";
        String repeatEndSS = "59";
		
		// Adjust start and end dates to the server's timezone.
        String startDateString      = DateHelper.adjustToTimeZone(startDate, ConnectDB.userTimeZoneId, ConnectDB.serverTimeZoneId);
        String endDateString        = DateHelper.adjustToTimeZone(endDate, ConnectDB.userTimeZoneId, ConnectDB.serverTimeZoneId);
		
		// Convert adjusted date strings back to Date objects.
        startDate = ConnectDB.stringToDate(startDateString);
        endDate   = ConnectDB.stringToDate(endDateString);

		// Initialize repeatEndDateString.
        String repeatEndDateString;
		
		// Check if repeatEnd is null or empty; if so, use the end date as the repeat end date.
        if(repeatEndDatePicker.getValue()!=null || repeatEndDatePicker!=null){
            repeatEndDateString = endDateString;
            repeatEnd           = ConnectDB.stringToDate(repeatEndDateString);
        }else{
			// If repeatEnd is specified, parse the repeat end date and adjust it to the server's timezone.
            repeatEndString = repeatEndDatePicker.getValue().toString();
            repeatEndString = repeatEndString + " " + repeatEndHH +":"+repeatEndMM+":"+repeatEndSS;
            repeatEnd = dateFormatter.parse(repeatEndString);
            repeatEndDateString = DateHelper.adjustToTimeZone(repeatEnd, ConnectDB.userTimeZoneId, ConnectDB.serverTimeZoneId);
        }
    }

    /**
     * Checks the availability against user's existing availabilites. If there is no clash, the function will return true.
	 *
	 * @return 
     */
    private boolean checkAvailability(Availability avail){

        //boolean variable to hold if availability is valid - default value is true
        boolean validAvailability = true;

		//if there are no other availabilities, go ahead and return true
        if(userAvailabilities.isEmpty())
            return true;

        //check the incoming availability against any existing availabilities for the user
        for(Availability existingAvailabilities : userAvailabilities){

            //ensure availabilities aren't the same
            if(existingAvailabilities.getAvailabilityID()!=avail.getAvailabilityID()){

                //check the dates
                validAvailability = checkDates(avail, existingAvailabilities);
            }
        }

        return validAvailability;
    }

    /**
     * Returns whether the new availability is valid.
     * Doesn't fall within the start and end date of the old availability.
	 *
	 * @return A boolean variable representing the present validity of the availability check.
     */
    public boolean checkDates(Availability newAvail, Availability oldAvail){

        boolean valid 		= true;
		boolean endDateMet 	= false;

        // Initialize dates for the new and old availabilities
        newStart        = newAvail.getStart();
        newEnd          = newAvail.getEnd();
        newRepeatEnd    = newAvail.getRepeatEndDate();
        oldStart        = oldAvail.getStart();
        oldEnd          = oldAvail.getEnd();
        oldRepeatEnd    = oldAvail.getRepeatEndDate();

        // Initialize calendars for date manipulation
        newCalendarStart.setTime(newStart);
        newCalendarEnd.setTime(newEnd);
		newCalendarRepeatEnd.setTime(newRepeatEnd);
        oldCalendarStart.setTime(oldStart);
        oldCalendarEnd.setTime(oldEnd);
		oldCalendarRepeatEnd.setTime(oldRepeatEnd);

        // Get the repeat frequencies (e.g., daily, weekly) for both availabilities.
        newRepeatFrequency = newAvail.getRepeatFrequency();
        oldRepeatFrequency = oldAvail.getRepeatFrequency();
		
		// Check for overlap between new and old availability dates before entering the loop
//		if (checkOverlap(newStart, newEnd, oldStart, oldEnd)) {
//			return false; // Overlapping dates found
//		}

		// Loop while conditions are valid and neither the repeat end nor the end date has been reached.
		while(valid && !endDateMet){

			// Check for overlapping dates - initial check.
			if(!endDateMet){
				
				// Check for overlap between new and old availability dates.
				valid = !checkOverlap(newStart, newEnd, oldStart, oldEnd);

                // Check if the end date has been reached.
                endDateMet = checkForEndDatesReached();
				
				// If overlap is found, return false.
				if(!valid){
					return valid;
				} else{
					// Increment dates if applicable.
					checkIncrementDate();
				}
			} else{
				// Notify that the end date has been reached.
                System.out.println("end date reached");
				break;
			}
		}

        return valid;
    }

	/**
	 * This function calls upon the compare dates function to determine which date to increment then passes
	 * that value to the incrementDate function to perform the increment.
	 */
    private void checkIncrementDate() {
		
		//string value to denote which date is to be incremented
		String whichToIncrement = "";
		
        //first need to check which date is smaller/larger to know which one needs to be incremented
        whichToIncrement = compareDates();

        //increment appropriate date and calendar properties
		switch(whichToIncrement){
			case "None":
				break;
			case "New":
				incrementDate(newCalendarStart, newCalendarEnd, newRepeatFrequency);
				break;
			case "Old":
				incrementDate(oldCalendarStart, oldCalendarEnd, oldRepeatFrequency);
				break;
		}
    }
	
	/**
	 * This function calls takes two calendar variables, start and end, and increments them based on the
	 * given repeat frequency.
	 *
	 * @param start 			A Calendar variable representing the start point for a given availability.
	 * @param end				A Calendar variable representing the end point for a given availability.
	 * @param repeatFrequency	A String variable representing the repeat frequency for a given availability.
	 */
	private void incrementDate(Calendar start, Calendar end, String repeatFrequency){
		switch (repeatFrequency) {
			case "Daily":
				start.add(Calendar.DAY_OF_MONTH, 1);
				end.add(Calendar.DAY_OF_MONTH, 1);
				break;
			case "Weekly":
				start.add(Calendar.WEEK_OF_YEAR, 1);
				end.add(Calendar.WEEK_OF_YEAR, 1);
				break;
			case "Monthly":
				start.add(Calendar.MONTH, 1);
				end.add(Calendar.MONTH, 1);
				break;
			case "Yearly":
				start.add(Calendar.YEAR, 1);
				end.add(Calendar.YEAR, 1);
				break;
			case "None":
				// No need to increment the date
				break;
			default:
				// Handle unsupported repeat frequencies - this should not occur
				throw new IllegalArgumentException("Unsupported repeat frequency: " + repeatFrequency);
		}
	}

	/**
	 * This function first calls upon the checkForEndDateReached to see if any of the start or end dates of the 
     * availabilities being looped through have reached their repeatEndDates. If no end dates have been met it will
	 * compare the dates to see which one has the earliest start and return that value in string form, either "None",
	 * "New", or "Old". This value will be used in the checkIncrementDate function to be passed to the incrementDate
	 * function to actually perform the incrementing.
	 *
	 * @return A string value representing which availability to increment.
	 */
    private String compareDates() {
        if (checkForEndDatesReached()) {
            return "EndDateMet";
        }

        // Check for exact match or overlap - this might be caught by previous checks and be useless
        if (newStart.equals(oldStart) || newStart.equals(oldEnd) ||
                newEnd.equals(oldStart) || newEnd.equals(oldEnd) ||
                (newStart.after(oldStart) && newStart.before(oldEnd)) ||
                (newEnd.after(oldStart) && newEnd.before(oldEnd))) {
            return "None";
        }

        // Determine which availability to increment based on start dates
        if (newStart.before(oldStart) || newEnd.before(oldEnd)) {
            return "New";
        } else {
            return "Old";
        }
    }

    /**
	 * This function checks to see if the end dates of either calendar have been met
	 *
	 * @return True if any of the end dates have been reached
	 */
    private Boolean checkForEndDatesReached() {
		return newCalendarStart.after(newCalendarRepeatEnd) || newCalendarStart.equals(newCalendarRepeatEnd) ||
			   oldCalendarStart.after(oldCalendarRepeatEnd) || oldCalendarEnd.equals(oldCalendarRepeatEnd);
    }

    /**
     * Checks for date overlap.
     *
     * @param start1 Start date of the first period.
     * @param end1   End date of the first period.
     * @param start2 Start date of the second period.
     * @param end2   End date of the second period.
     * @return 		 True if there is an overlap
     */
    private static boolean checkOverlap(Date start1, Date end1, Date start2, Date end2) {

        // Check if one range starts or ends within the other range
        Boolean start1Between   = (start1.after(start2) && start1.before(end2));
        Boolean end1Between     = (end1.after(start2) && end1.before(end2));
        Boolean start2Between   = (start2.after(start1) && start2.before(end1));
        Boolean end2Between     = (end2.after(start1) && end2.before(end1));

        // Check if one range completely encompasses the other
        boolean start1BeforeAndEnd1After = start1.before(start2) && end1.after(end2);
        boolean start2BeforeAndEnd2After = start2.before(start1) && end2.after(end1);

        // Logging to see which conditions are true
        if (start1Between) System.out.println("Start 1 in between");
        if (end1Between) System.out.println("End 1 in between");
        if (start2Between) System.out.println("Start 2 in between");
        if (end2Between) System.out.println("End 2 in between");
        if (start1BeforeAndEnd1After) System.out.println("Range 1 encompasses Range 2");
        if (start2BeforeAndEnd2After) System.out.println("Range 2 encompasses Range 1");

        // Return true if any of the conditions indicate overlap
        return start1Between || end1Between || start2Between || end2Between ||
                start1BeforeAndEnd1After || start2BeforeAndEnd2After;
    }

    /**
     * Returns the user to the previous screen, "Availabilities.fxml".
     */
    public void cancel(){
        returnToAvailabilitiesView();
    }
	
	/**
     * Returns the user to the previous screen, "Availabilities.fxml".
     */
    private void returnToAvailabilitiesView() {
        currentStage = (Stage) saveButton.getScene().getWindow();
        viewLoader.loadFXML("Availabilities", currentStage);
    }

}