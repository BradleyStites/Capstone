package main.stitesc195.Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.stitesc195.Model.UserRole;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "UserRoleDetails" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class UserRoleDetails implements Initializable {

    /**
     * Add button for adding roles, loads the UserRoleDetails screen when pressed.
     */
    @FXML
    private Button saveButton;

    /**
     * Represents the cancel button in the user interface.
     * This button allows users to cancel the current operation and return to the previous screen.
     */
    @FXML
    private Button cancelButton;

    /**
     * CheckBox for indicating whether passwords can be reset.
     */
    @FXML
    private CheckBox canResetPasswordsCheckbox;

    /**
     * Label associated with the canResetPasswordsCheckbox.
     */
    @FXML
    private Label canResetPasswordsLabel;

    /**
     * CheckBox for indicating whether the user has superuser privileges.
     */
    @FXML
    private CheckBox superUserCheckbox;

    /**
     * Label associated with the superUserCheckbox.
     */
    @FXML
    private Label superUserLabel;

    /**
     * Label for the role description.
     */
    @FXML
    private Label roleDescriptionLabel;

    /**
     * TextField for entering the role description.
     */
    @FXML
    private TextField roleDescriptionTextField;

    /**
     * Label for the role ID.
     */
    @FXML
    private Label roleIdLabel;

    /**
     * TextField for entering the role ID.
     */
    @FXML
    private TextField roleIdTextField;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Customer object representing the selected user role.
     */
    private UserRole selectedRole;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     *  Initializes the UserRoleDetails screen.
     *
     *  Sets the text on the various GUI elements to the match language
     *  selection.
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        viewLoader = new ViewLoader();

        //if a role is selected set the values on the form to match the tuple
        if (ConnectDB.selectedRole != null) {
            selectedRole = ConnectDB.selectedRole;

            //set fields to match relevant variables to the selected user role
            roleIdTextField.setText(String.valueOf(selectedRole.getRoleID()));
            roleDescriptionTextField.setText(selectedRole.getDescription());
            canResetPasswordsCheckbox.setSelected(selectedRole.getCanResetPasswords());
            superUserCheckbox.setSelected(selectedRole.getSuperUser());
        }
    }

    /**
     * Initializes the null GUI elements on the UserRoleDetails page.
     */
    public void initialize(){
        roleIdLabel                 = new Label();
        roleDescriptionLabel        = new Label();
        canResetPasswordsLabel      = new Label();
        superUserLabel              = new Label();

        roleIdTextField             = new TextField();
        roleDescriptionTextField    = new TextField();
        canResetPasswordsCheckbox   = new CheckBox();
        superUserCheckbox           = new CheckBox();

        setLanguage();
    }

    /**
     * Returns the user to the "Dashboard.fxml" screen.
     */
    public void cancel() {
        currentStage = (Stage) cancelButton.getScene().getWindow();
        viewLoader.loadFXML("Dashboard", currentStage);
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
        String roleId, roleDesc, canResetPassword, superUser, save, cancel;

        roleId              = languages.getString("roleId");
        roleDesc            = languages.getString("roleDesc");
        canResetPassword    = languages.getString("canResetPassword");
        superUser           = languages.getString("superUser");
        save                = languages.getString("save");
        cancel              = languages.getString("cancel");

        roleIdLabel.setText(roleId);
        roleDescriptionLabel.setText(roleDesc);
        canResetPasswordsLabel.setText(canResetPassword);
        superUserLabel.setText(superUser);
        saveButton.setText(save);
        cancelButton.setText(cancel);
    }

    public void setRole(UserRole selectedRole) {
        this.selectedRole = selectedRole;
    }

    public void loadDetails(UserRole selectedRole) {
        roleIdTextField.setText(String.valueOf(selectedRole.getRoleID()));
        roleDescriptionTextField.setText(selectedRole.getDescription());
        canResetPasswordsCheckbox.setSelected(selectedRole.getCanResetPasswords());
        superUserCheckbox.setSelected(selectedRole.getSuperUser());
    }
}
