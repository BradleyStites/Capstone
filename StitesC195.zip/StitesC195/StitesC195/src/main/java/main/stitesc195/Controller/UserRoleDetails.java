package main.stitesc195.Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.stitesc195.Model.UserRole;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "UserRoleDetails" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class UserRoleDetails implements Initializable {

    /**
     * Add button for adding roles, loads the UserRoleDetails screen when pressed.
     */
    @FXML
    private Button saveButton;

    /**
     * Represents the cancel button in the user interface.
     * This button allows users to cancel the current operation and return to the previous screen.
     */
    @FXML
    private Button cancelButton;

    /**
     * CheckBox for indicating whether passwords can be reset.
     */
    @FXML
    private CheckBox administratorCheckBox;

    /**
     * Label for the role description.
     */
    @FXML
    private Label descriptionLabel;

    /**
     * TextField for entering the role description.
     */
    @FXML
    private TextField descriptionField;

    /**
     * Label for the role ID.
     */
    @FXML
    private Label idLabel;

    /**
     * TextField for entering the role ID.
     */
    @FXML
    private TextField idField;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Customer object representing the selected user role.
     */
    private UserRole selectedRole;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     *  Initializes the UserRoleDetails screen.
     *  Sets the text on the various GUI elements to the match language selection.
     *
     * @param url The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        viewLoader = new ViewLoader();

        //if a role is selected set the values on the form to match the tuple
        if (ConnectDB.selectedRole != null) {
            selectedRole = ConnectDB.selectedRole;

            //set fields to match relevant variables to the selected user role
            idField.setText(String.valueOf(selectedRole.getId()));
            descriptionField.setText(selectedRole.getDescription());
            administratorCheckBox.setSelected(selectedRole.getAdministrator());
        }

        setLanguage();
    }

    /**
     * Initializes the null GUI elements on the UserRoleDetails page.
     */
    public void initialize(){
        idLabel = new Label();
        descriptionLabel = new Label();

        idField = new TextField();
        descriptionField = new TextField();
        administratorCheckBox       = new CheckBox();
    }

    /**
     * Returns the user to the "Dashboard.fxml" screen.
     */
    public void cancel() {
        currentStage = (Stage) cancelButton.getScene().getWindow();
        viewLoader.loadFXML("UserRoles", currentStage);
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
        String roleId, roleDesc, administrator, save, cancel;

        roleId              = languages.getString("roleId");
        roleDesc            = languages.getString("roleDesc");
        administrator       = languages.getString("administrator");
        save                = languages.getString("save");
        cancel              = languages.getString("cancel");

        idLabel.setText(roleId);
        descriptionLabel.setText(roleDesc);
        administratorCheckBox.setText(administrator);
        saveButton.setText(save);
        cancelButton.setText(cancel);
    }

    /**
     * Sets the selected user role.
     *
     * @param selectedRole the selected user role to set
     */
    public void setRole(UserRole selectedRole) {
        this.selectedRole = selectedRole;
    }

    /**
     * Loads the details of the selected user role into the GUI components.
     *
     * @param selectedRole the selected user role
     */
    public void loadDetails(UserRole selectedRole) {
        idField.setText(String.valueOf(selectedRole.getId()));
        descriptionField.setText(selectedRole.getDescription());
        administratorCheckBox.setSelected(selectedRole.getAdministrator());
    }

    public void save() {
        String  roleId;
        Boolean success;

        // get information from form
        if(idField !=null && !idField.getText().isEmpty())
            roleId       = idField.getText();
        else
            roleId = null;

        String description  = descriptionField.getText();
        Boolean admin       = administratorCheckBox.isSelected();

        //create a role object based on the information provided
        if(roleId!=null && !roleId.isEmpty()){
            //this is an update
            UserRole role = new UserRole(Integer.parseInt(roleId), description, admin);
            success = ConnectDB.updateRole(role);
            System.out.println("Updating Role: "+success);

            if(success){
                String roleUpdated = languages.getString("roleUpdated");
                viewLoader.showAlert(roleUpdated);

                //return to dashboard
                cancel();
            }else{
                String roleUpdated = languages.getString("roleNotUpdated");
                viewLoader.showAlert(roleUpdated);
            }
        }else{
            //this is a new role
            UserRole role = new UserRole(0, description, admin);
            success = ConnectDB.addRole(role);
            System.out.println("Adding Role: "+success);

            if(success){
                String roleAdded = languages.getString("roleAdded");
                viewLoader.showAlert(roleAdded);

                //return to dashboard
                cancel();
            }else{
                String roleNotAdded = languages.getString("roleNotAdded");
                viewLoader.showAlert(roleNotAdded);
            }
        }
    }
}
