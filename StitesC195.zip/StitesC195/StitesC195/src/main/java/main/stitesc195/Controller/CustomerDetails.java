package main.stitesc195.Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.stage.Stage;
import main.stitesc195.Model.Country;
import main.stitesc195.Model.Customer;
import main.stitesc195.Model.Division;

/**
 * Contains the logic and variables for the "CustomerDetails" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class CustomerDetails implements Initializable {

    /**
     * Label used to store text for "Customer ID".
     */
    @FXML
    public Label customerIdLabel;

    /**
     * Label used to store text for "Customer Name".
     */
    @FXML
    public Label customerNameLabel;

    /**
     * Label used to store text for "Address".
     */
    @FXML
    public Label addressLabel;

    /**
     * Label used to store text for "Postal Code".
     */
    @FXML
    public Label postalCodeLabel;

    /**
     * Label used to store text for "Phone".
     */
    @FXML
    public Label phoneLabel;

    /**
     * Label used to store text for "Created".
     */
    @FXML
    public Label createdLabel;

    /**
     * Label used to store text for "Created By".
     */
    @FXML
    public Label createdByLabel;

    /**
     * Label used to store text for "Updated".
     */
    @FXML
    public Label updatedLabel;

    /**
     * Label used to store text for "Updated By".
     */
    @FXML
    public Label updatedByLabel;

    /**
     * Label used to store text for "Country".
     */
    @FXML
    public Label countryLabel;

    /**
     * Label used to store text for "Division".
     */
    @FXML
    public Label divisionLabel;

    /**
     * TextField used to store "Customer IDs"
     */
    @FXML
    public TextField customerIDField;

    /**
     * TextField used to store "Customer Names"
     */
    @FXML
    public TextField customerNameField;

    /**
     * TextField used to store "Customer Addresses"
     */
    @FXML
    private TextField addressField;

    /**
     * TextField used to store "Customer Post Codes"
     */
    @FXML
    private TextField postalCodeField;

    /**
     * TextField used to store "Customer Phones"
     */
    @FXML
    private TextField phoneField;

    /**
     * ComboBox used to store selected country.
     */
    @FXML
    private ComboBox countryComboBox;

    /**
     * ComboBox used to store selected division.
     */
    @FXML
    private ComboBox divisionComboBox;

    /**
     * TextField used to store the creation date.
     */
    @FXML
    private TextField createdDateField;

    /**
     * TextField used to store the created by username.
     */
    @FXML
    private TextField createdByField;

    /**
     * TextField used to store the last update.
     */
    @FXML
    private TextField lastUpdateField;

    /**
     * TextField used to store the username of who last updated the customer.
     */
    @FXML
    private TextField lastUpdatedByField;

    /**
     * Button to save the form details into new or existing customer depending on context.
     */
    @FXML
    private Button saveButton;

    /**
     * Button to cancel input and return to previous screen, MainScreen.fxml
     */
    @FXML
    private Button cancelButton;

    /**
     * ObservableList containing the list of all divisions
     */
    ObservableList<Division> divisionsList;

    /**
     * ObservableList containing the list of all countries
     */
    ObservableList<Country> countryList;

    /**
     * Customer object representing the selected customer.
     */
    private Customer customer;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert dates and times easily
     */
    DateHelper dateHelper;

    /**
     * Initializes the null GUI elements on the CustomerDetails page.
     */
    public void initialize(){

        customerIDField = new TextField();
        customerIDField.setText(""+customer.getId());

        customerNameField = new TextField();
        customerNameField.setText(customer.getName());

        addressField = new TextField();
        postalCodeField = new TextField();
        phoneField = new TextField();
        createdDateField = new TextField();
        createdByField = new TextField();
        lastUpdateField = new TextField();
        lastUpdatedByField = new TextField();
        divisionComboBox = new ComboBox<Division>();
        countryComboBox = new ComboBox<Country>();
    }

    /**
     * Sets the selected customer.
     *
     * @param customer  The customer selected.
     */
    public void setCustomer(Customer customer){
        this.customer = customer;
    }

    /**
     * Sets the customer id field to the input id.
     * @param id    the id of the selected customer.
     */
    public void setCustomerIDField(String id){
        this.customerIDField.setText(id);
    }

    /**
     * Initializes the CustomerDetails class.
     * Gets the divisions, and countries and sets combo box values to the appropriate array list, and sets the text of various
     * gui elements to match language selection.
     *
     * @param url             The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle  The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        if(ConnectDB.selectedCustomer!=null){
            customer = ConnectDB.selectedCustomer;
        }

        divisionsList = FXCollections.observableArrayList();
        countryList   = FXCollections.observableArrayList();

        //get divisions
        divisionsList = getDivisions();

        //populate combo box for new customers
        if(ConnectDB.selectedCustomer==null){
            divisionComboBox.getItems().addAll(divisionsList.stream()
                    .map(Division::getDivision)
                    .collect(Collectors.toList()));
        }

        //get country names
        countryList = getCountries();

        for(Country c : countryList){
            countryComboBox.getItems().add(c.getCountry());
        }

        //if updating a customer
        if(ConnectDB.selectedCustomer!=null) {
            customerIDField.setText("" + customer.getId());
            customerNameField.setText(customer.getName());
            addressField.setText(customer.getAddress());
            postalCodeField.setText(customer.getPostalCode());
            phoneField.setText(customer.getPhone());
            createdByField.setText(customer.getCreatedBy());
            lastUpdatedByField.setText(customer.getUpdatedBy());

            //convert values for updated and created from server to user
            String createdDate = DateHelper.convertServerToUser(customer.getCreated());
            createdDateField.setText(createdDate);
            String updated     = DateHelper.convertServerToUser(customer.getUpdate());
            lastUpdateField.setText(updated);

            //get division name, list, & populate combo box
            Division division = new Division();
            try {
                division = ConnectDB.getDivisionByID(customer.getDivisionID());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

            try {
                divisionsList = getDivisionsByCountry(customer.getDivisionID());
            } catch (SQLException e) {
                e.printStackTrace();
            }

            divisionComboBox.getItems().addAll(divisionsList.stream()
                    .map(Division::getDivision)
                    .collect(Collectors.toList()));

            int divisionIndex = 0;

            for(int i =0; i<divisionsList.size(); i++){
                if(divisionsList.get(i).getId() ==  customer.getDivisionID()){
                    divisionIndex = i;
                    System.out.println("divisionIndex: " + divisionIndex);
                }
            }

            //get country name & populate combo box
            Country country = new Country();
            try{
                country = ConnectDB.getCountryById(division.getCountryId());
            }catch(Exception e){
                e.printStackTrace();
            }

            int index=0;
            for(int i=0; i<countryList.size(); i++){
                if(countryList.get(i).getId() == country.getId()){
                    index = i;
                }
            }

            //select the customers country in the country combo box
            countryComboBox.getSelectionModel().select(index);
            divisionComboBox.getSelectionModel().select(divisionIndex);
        }

        setLanguage();
    }

    /**
     * Sets the text of various GUI elements of this class to match language selection.
     */
    private void setLanguage() {
        String customerId, customerName, address, postCode, phone, created, createdBy, updated, updatedBy, country,
                division, cancel;

        customerId = languages.getString("customerId");
        customerName = languages.getString("name");
        address = languages.getString("address");
        postCode = languages.getString("postCode");
        phone = languages.getString("phone");
        created = languages.getString("created");
        createdBy = languages.getString("createdBy");
        updated = languages.getString("updated");
        updatedBy = languages.getString("updatedBy");
        country = languages.getString("country");
        division = languages.getString("division");
        cancel  = languages.getString("cancel");

        customerIdLabel.setText(customerId);
        customerNameLabel.setText(customerName);
        addressLabel.setText(address);
        postalCodeLabel.setText(postCode);
        phoneLabel.setText(phone);
        createdLabel.setText(created);
        createdByLabel.setText(createdBy);
        updatedLabel.setText(updated);
        updatedByLabel.setText(updatedBy);
        countryLabel.setText(country);
        divisionLabel.setText(division);
        cancelButton.setText(cancel);
    }

    /**
     * Gets divisions and country list and sets division combo box.
     * @param selectedCustomer the customer selected customer to get the division and country value from
     */
    public void loadDetails(Customer selectedCustomer){

        //get divisions and countries
        try {
            divisionsList = getDivisionsByCountry(selectedCustomer.getDivisionID());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        countryList = getCountries();

        int divisionIndex = -1;
        int countryid=-1;
        int countryIndex = -1;

        for(Division division : divisionsList){
            if(division.getId() == selectedCustomer.getDivisionID()){
                divisionIndex = divisionsList.indexOf(division);
                System.out.println("Division ID: " + division.getId() + "\tIndex: "+divisionIndex + "\tdivision: " +division.getDivision());
                countryid = division.getCountryId();

            }
        }

        for(Country country : countryList){
            if(country.getId()==countryid){
                countryIndex= countryList.indexOf(country);
            }
        }

        //populate country box with matching country for selected division
        countryComboBox.getSelectionModel().select(countryIndex);
        countryComboBox.setValue(countryList.get(countryIndex).getCountry());

//        try {
//            refreshDivisionComboBoxOnCountrySelection();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }

        divisionComboBox.getSelectionModel().select(divisionIndex);

    }

    private ObservableList<Division> getDivisionsByCountry(int divisionID) throws SQLException {
        ObservableList<Division> divisions = null;

        //get country name from the division id supplied
        String countryName = ConnectDB.getCountryNameByDivisionId(divisionID);

        try{
            divisions = ConnectDB.getDivisionsByCountryName(countryName);
        }catch(SQLException e){
            e.printStackTrace();
        }

        return divisions;
    }

    /**
     * gets divisions from the database
     * @return  ObservableList with divisions from the database
     */
    public ObservableList<Division> getDivisions(){
        ObservableList<Division> divisions = null;

        try {
            divisions = ConnectDB.getDivisions();
        }catch(SQLException e){
            e.printStackTrace();
        }

        return divisions;
    }

    /**
     * Gets the countries from the database.
     * @return the list of countries
     */
    public ObservableList<Country> getCountries(){

        ObservableList<Country> countries = null;

        try{
            countries = ConnectDB.getCountries();

        }catch(SQLException e){
            e.printStackTrace();
        }

        return countries;
    }

    /**
     * Logic for save Button.
     * Determines if new or existing customer and saves details from form appropriately.
     *
     * @throws SQLException if there is an error with the SQL statement or server.
     */
    public void save()throws SQLException{

        //get values from fields
        String id        = customerIDField.getText();
        String name      = customerNameField.getText();
        String address   = addressField.getText();
        String postal    = postalCodeField.getText();
        String phone     = phoneField.getText();
        String division  = divisionComboBox.getValue().toString();
        String created   = createdDateField.getText();
        String createdBy = createdByField.getText();

        int divisionID = -1;

        Date updated        = ConnectDB.getDateFromServer();
        String updatedBy    = ConnectDB.getUserNameById(ConnectDB.userID);

        //get the divisions from the database
        divisionsList = getDivisions();

        //get division ID from division name
        for(Division d : divisionsList){
            if(division.equals(d.getDivision())){
                divisionID = d.getId();
            }
        }

        if(id==null || id.isEmpty()){
            // This is a New Customer
            Date createdDate  =ConnectDB.getDateFromServer();
            createdBy= ConnectDB.getUserNameById(ConnectDB.userID);
			
			Customer newCustomer = new Customer(0, name, address, postal, phone, createdDate, createdBy, updated, updatedBy, divisionID);
			Boolean success = ConnectDB.addCustomer(newCustomer);

            if(success){
                String customerAdded = languages.getString("customerAdded");
                viewLoader.showAlert(customerAdded);

                returnToCustomers();
            }else{
                String customerNotAdded = languages.getString("customerNotAdded");
                viewLoader.showAlert(customerNotAdded);
            }
        }else{
            // Updating customer

            //convert created date string to actual date
            Date createdDate = DateHelper.stringToDate(created);

            // create customer object from parameters in form
            customer = new Customer(Integer.parseInt(id),name, address, postal, phone, createdDate, createdBy,
                                    updated,updatedBy,divisionID);

            // Get Integer value for Result of Edit Customer
            int result = ConnectDB.editCustomer(customer);

            // Set Boolean value on previous integer result
            // True if >0
            Boolean success = (result > 0);

            if(success){
                String customerAdded = languages.getString("customerUpdated");
                viewLoader.showAlert(customerAdded);
                returnToCustomers();
            }else{
                String customerNotAdded = languages.getString("customerNotUpdated");
                viewLoader.showAlert(customerNotAdded);
            }
        }
    }

    /**
     * Returns the user to the previous screen, "Customers.fxml".
     */
    private void returnToCustomers() {
        currentStage = (Stage) saveButton.getScene().getWindow();
        viewLoader.loadFXML("Customers", currentStage);
    }

    /**
     * Returns the user to the previous screen, "Customers.fxml".
     */
    public void cancel(){
        returnToCustomers();
    }

    /**
     * Reloads the division combo box with options based on the country combo box selection.
     *
     * @throws SQLException if there is an error with the SQL statement or server.
     */
    public void refreshDivisionComboBoxOnCountrySelection() throws SQLException {

        ObservableList<Division> filteredDivisionsList = FXCollections.observableArrayList();

        //get the selection from the country combo box
        String countrySelection = countryComboBox.getSelectionModel().getSelectedItem().toString();

        //get the divisions that are connected to the country selection from the database
        filteredDivisionsList = ConnectDB.getDivisionsByCountryName(countrySelection);

        // clear the division combo box
        divisionComboBox.getSelectionModel().clearSelection();
        divisionComboBox.getItems().removeAll();
        divisionComboBox.getItems().clear();

        divisionComboBox.getItems().removeAll(divisionComboBox.getItems());

        // populate division list by setting the contents of the division combo box to the new filtered divisions list
        if(filteredDivisionsList.size()>0){

            divisionComboBox.getItems().addAll(filteredDivisionsList.stream()
                    .map(Division::getDivision)
                    .collect(Collectors.toList()));
        }

        for(Division d:filteredDivisionsList){
            System.out.println(d.getDivision());
        }
    }
}