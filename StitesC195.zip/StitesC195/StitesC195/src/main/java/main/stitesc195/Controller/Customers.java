package main.stitesc195.Controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.control.*;

import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Customer;

/**
 * Contains the logic and variables for the "Customers" screen, handles errors and prompts for various
 * conditions, launches different screens, sets texts on GUI elements based on user selection.
 *
 * @author Bradley Stites
 */
public class Customers implements Initializable {

    /**
     * Add button for adding customer, loads the CustomerDetails screen when pressed.
     */
    @FXML
    private Button addButton;

    /**
     * Back button for return to previous screen, loads the MainScreen.
     */
    @FXML
    private Button backButton;

    /**
     * TableView for storing the various customers.
     */
    @FXML
    private TableView customersTable;

    /**
     * Modify Button for viewing or modifying an existing customer, loads CustomerDetails screen when pressed.
     */
    @FXML
    private Button modifyButton;

    /**
     * Delete button for deleting a selected customer from the table and database
     */
    @FXML
    private Button deleteButton;

    /**
     * TableColumn for storing Customer Ids
     */
    @FXML
    TableColumn<Customer, Integer> customerIDColumn;

    /**
     * TableColumn for storing Customer Names
     */
    @FXML
    TableColumn<Customer, String> customerNameColumn;

    /**
     * TableColumn for storing Customer Addresses
     */
    @FXML
    TableColumn<Customer, String> addressColumn;

    /**
     * TableColumn for storing Customer Post Codes
     */
    @FXML
    TableColumn<Customer, String> postCodeColumn;

    /**
     * TableColumn for storing Customer Phone Numbers
     */
    @FXML
    TableColumn<Customer, String> phoneColumn;

    /**
     * TableColumn for storing Customer Creation Date
     */
    @FXML
    TableColumn<Customer, String> createdDateColumn;

    /**
     * TableColumn for storing Customer Created By values
     */
    @FXML
    TableColumn<Customer, String> createdByColumn;

    /**
     * TableColumn for storing Customer Last Updated values
     */
    @FXML
    TableColumn<Customer, String> updatedColumn;

    /**
     * TableColumn for storing Customer Last Updated By values
     */
    @FXML
    TableColumn<Customer, String> updatedByColumn;

    /**
     * TableColumn for storing Customer Division IDs
     */
    @FXML
    TableColumn<Customer, Integer> divisionIDColumn;

    /**
     * ObservableList used to store all customers
     */
    ObservableList<Customer> customers = FXCollections.observableArrayList();

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages      = ResourceBundle.getBundle("language");

    /**
     * Boolean value used to represent false if converting toServer
     */
    static final Boolean toServer = false;

    /**
     * Boolean value used to represent false if converting fromServer
     */
    static final Boolean fromServer = true;

    /**
     * Customer object used to store the selected Customer
     */
    private static Customer selectedCustomer = new Customer();

    /**
     * DateHelper class to help convert dates
     */
    DateHelper dateHelper;

    /**
     * Initializes the Customers screen.
     * Sets the GUI elements to the appropriate text based on language selection and gets all customers from the database
     * and displays them in the table view.
     *
     * @param url            The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();
        setLanguage();

        //get all customers from the database and load into cells
        getAllCustomers(customers);
    }

    /**
     *  Populates the Customers' table with the customers Observable List. Sets the appropriate cell factories to
     *  display customer information, and converts date/time values from the server time to the user's local time
     *  zone, and updates the table view.
     *
     * @param customers An ObservableList of Customer objects containing all customers to be displayed.
     */
    public void getAllCustomers(ObservableList<Customer> customers) {
        PropertyValueFactory<Customer, Integer> idColumnFactory = new PropertyValueFactory<>("id");
        customerIDColumn.setCellValueFactory(idColumnFactory);

        PropertyValueFactory<Customer, String> customerNameColumnFactory = new PropertyValueFactory<>("name");
        customerNameColumn.setCellValueFactory(customerNameColumnFactory);

        PropertyValueFactory<Customer, String> addressColumnFactory = new PropertyValueFactory<>("address");
        addressColumn.setCellValueFactory(addressColumnFactory);

        PropertyValueFactory<Customer, String> postCodeColumnFactory = new PropertyValueFactory<>("postalCode");
        postCodeColumn.setCellValueFactory(postCodeColumnFactory);

        PropertyValueFactory<Customer, String> phoneColumnFactory = new PropertyValueFactory<>("phone");
        phoneColumn.setCellValueFactory(phoneColumnFactory);

        PropertyValueFactory<Customer, String> createDateFactory = new PropertyValueFactory<>("created");
        createdDateColumn.setCellValueFactory(createDateFactory);
        createdDateColumn.setCellValueFactory(cellData -> {
            Date createDate = cellData.getValue().getCreated();
            String createDateString = DateHelper.dateToString(createDate);
            return new SimpleStringProperty(createDateString);
        });

        PropertyValueFactory<Customer, String> createdByColumnFactory = new PropertyValueFactory<>("createdBy");
        createdByColumn.setCellValueFactory(createdByColumnFactory);

        PropertyValueFactory<Customer, String> updatedColumnFactory = new PropertyValueFactory<>("update");
        updatedColumn.setCellValueFactory(updatedColumnFactory);
        updatedColumn.setCellValueFactory(cellData -> {
            Date updated = cellData.getValue().getUpdate();
            String updatedString = DateHelper.dateToString(updated);
            return new SimpleStringProperty(updatedString);
        });

        PropertyValueFactory<Customer, String> updatedByColumnFactory = new PropertyValueFactory<>("updatedBy");
        updatedByColumn.setCellValueFactory(updatedByColumnFactory);

        PropertyValueFactory<Customer, Integer> divisionIDColumnFactory = new PropertyValueFactory<>("divisionID");
        divisionIDColumn.setCellValueFactory(divisionIDColumnFactory);

        customers.removeAll();

        try {
            customers = ConnectDB.getCustomers();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        //loop through each customer in customers and adjust the dates to be displayed for the current user
        for (Customer customer : customers) {
            int index = customers.indexOf(customer);
            customer = convertCustomerDates(customer, fromServer);
            customers.set(index, customer);
        }

        updateTable(customers);
    }

    /**
     * Back button for returning to previous screen "MainScreen.fxml"
     */
    public void BackButton(){
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("MainScreen", currentStage);
    }

    /**
     * Loads CustomerDetails screen to add a customer.
     */
    public void addCustomer(){
        ConnectDB.selectedCustomer = null;

        currentStage = (Stage) addButton.getScene().getWindow();
        viewLoader.loadFXML("CustomerDetails", currentStage);
    }

    /**
     * Loads CustomerDetails screen to view or modify an existing customer.
     */
    public void editCustomer(){

        //get customer selection from table
        selectedCustomer = (Customer) customersTable.getSelectionModel().getSelectedItem();
        convertCustomerDates(selectedCustomer, toServer);
        ConnectDB.selectedCustomer = selectedCustomer;

        //ensure not null
        if (selectedCustomer == null) {
            String noSelectedCustomer = languages.getString("noSelectedCustomer");
            viewLoader.showAlert(noSelectedCustomer);
            return;
        }

        //load selected customer into form
        CustomerDetails customerDetails = new CustomerDetails();
        customerDetails.setCustomer(selectedCustomer);
        customerDetails.initialize();

        try {
            customerDetails.loadDetails(selectedCustomer);
        } catch (Exception e) {
            e.printStackTrace();
        }

        currentStage = (Stage) modifyButton.getScene().getWindow();

        //display customer details screen
        viewLoader.loadFXML("CustomerDetails", currentStage);
    }

    /**
     * Deletes a selected customer. Displays alert if there are remaining appointments and won't allow deletion.
     *
     * @throws SQLException if there is an error with the sql code or server.
     */
    public void deleteCustomer() throws SQLException {

        ObservableList<Appointment> appointmentsForCustomer;

        //get customer selection from table
        selectedCustomer = (Customer) customersTable.getSelectionModel().getSelectedItem();
        ConnectDB.selectedCustomer = selectedCustomer;

        //ensure not null
        if (selectedCustomer == null) {
            String noSelectedCustomer = languages.getString("noSelectedCustomer");
            viewLoader.showAlert(noSelectedCustomer);
            return;
        }

        //check for any existing appointments associated with the customer
        appointmentsForCustomer = ConnectDB.getAppointmentsForCustomerByCustomerID(selectedCustomer.getId());

        if (appointmentsForCustomer.isEmpty()) {

            // Prompt user to ensure they want to continue with the deletion
            String confirmDeletion = languages.getString("confirmDeleteCustomer");
            Boolean confirmStatus = viewLoader.confirmPrompt(confirmDeletion);

            if(confirmStatus) {

                //proceed with deletion
                int success = ConnectDB.deleteCustomer(selectedCustomer);

                if (success > 0) {
                    customers.remove(selectedCustomer);

                    ResourceBundle languages = ResourceBundle.getBundle("language");
                    String customerDeleted = languages.getString("customerDeleted");
                    String customerDetails = "Customer ID: " + selectedCustomer.getId() +"\n"
                                           + "Customer   : " + selectedCustomer.getName();

                    viewLoader.showAlert(customerDeleted+"\n"+customerDetails);

                    //refresh customers list
                    getAllCustomers(customers);

                } else {
                    String customerNotDeleted = languages.getString("customerNotDeleted");
                    viewLoader.showAlert(customerNotDeleted);
                }
            }

        } else {
            //display error message alerting user about the appointments in the database that are assigned to the customer
            String existingAppointmentsError = languages.getString("existingAppointmentsError");
            viewLoader.showAlert(existingAppointmentsError);
        }
    }

    /**
     * Sets the language of the various GUI elements based on language selection.
     */
    public void setLanguage() {
        //get language resource bundle
        ResourceBundle languages = ResourceBundle.getBundle("language");

        String customerId, name, address, phone, postCode, created, createdBy, division, updated, updatedBy, add, view, delete, back;

        customerId = languages.getString("customerId");
        name = languages.getString("name");
        address = languages.getString("address");
        postCode = languages.getString("postCode");
        phone = languages.getString("phone");
        created = languages.getString("created");
        createdBy = languages.getString("createdBy");
        division = languages.getString("division");
        updated = languages.getString("updated");
        updatedBy = languages.getString("updatedBy");
        add = languages.getString("add");
        view = languages.getString("view");
        delete = languages.getString("delete");
        back = languages.getString("back");

        customerIDColumn.setText(customerId);
        customerNameColumn.setText(name);
        postCodeColumn.setText(postCode);
        createdDateColumn.setText(created);
        createdByColumn.setText(createdBy);
        addButton.setText(add);
        addressColumn.setText(address);
        phoneColumn.setText(phone);
        updatedColumn.setText(updated);
        updatedByColumn.setText(updatedBy);
        divisionIDColumn.setText(division);
        modifyButton.setText(view);
        deleteButton.setText(delete);
        backButton.setText(back);
    }

    /**
     * Update the table view based on the customerList input.
     *
     * @param customersList the list of customers to be shown on the table view
     */
    public void updateTable(ObservableList<Customer> customersList) {
        customersTable.getItems().clear();
        customersTable.getItems().setAll(customersList);
        customersTable.refresh();
    }

    /**
     * Converts values to/from server/user to store or display, depending on context.
     *
     * @param customer      the customer object that has the dates in question
     * @param fromServer    boolean value to determine which way we are converting either to or from the server.
     * @return              customer object with adjust date/time
     */
    public Customer convertCustomerDates(Customer customer, Boolean fromServer) {

        // String used to store the created date string that's been converted either from/to server/user time
        String createdString;

        // String used to store the updated date string that's been converted either from/to server/user time
        String updatedString;

        //check if converting to or from the server
        if (fromServer) {
            //alter values to be the user's time zone
            createdString = DateHelper.convertServerToUser(customer.getCreated());
            updatedString = DateHelper.convertServerToUser(customer.getUpdate());
        }else{
            /* Convert to Server Date-Time */
            createdString = DateHelper.convertUserToServer(customer.getCreated());
            updatedString = DateHelper.convertUserToServer(customer.getUpdate());
        }

        //set values for customer and return customer object
        customer.setCustomerCreatedDate(DateHelper.stringToDate(createdString));
        customer.setCustomerLastUpdate(DateHelper.stringToDate(updatedString));
        return customer;
    }
}