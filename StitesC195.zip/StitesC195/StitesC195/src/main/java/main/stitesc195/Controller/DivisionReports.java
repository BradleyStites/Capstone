package main.stitesc195.Controller;

import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import main.stitesc195.Model.DivisionReport;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * Contains the logic and variables for the "DivisionReports" screen.
 * Launches different screens, sets texts on GUI elements based on language selection, displays report in table view.
 *
 * @author Bradley Stites
 */
public class DivisionReports implements Initializable {

    /**
     * Button for returning to previous screen, ReportSelection.
     */
    @FXML
    private Button backButton;

    /**
     * TableColumn for storing division ids
     */
    @FXML
    TableColumn<DivisionReport, Integer> divisionIdColumn;

    /**
     * TableColumn for storing division names
     */
    @FXML
    TableColumn<DivisionReport, String> divisionNameColumn;

    /**
     * TableColumn for storing total customers per division
     */
    @FXML
    TableColumn<DivisionReport, Integer> totalColumn;

    /**
     * TableView for displaying division reports.
     */
    @FXML
    private TableView divisionReportTableView;

    /**
     * ObservableList for storing Division Reports
     */
    ObservableList<DivisionReport> divisionReports = FXCollections.observableArrayList();

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;

    /**
     * Gets a resource bundle for the various language options
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * Initializes the DivisionReports screen.
     * Gets division reports from database, sets the items in the table view to the division reports, sets the text
     * of various GUI elements to match language selection.
     *
     * @param url               The location used to resolve relative paths for the root object, or null if the location is not known.
     * @param resourceBundle    The resources used to localize the root object, or null if the root object was not localized.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        viewLoader = new ViewLoader();

        // Get division reports from DB
        divisionReports = ConnectDB.getDivisionReports();

        if(divisionReports.isEmpty()){
            //no appointments --send prompt to user notifying
            viewLoader.showAlert("noDivisionReports");
        }

        divisionReportTableView.getItems().clear();
        addReportsToTableView();

        divisionReportTableView.getItems().setAll(divisionReports);
        divisionReportTableView.refresh();
        setLanguage();
    }

    /**
     * Sets text of GUI elements to match language selection.
     */
    private void setLanguage() {
        String divisionId, division, total, back;

        divisionId = languages.getString("divisionId");
        division = languages.getString("division");
        total = languages.getString("total");
        back = languages.getString("back");

        divisionIdColumn.setText(divisionId);
        divisionNameColumn.setText(division);
        totalColumn.setText(total);
        backButton.setText(back);
    }

    /**
     * Sets cell value factory for columns
     */
    private void addReportsToTableView() {
        divisionIdColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        divisionNameColumn.setCellValueFactory( cellData -> Bindings.createStringBinding(() -> cellData.getValue().getName()));
        totalColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getTotal()).asObject());
    }

    /**
     * Returns user to previous screen, ReportSelection.
     *
     * @throws SQLException error with SQL statement or server
     * @throws IOException  error with IO
     */
    public void backButton() throws SQLException, IOException {
        currentStage = (Stage) backButton.getScene().getWindow();
        viewLoader.loadFXML("ReportSelection", currentStage);
    }
}
