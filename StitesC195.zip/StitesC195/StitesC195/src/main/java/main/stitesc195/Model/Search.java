package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;
import java.util.Date;

/**
 * The Search Details class represents an search object to filter appointments from the database
 */
public class Search {

    /**
     * int representing the unique id value for the search details.
     */
    private int searchID;

    /**
     * String representing the title for the appointment.
     */
    private String title;

    /**
     * String representing the description of the appointment.
     */
    private String description;

    /**
     * String representing the location of the appointment.
     */
    private String location;

    /**
     * String representing the type of appointment.
     */
    private String type;

    /**
     * Date representing the start value of the appointment.
     */
    private Date start;

    /**
     * Date representing the end value of the appointment.
     */
    private Date end;

    /**
     * Int representing the customer id for the appointment.
     */
    private int customerID;

    /**
     * Int representing the user id for the appointment.
     */
    private int userID;

    /**
     * Int representing the contact id for the appointment.
     */
    private int contactID;

    /**
     * Boolean representing if the search is to be saved as a favorite.
     */
    private Boolean favorite;

    /**
     * String representing the value for the time zone id
     */
    private int zoneId;

    /**
     * String representing the value for the search owner's id
     */
    private int ownerId;

    /**
     * Constructs an empty 'search details' object.
     */
    public Search() {
    }

    /**
     * Constructs an 'search details' object with the given parameters.
     *
     * @param searchID  	 The search's unique identifier.
     * @param title          The title of the appointment.
     * @param description    The description of the appointment.
     * @param location       The location where the appointment takes place.
     * @param type           The type of the appointment.
     * @param start          The start date and time of the appointment.
     * @param end            The end date and time of the appointment.
     * @param customerID     The ID of the customer associated with the appointment.
     * @param userID         The ID of the user associated with the search.
     * @param contactID      The ID of the contact associated with the appointment.
     * @param favorite       Boolean value representing if the search is favorited.
     * @param zoneID		 String value representing the time zone id
     * @param ownerID		 The ID associated with the owner of the search.
     */
    public Search(int searchID, String title, String description, String location, String type, Date start, Date end,
                  int customerID, int userID, int contactID, boolean favorite, String zoneID, int ownerID) {
        setSearchID(searchID);
        setTitle(title);
        setDescription(description);
        setLocation(location);
        setType(type);
        setStart(start);
        setEnd(end);
        setCustomerID(customerID);
        setUserID(userID);
        setContactID(contactID);
        setFavorite(favorite);
        setZoneID(Integer.parseInt(zoneID));
        setOwnerID(ownerID);
    }

    /**
     * returns the value of owner id
     *
     * @return the value of owner id
     */
    public int getOwnerID(){ return ownerId;
    }

    /**
     * returns the value of zone id
     *
     * @return the value of zone id
     */
    public int getZoneID(){ return zoneId;
    }

    /**
     * returns the value of favorite
     *
     * @return the value of favorite
     */
    public Boolean getFavorite(){ return favorite;
    }

    /**
     * returns the id of the contact.
     *
     * @return the id of the contact
     */
    public int getContactID(){ return contactID;
    }

    /**
     * returns the id of the appointment.
     *
     * @return the id of the appointment.
     */
    public int getSearchID(){
        return searchID;
    }

    /**
     * returns the title of the appointment.
     *
     * @return the appointment's title
     */
    public String getTitle(){
        return title;
    }

    /**
     * returns the appointment's location.
     *
     * @return location for the appointment.
     */
    public String getLocation(){
        return location;
    }

    /**
     * returns the type for the appointment.
     * @return the type of appointment.
     */
    public String getType(){
        return type;
    }

    /**
     * returns the start value for the appointment.
     * @return the start date for the appointment.
     */
    public Date getStart(){
        return start;
    }

    /**
     * returns the end value for the appointment.
     * @return the end value for the appointment.
     */
    public Date getEnd(){
        return end;
    }

    /**
     * returns the customer id for the appointment.
     * @return the customer id being returned.
     */
    public int getCustomerID(){
        return customerID;
    }

    /**
     * returns the user id for the appointment.
     * @return the user id being returned.
     */
    public int getUserID(){ return userID; }

    /**
     * returns the description for the appointment.
     * @return the appointment description.
     */
    public String getDescription(){
        return description;
    }

    /**
     * sets the owner id
     * @param id the owner id to be set
     */
    public void setOwnerID(int id){
        this.ownerId = id;
    }

    /**
     * sets the zone id
     * @param zoneID the zone id to be set
     */
    public void setZoneID(int zoneID){
        this.zoneId = zoneID;
    }

    /**
     * sets the appointment id
     * @param searchID the appointment id to be set
     */
    public void setSearchID(int searchID){
        this.searchID = searchID;
    }

    /**
     * sets the appointment title
     * @param title the title to be set
     */
    public void setTitle(String title){
        this.title = title;
    }

    /**
     * sets the appointment's description.
     *
     * @param desc The description to be set.
     */
    public void setDescription(String desc){
        this.description = desc;
    }

    /**
     * sets the location of the appointment
     * @param location the location to be set
     */
    public void setLocation(String location){
        this.location = location;
    }

    /**
     * sets the type for the appointment.
     *
     * @param type the type to be set
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * sets the contact id for the appointment.
     * @param id contact id being set.
     */
    public void setContactID(int id){
        this.contactID = id;
    }

    /**
     * sets the user id for the appointment.
     * @param userID user id to be set.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * sets the customer id for the appointment.
     * @param customerID customer id being set.
     */
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /**
     * set the end date for the appointment.
     * @param end the end date for the appointment.
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * set the start date for the appointment for the search.
     *
     * @param start the start date for the appointment for the search.
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * sets the value of favorite
     * @param favorite the value to be set for the favorite value
     */
    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    /**
     * prints out appointment information. Used to debug problems in the code.
     * @return String containing information regarding an appointment.
     */
    public String printSearchInformation() {

        //create a dateHelper object to manage the display of the date/time variables
        DateHelper dateHelper = new DateHelper();

        //original values
        String startString, endString, createDateString, lastUpdateString;

        startString      = DateHelper.stringDateToFormatForSQL(start);
        endString        = DateHelper.stringDateToFormatForSQL(end);

        String output = searchID +", '" + title + "', '" +  description + "', '" + location + "', '" +
                type + "', '" + startString +"', '" + endString  +"', '" + customerID   +", " + userID   +", " + contactID + ", " + favorite+ ", " + zoneId;

        System.out.println(output);

        return output;
    }

    public void setSearch(Search selectedSearch) {
    }

    public void initialize() {
    }

    public void loadDetails(Search selectedSearch) {
    }
}