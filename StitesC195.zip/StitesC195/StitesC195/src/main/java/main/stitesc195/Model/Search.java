package main.stitesc195.Model;

import main.stitesc195.Controller.DateHelper;
import java.util.Date;

/**
 * The Search Details class represents a search object to filter appointments from the database
 */
public class Search {

    /**
     * int representing the unique id value for the search details.
     */
    private int id;

    /**
     * String representing the description of the appointment.
     */
    private String description;

    /**
     * String representing the location of the appointment.
     */
    private String location;

    /**
     * String representing the type of appointment.
     */
    private String type;
	
	/**
     * String representing the title of appointment.
     */
    private String title;

    /**
     * Date representing the start value of the appointment.
     */
    private Date start;

    /**
     * Date representing the end value of the appointment.
     */
    private Date end;

    /**
     * Int representing the customer id for the appointment.
     */
    private int customerId;

    /**
     * Int representing the user id for the appointment.
     */
    private int userId;

    /**
     * Int representing the contact id for the appointment.
     */
    private int contactId;

    /**
     * Boolean representing if the search is to be saved as a favorite.
     */
    private Boolean favorite;

    /**
     * String representing the value for the search owner's id
     */
    private int ownerId;

    /**
     * Constructs an empty 'search details' object.
     */
    public Search() {
    }

    /**
     * Constructs an 'search details' object with the given parameters.
     *
     * @param id  	         The search's unique identifier.
     * @param description    The description of the appointment.
     * @param location       The location where the appointment takes place.
     * @param type           The type of the appointment.
	 * @param title			 The title of the appointment
     * @param start          The start date and time of the appointment.
     * @param end            The end date and time of the appointment.
     * @param customerId     The ID of the customer associated with the appointment.
     * @param userId         The ID of the user associated with the search.
     * @param contactId      The ID of the contact associated with the appointment.
     * @param favorite       Boolean value representing if the search is a favorite.
     * @param ownerId		 The ID associated with the owner of the search.
     */
    public Search(int id, String description, String title, String location, String type, Date start, Date end, int customerId, int userId, int contactId, boolean favorite, int ownerId) {
        setId(id);
        setDescription(description);
		setTitle(title);
        setLocation(location);
        setType(type);
        setStart(start);
        setEnd(end);
        setCustomerId(customerId);
        setUserId(userId);
        setContactId(contactId);
        setFavorite(favorite);
        setOwnerId(ownerId);
    }

    /**
     * returns the value of owner id
     *
     * @return the value of owner id
     */
    public int getOwnerId(){
        return ownerId;
    }
	
	/**
     * returns the value of the title
     *
     * @return the value of title
     */
    public String getTitle(){
        return title;
    }

    /**
     * returns the value of favorite
     *
     * @return the value of favorite
     */
    public Boolean getFavorite(){
        return favorite;
    }

    /**
     * returns the id of the contact.
     *
     * @return the id of the contact
     */
    public int getContactId(){
        return contactId;
    }

    /**
     * returns the id of the appointment.
     *
     * @return the id of the appointment.
     */
    public int getId(){
        return id;
    }

    /**
     * returns the appointment's location.
     *
     * @return location for the appointment.
     */
    public String getLocation(){
        return location;
    }

    /**
     * returns the type for the appointment.
     * @return the type of appointment.
     */
    public String getType(){
        return type;
    }

    /**
     * returns the start value for the appointment.
     * @return the start date for the appointment.
     */
    public Date getStart(){
        return start;
    }

    /**
     * returns the end value for the appointment.
     * @return the end value for the appointment.
     */
    public Date getEnd(){
        return end;
    }

    /**
     * returns the customer id for the appointment.
     * @return the customer id being returned.
     */
    public int getCustomerId(){
        return customerId;
    }

    /**
     * returns the user id for the appointment.
     * @return the user id being returned.
     */
    public int getUserId(){
        return userId;
    }

    /**
     * returns the description for the search.
     * @return the appointment description.
     */
    public String getDescription(){
        return description;
    }

    /**
     * sets the owner id
     * @param id the owner id to be set
     */
    public void setOwnerId(int id){
        this.ownerId = id;
    }
	
	/**
     * sets the search title
     * @param title the search title to be set
     */
    public void setTitle(String title){
        this.title = title;
    }

    /**
     * sets the appointment id
     * @param id the appointment id to be set
     */
    public void setId(int id){
        this.id = id;
    }

    /**
     * sets the appointment's description.
     *
     * @param desc The description to be set.
     */
    public void setDescription(String desc){
        this.description = desc;
    }

    /**
     * sets the location of the appointment
     * @param location the location to be set
     */
    public void setLocation(String location){
        this.location = location;
    }

    /**
     * sets the type for the appointment.
     *
     * @param type the type to be set
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * sets the contact id for the appointment.
     * @param id contact id being set.
     */
    public void setContactId(int id){
        this.contactId = id;
    }

    /**
     * sets the user id for the appointment.
     * @param userId user id to be set.
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * sets the customer id for the appointment.
     * @param customerId customer id being set.
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * set the end date for the appointment.
     * @param end the end date for the appointment.
     */
    public void setEnd(Date end) {
        this.end = end;
    }

    /**
     * set the start date for the appointment for the search.
     *
     * @param start the start date for the appointment for the search.
     */
    public void setStart(Date start) {
        this.start = start;
    }

    /**
     * sets the value of favorite
     * @param favorite the value to be set for the favorite value
     */
    public void setFavorite(Boolean favorite) {
        this.favorite = favorite;
    }

    /**
     * prints out appointment information. Used to debug problems in the code.
     * @return String containing information regarding an appointment.
     */
    public String printSearchInformation() {

        //create a dateHelper object to manage the display of the date/time variables
        DateHelper dateHelper = new DateHelper();

        //original values
        String startString="", endString="", createDateString, lastUpdateString;

        if(start!=null){
            startString      = DateHelper.stringDateToFormatForSQL(start);
        }
        if(end!=null){
            endString        = DateHelper.stringDateToFormatForSQL(end);
        }

        String output = id          + ", '" 	+
						description + "', '" 	+
						location 	+ "', '" 	+
						type 		+ "', '" 	+ 
						title 		+ "', " 	;

        if(start!=null){
              output += "'"+ startString + "', " 	;
        }else{
              output += "null, ";
        }
        if(end!=null){
              output += "'"+endString +"', ";
        }else{
              output += "null, ";
        }
              output +=
                        customerId  + ", " 		+
                        userId      + ", " 		+
                        contactId   + ", " 		+
						favorite;

        System.out.println(output);

        return output;
    }

    public Boolean hasCriteria(){
        String title,type, desc, location;

        if(getTitle()==null)
            title="";
        else
            title       = getTitle();

        if(getType()==null)
            type = "";
        else
            type        = getType();

        if(getDescription()==null)
            desc = "";
        else
            desc        = getDescription();

        int     customerId  = getCustomerId();
        int     userId      = getUserId();
        int     contactId   = getContactId();
        Date    start       = getStart();
        Date    end         = getEnd();

        if(getLocation()==null)
            location = "";
        else
            location    = getLocation();

        return !title.isEmpty()     ||
                !type.isEmpty()     ||
                !desc.isEmpty()     ||
                customerId>=0       ||
                userId>=0           ||
                contactId>=0        ||
                start!=null         ||
                end!=null           ||
                !location.isEmpty();
    }
}