package main.stitesc195.Controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import main.stitesc195.Model.Appointment;
import main.stitesc195.Model.Contact;
import main.stitesc195.Model.User;
import main.stitesc195.Model.UserRole;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.ResourceBundle;

public class UserDetails implements Initializable {


	@FXML
	public Label userIdLabel;
	
	@FXML
	public TextField userIDField;
	
	@FXML
	public Label userNameLabel;
	
	@FXML
	public TextField userNameField;
	
	@FXML
	public Label passwordLabel;
	
	@FXML
	public TextField passwordField;
	
	@FXML
	public Label roleLabel;
	
	@FXML
	public ComboBox roleComboBox;
	
	@FXML
    public Label createdLabel;
    
	@FXML
	public Label createdByLabel;
	
	@FXML
    public Label updatedLabel;
	
	@FXML
	public Label updatedByLabel;
	
	@FXML
    public TextField updatedField;

    @FXML
    public TextField updatedByField;

    /**
     * A TextField representing the user who created the user.
     */
    @FXML
    public TextField createdByField;
	
    @FXML
    public TextField createdField;

    /**
     * Button for saving values in the form to the Database as an appointment object.
     */
    @FXML
    public Button saveButton;

    /**
     * Button to cancel the input of values and return to the previous screen Appointments.fxml
     */
    @FXML
    public Button cancelButton;

    /**
     * The current stage of the application.
     */
    Stage currentStage;

    /**
     * The view loader for the application.
     */
    ViewLoader viewLoader;
	
	/**
     * ObservableList containing the list of all user roles.
     */
    ObservableList<UserRole> userRoles;

    /**
     * Gets a resource bundle for the various language options
     *
     * This allows the application to set the various labels and prompt texts to match the selected language option.
     */
    ResourceBundle languages = ResourceBundle.getBundle("language");

    /**
     * DateHelper used to convert various dates and times.
     */
    DateHelper dateHelper;

    /**
     * User object - either a selected user from a previous screen or a placeholder for the new user being saved
     */
    User selectedUser;

	/**
	 * Initializes the controller. If a selected user is present in the ConnectDB class, it assigns it to the local selectedUser variable.
	 * Initializes the text fields, combo boxes, and date pickers.
	 */
    public void initialize() {
        if(ConnectDB.selectedUser!=null){
            selectedUser = ConnectDB.selectedUser;
        }

        //initialize field, combo boxes, and date pickers
        userIDField   			= new TextField();
		userNameField 			= new TextField();
		passwordField 			= new TextField();
		roleComboBox		 	= new ComboBox();
		createdField			= new TextField();
		updatedField			= new TextField();
		createdByField			= new TextField();
		updatedByField			= new TextField();
    }

	/**
	 * Sets the selected user to be used by the controller.
	 *
	 * @param selectedUser The User object representing the selected user.
	 */
    public void setUser(User selectedUser) {
		this.selectedUser = selectedUser;
    }
	
	/**
	 * Initializes the controller after its root element has been completely processed.
	 * This method is automatically called by the FXMLLoader once all dependencies have been injected.
	 * It initializes necessary objects, populates UI elements, and sets their initial values.
	 *
	 * @param url            The location used to resolve relative paths for the root object, or null if the location is not known.
	 * @param resourceBundle The resources used to localize the root object, or null if the root object was not localized.
	 */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        dateHelper = new DateHelper();
        viewLoader = new ViewLoader();

        //initialize roles
        userRoles = ConnectDB.getAllRoles();

        //populate user roles combo box
        for(UserRole role : userRoles){
            String roleDescription = role.getDescription();
            System.out.println(roleDescription);
            roleComboBox.getItems().add(role.getDescription());
        }

        //if updating an availability
        if (ConnectDB.selectedUser != null) {
            selectedUser = ConnectDB.selectedUser;

            // initialize the fields with the selected user's values
            userIDField.setText(""+selectedUser.getUserID());
            userNameField.setText(""+selectedUser.getUserName());
            passwordField.setText(""+selectedUser.getPassword());
            createdByField.setText(""+selectedUser.getCreatedBy());
            updatedByField.setText(""+selectedUser.getUpdatedBy());

            //get the role id from the administrators table that matches the user id
            int userRoleId = ConnectDB.getUserRoleIDByUserID(selectedUser.getUserID());

            if(userRoleId!=-1){
                //set user role combo box to user's
                for(UserRole Role : userRoles){
                    if(userRoleId == Role.getRoleID()){
                        roleComboBox.setValue(Role.getDescription());
                    }
                }
            }

            //get dates
            Date created = selectedUser.getCreated();
            Date updated = selectedUser.getUpdated();

            String createDateText = DateHelper.convertServerToUser(created);
            String lastUpdateText = DateHelper.convertServerToUser(updated);

            createdField.setText(createDateText);
            updatedField.setText(lastUpdateText);
        }
		
		//set language for gui elements
		setLanguage();
    }
	
	/**
	 * Sets the language for the user interface elements based on the current locale.
	 * This method retrieves localized strings from resource bundles and updates
	 * the labels, buttons, and other UI elements accordingly.
	 */
	public void setLanguage(){
		String userId, userName, password, roleString, createdByString, updatedByString, 
			   updatedString, createdString, save, cancel;

        userId 				= languages.getString("userId");
        userName			= languages.getString("userName");
		password			= languages.getString("password");
		roleString			= languages.getString("role");
		createdString		= languages.getString("created");
		updatedString		= languages.getString("updated");	
		createdByString		= languages.getString("createdBy");
		updatedByString		= languages.getString("updatedBy");
        save    			= languages.getString("save");
        cancel  			= languages.getString("cancel");

        //set labels for fields
        userIdLabel.setText(userId);
        userNameLabel.setText(userName);
		passwordLabel.setText(password);
		roleLabel.setText(roleString);

        //set label text for dates
        createdLabel.setText(createdString);
        updatedLabel.setText(updatedString);
        createdByLabel.setText(createdByString);
        updatedByLabel.setText(updatedByString);

        //set text for buttons
        saveButton.setText(save);
        cancelButton.setText(cancel);
	}

	/**
	 * Saves a user's details to the database. This method handles both adding a new user
	 * and updating an existing user's information. It retrieves user input from the UI,
	 * performs necessary validation, and then attempts to add the user to the database
	 * or update their existing record. If successful, it also assigns or updates the user's role.
	 *
	 * @throws SQLException If an SQL error occurs during the database operation.
	 */
    public void save() throws SQLException {
        currentStage = (Stage) saveButton.getScene().getWindow();

        int userId, roleId=-1;
        Date created, updated;
        Boolean newUser;
        Boolean success;
        Boolean roleSuccess = false;

        //variables for fields & combo boxes
        String   userIdString, userName, password, createdDate, createdBy, updatedBy, role;

        //get values from fields & combo boxes
        userIdString = userIDField.getText();
        userName     = userNameField.getText();
        password     = passwordField.getText();
        role         = roleComboBox.getValue().toString();

        //set updated by to be the active user
        updatedBy = ConnectDB.activeUserName;

        //set updated date
        updated     = ConnectDB.getDateFromServer();

        //check if new user or not and process values and attempt to add to db
        if(userIdString==null || userIdString.equals("")){
            //this is a new user
            newUser     = true;
            userId      = ConnectDB.generateNewUserID();
            createdBy   = ConnectDB.activeUserName;
            created     = ConnectDB.getDateFromServer();

            //create user and save
            selectedUser = new User(userId, userName,password, created,createdBy,updated,updatedBy);
            success = ConnectDB.addUser(selectedUser);

            //only add role if successful adding user
            if(success) {
                //add role information to DB
                //loop through roles to find the role id from the description
                if (!role.equals("") || role != null) {
                    //get the role id from the description of the role
                    for (UserRole Role : userRoles) {
                        if (Role.getDescription().equals(role)) {
                            //set the roleID to the userRole's id
                            roleId = Role.getRoleID();

                            //set the user to the role in the admin DB
                            roleSuccess = ConnectDB.addUserToRole(userId, roleId);
                        }
                    }
                }
            }else
                //set role success to false if user couldn't be added
                roleSuccess = false;

        }else{
            //updating user
            newUser     = false;
            userId      = Integer.parseInt(userIdString);
            createdBy   = createdByField.getText();
            createdDate = createdField.getText();

            //set created
            created = ConnectDB.stringToDate(createdDate);
            selectedUser = new User(userId, userName,password, created,createdBy,updated,updatedBy);
            success = ConnectDB.editUser(selectedUser);

            //only add role if successful updating user
            if(success){
                //loop through roles to find the role id from the description
                if(!role.equals("") || role!=null){
                    //get the role id from the description of the role
                    for(UserRole Role : userRoles){
                        if(Role.getDescription().equals(role)){
                            //set the roleID to the userRole's id
                            roleId = Role.getRoleID();

                            //set the user to the role in the admin DB
                            roleSuccess = ConnectDB.addUserToRole(userId, roleId);
                        }
                    }
                }
            }else
                //set role success to false if user couldn't be updated
                roleSuccess = false;
        }

        //process successes and push appropriate notification
        processSuccesses(success, roleSuccess, newUser);
    }

	/**
	 * Processes the success or failure of user-related operations and displays appropriate messages.
	 *
	 * @param success    A boolean indicating whether the main operation (add or edit user) was successful.
	 * @param roleSuccess A boolean indicating whether the role assignment operation was successful.
	 * @param newUser    A boolean indicating whether a new user was added or an existing user was edited.
	 */
    private void processSuccesses(Boolean success, Boolean roleSuccess, Boolean newUser) {
        String outputStatement = "";

        //start initializing outputstatement with appropriate comments to match the use case in question
        if(newUser){
            String addingUser = languages.getString("addingUser");
            outputStatement += addingUser + "\n";
        }else{
            String editingUser = languages.getString("updatingUser");
            outputStatement += editingUser + "\n";
        }

        //add username to output statement
        outputStatement +=  selectedUser.getUserName() +"\n";

        //add success statement to the output statement
        if(success){
            String successString = languages.getString("success");
            outputStatement += successString + "\n";
        }else{
            String failureString = languages.getString("failure");
            outputStatement += failureString + "\n";
        }

        if (roleSuccess) {
            String roleSuccessString = languages.getString("roleSuccess");
            outputStatement += roleSuccessString;
        }else{
            String roleFailureString = languages.getString("roleFailure");
            outputStatement += roleFailureString;
        }

        //show output via viewLoader
        viewLoader.showAlert(outputStatement);
        returnToUsers();
    }

	/**
	 * Calls the cancel function, which navigates back to the "Users" view
	 */
    public void returnToUsers(){
        cancel();
    }
	
	/**
	 * Cancels the current operation and navigates back to the "Users" view.
	 */
    public void cancel() {
		// Retrieve the current stage associated with the cancel button.
        currentStage = (Stage) cancelButton.getScene().getWindow();
		
		// Load the "Users" view using the viewLoader.
        viewLoader.loadFXML("Users", currentStage);
    }
}