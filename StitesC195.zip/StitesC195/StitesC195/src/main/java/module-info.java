module main.stitesc195 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens main.stitesc195 to javafx.fxml;
    exports main.stitesc195;
    exports main.stitesc195.Controller;
    opens main.stitesc195.Controller to javafx.fxml;
    opens main.stitesc195.Model to javafx.base;
}