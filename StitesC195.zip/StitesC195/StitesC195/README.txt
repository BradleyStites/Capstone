Title		: StitesC195
Purpose		: Manage customers, appointments, and view reports.
Author 		: Bradley Stites
Contact		: bstite1@wgu.edu
Version		: 1.0
Date		: 2/28/2023
IDE Ver		: IntelliJ IDEA 2021.1.3 (Community Edition)
              Build #IC-211.7628.21, built on June 30, 2021
              Runtime version: 11.0.11+9-b1341.60 amd64
              VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
              Windows 10 10.0
              GC: G1 Young Generation, G1 Old Generation
              Memory: 768M
              Cores: 4
              Non-Bundled Plugins: com.intellij.javafx (1.0.4)
              Kotlin: 211-1.4.32-release-IJ7628.19
Java FX version	: javafx.version=20.0.1
                  javafx.runtime.version=20.0.1+2
                  javafx.runtime.build=2


How to Use Software:
	Login with an approved username & password.

	Change default language by selecting a language option on the login page.
	Change default time zone by selecting a time zone from the login page.

	Upon login user will get a notification if there are any appointments within fifteen minutes.
	
	To Create an appointment, goto the Appointments screen and click Add. Appointments must not overlap existing appointments for customers or be outside business hours.
	To Modify or View an appointment, click "View/Modify" at the Appointment screen with an appointment selected.
	To Delete an appointment, click the delete button on the appointments screen with an appointment selected.
	Appointments can be filtered by week, month, or user can display all. When filtering by week or month the next and previous buttons will be available depending if dates exist in that direction.

	To Create an Customer, goto the Customers screen and click Add.
	To Modify or View a customer, click "View/Modify" at the customers screen with a customer selected.
	To Delete a customer, click the delete button on the customers screen with an appointment selected. A customer cannot be deleted if the customer has existing appointments.
	
	To view a desired report select the appropriate button at the reports selection screen, which can be accessed from the main screen after login.


Description of Report 3:	Retrieves a total number of appointments by division.

MySQL Driver Version  : mysql-connector-java-8.0.30